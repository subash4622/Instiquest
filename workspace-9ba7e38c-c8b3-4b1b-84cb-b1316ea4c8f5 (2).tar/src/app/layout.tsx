import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    default: "INSTIQUEST — Premium Educational Admission Portal | WEB CREATORS",
    template: "%s | INSTIQUEST",
  },
  description:
    "INSTIQUEST is a futuristic educational admission portal featuring 100+ entrance exams, institution directory, hard-level mock tests, AI admission chatbot, advertising portal and admin tools. Built by WEB CREATORS.",
  keywords: [
    "INSTIQUEST",
    "WEB CREATORS",
    "admission portal",
    "entrance exams India",
    "JEE Main",
    "NEET",
    "CAT",
    "CLAT",
    "mock test",
    "institutions directory",
    "IIT",
    "NIT",
    "IIM",
    "AI admission chatbot",
    "engineering admission",
    "medical admission",
    "management admission",
  ],
  authors: [{ name: "WEB CREATORS" }],
  creator: "WEB CREATORS",
  publisher: "WEB CREATORS",
  applicationName: "INSTIQUEST",
  category: "Education",
  icons: {
    icon: [
      { url: "/instiquest-logo-256.png", type: "image/png", sizes: "256x256" },
      { url: "/instiquest-favicon-64.png", type: "image/png", sizes: "64x64" },
      { url: "/favicon.svg", type: "image/svg+xml" },
    ],
    shortcut: "/instiquest-logo-256.png",
    apple: "/instiquest-logo-256.png",
  },
  openGraph: {
    title: "INSTIQUEST — Premium Educational Admission Portal",
    description:
      "Futuristic admission portal with 100+ exams, institutions, mock tests, AI chatbot, advertising portal and admin dashboards. By WEB CREATORS.",
    siteName: "INSTIQUEST",
    type: "website",
    locale: "en_IN",
  },
  twitter: {
    card: "summary_large_image",
    title: "INSTIQUEST — Premium Educational Admission Portal",
    description:
      "Futuristic admission portal with 100+ exams, institutions, mock tests, AI chatbot and admin tools.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true },
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta name="theme-color" content="#0a0e27" />
        <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
        <Sonner position="top-right" />
      </body>
    </html>
  );
}
