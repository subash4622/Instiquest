"use client";

import dynamic from "next/dynamic";

// AppShell is client-only — load it dynamically so SSR only renders a
// minimal shell and the client hydrates the full SPA. The / route is
// the only user-visible route per sandbox preview constraint; all
// internal "pages" are components driven by hash-based routing.
const AppShell = dynamic(
  () => import("@/components/layout/AppShell").then((m) => m.AppShell),
  {
    ssr: false,
    loading: () => (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-3">
          <div className="mx-auto h-10 w-10 rounded-full border-2 border-electric border-t-transparent animate-spin" />
          <p className="text-sm text-muted-foreground">Loading INSTIQUEST…</p>
        </div>
      </div>
    ),
  }
);

export default function Home() {
  return <AppShell />;
}
