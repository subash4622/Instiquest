/**
 * INSTIQUEST admin authentication — DEMO endpoint.
 * -------------------------------------------------------------
 * This route is a placeholder for a real NextAuth.js credentials
 * or email-based authentication flow. It accepts a role + optional
 * email/name, creates a deterministic demo session and returns it.
 *
 * Replace this with a real NextAuth setup before going live.
 * Passwords must be hashed server-side (e.g., bcrypt) and never
 * stored in plain text or in the frontend.
 *
 * Role-based permissions:
 *   - student: default, can use directory, mock tests, dashboard
 *   - institute: can submit ads
 *   - admin: full admin console access
 */

import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

interface LoginDTO {
  role: "student" | "institute" | "admin";
  email?: string;
  name?: string;
}

const ALLOWED_ROLES = new Set(["student", "institute", "admin"]);

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as LoginDTO;
    if (!body.role || !ALLOWED_ROLES.has(body.role)) {
      return NextResponse.json({ error: "Invalid role" }, { status: 400 });
    }

    // DEMO ONLY — a real implementation would verify credentials
    // against a hashed-password store and issue a signed JWT or
    // a NextAuth session cookie.
    const session = {
      id: `demo-${body.role}-${Date.now()}`,
      name: body.name ?? (body.role === "admin" ? "Admin User" : body.role === "institute" ? "Institute Rep" : "Student User"),
      email: body.email ?? `${body.role}@instiquest.demo`,
      role: body.role,
      demo: true,
      issuedAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    };

    return NextResponse.json({ ok: true, session });
  } catch (err) {
    return NextResponse.json({ error: "Login failed", detail: String(err) }, { status: 500 });
  }
}

export async function GET() {
  return NextResponse.json({
    endpoint: "/api/auth/login",
    method: "POST",
    demo: true,
    note: "Replace with a real NextAuth.js credentials or email provider. Passwords must be hashed server-side.",
    roles: ["student", "institute", "admin"],
    permissions: {
      student: ["browse", "mock-tests", "student-dashboard"],
      institute: ["browse", "mock-tests", "advertising"],
      admin: ["student", "institute", "admin-console"],
    },
  });
}
