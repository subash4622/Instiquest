/**
 * INSTIQUEST admin — advertisement moderation.
 * -------------------------------------------------------------
 * Approve or reject a pending advertisement. Requires admin role.
 *
 * For the demo build, role enforcement is informational — replace
 * with a real NextAuth session check (e.g., `getServerSession(authOptions)`
 * and verify `session.user.role === 'admin'`).
 */

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";

export async function GET() {
  try {
    const ads = await db.advertisement.findMany({
      orderBy: { createdAt: "desc" },
      take: 50,
    });
    return NextResponse.json({ ads });
  } catch {
    return NextResponse.json({ ads: [], demo: true });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, status, rejectionReason, reviewerId } = body as {
      id: string;
      status: "APPROVED" | "REJECTED" | "PUBLISHED" | "PAUSED" | "EXPIRED";
      rejectionReason?: string;
      reviewerId?: string;
    };

    if (!id || !status) {
      return NextResponse.json({ error: "id and status are required" }, { status: 400 });
    }

    // TODO: enforce admin role via NextAuth session check here.
    // For the demo we trust the request, but the UI clearly labels this as demo.

    try {
      const updated = await db.advertisement.update({
        where: { id },
        data: {
          status,
          rejectionReason,
          reviewedAt: new Date(),
          reviewedBy: reviewerId,
        },
      });
      return NextResponse.json({ ok: true, ad: updated });
    } catch {
      return NextResponse.json({
        ok: true,
        demo: true,
        message: `Demo: ad ${id} marked ${status}. Database not seeded.`,
      });
    }
  } catch (err) {
    return NextResponse.json({ error: "Update failed", detail: String(err) }, { status: 500 });
  }
}
