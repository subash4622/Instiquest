/**
 * INSTIQUEST AI chatbot — server-side proxy.
 * -------------------------------------------------------------
 * This route receives chat messages from the frontend and forwards
 * them to a server-side AI provider. The actual provider SDK and API
 * key are NEVER exposed to the frontend; only this server-side file
 * reads them from environment variables.
 *
 * For the demo build, if no provider key is configured, the route
 * falls back to the verified knowledge base and returns a clearly
 * labelled AI-guidance message that points to verified KB entries.
 *
 * Replace the placeholder section with a real call to the
 * z-ai-web-dev-sdk LLM helper (already installed) to enable live AI.
 */

import { NextRequest, NextResponse } from "next/server";
import { searchKB, verifiedKB } from "@/data/kb";

export const runtime = "nodejs";

interface ChatMessageDTO {
  role: "user" | "assistant" | "system";
  content: string;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const messages: ChatMessageDTO[] = Array.isArray(body?.messages) ? body.messages : [];

    if (messages.length === 0) {
      return NextResponse.json(
        { error: "Messages array is required" },
        { status: 400 }
      );
    }

    const lastUser = [...messages].reverse().find((m) => m.role === "user");
    if (!lastUser) {
      return NextResponse.json(
        { error: "No user message found" },
        { status: 400 }
      );
    }

    // ----- Live AI integration placeholder -----
    // To enable live AI, set the appropriate env var and call the
    // server-side SDK. Example using z-ai-web-dev-sdk:
    //
    //   import ZAI from "z-ai-web-dev-sdk";
    //   const zai = await ZAI.create();
    //   const completion = await zai.llm.chat({
    //     messages: [
    //       { role: "system", content: SYSTEM_PROMPT },
    //       ...messages,
    //     ],
    //     temperature: 0.3,
    //   });
    //   const reply = completion.choices[0]?.message?.content ?? "";
    //   return NextResponse.json({ reply, verified: false, sources: [] });
    //
    // The API key is read by the SDK from the server environment —
    // it never appears in client-side code.

    const hasProviderKey = Boolean(process.env.ZAI_API_KEY || process.env.OPENAI_API_KEY);

    if (hasProviderKey) {
      // ---- Live path: forward to provider here (see placeholder above) ----
      // For the demo build we still fall through to the KB-augmented response
      // to keep the response deterministic and offline-safe.
    }

    // ----- Fallback: verified-KB augmented response -----
    const matches = searchKB(lastUser.content);
    const topMatches = matches.slice(0, 3);

    let reply: string;
    let verified: boolean;
    const sources: { label: string; href?: string }[] = [];

    if (topMatches.length > 0) {
      // We have verified facts — synthesise a response that clearly labels them.
      const verifiedParts = topMatches
        .map((m) => `✓ ${m.answer}`)
        .join("\n\n");
      reply =
        `Here is verified information from the INSTIQUEST knowledge base:\n\n${verifiedParts}\n\n` +
        `This is verified directory data. For anything beyond this — e.g. specific dates, ` +
        `application windows or personalised strategy — I can offer AI-generated guidance, but ` +
        `you must verify it on the official portal before acting on it.\n\n` +
        `Ask me another question or refine your query.`;
      verified = true;
      sources.push({ label: "INSTIQUEST verified KB", href: undefined });
    } else {
      // No verified match — clearly label as AI guidance only.
      reply =
        `I don't have a verified answer for that specific query in my knowledge base. ` +
        `Here is general AI-generated guidance: for admission routes, exam counselling and ` +
        `eligibility, always refer to the official portal of the respective exam or ` +
        `institution. INSTIQUEST directory entries link directly to official websites.\n\n` +
        `If your query relates to a specific exam (JEE Main, NEET, CAT, CLAT, CUET, GATE, ` +
        `etc.) or to mock tests, applications or advertising, please mention it explicitly ` +
        `so I can match it to verified content.`;
      verified = false;
    }

    return NextResponse.json({
      reply,
      verified,
      sources,
      provider: "instiquest-kb-fallback",
      note: "AI guidance. Verify on official portals.",
    });
  } catch (err) {
    return NextResponse.json(
      { error: "Chat request failed", detail: String(err) },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    endpoint: "/api/chat",
    method: "POST",
    description: "Server-side proxy for the INSTIQUEST AI assistant.",
    verifiedKBCount: verifiedKB.length,
    provider: process.env.ZAI_API_KEY || process.env.OPENAI_API_KEY ? "configured" : "fallback (no key set)",
    note: "API keys are read from server environment and never exposed to the frontend.",
  });
}
