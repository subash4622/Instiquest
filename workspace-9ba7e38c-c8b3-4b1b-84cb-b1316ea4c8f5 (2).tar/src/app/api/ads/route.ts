/**
 * INSTIQUEST advertising submission endpoint.
 * -------------------------------------------------------------
 * Receives an institute advertising submission and stores it in the
 * database with status = PENDING. No advertisement is published
 * automatically. An admin must explicitly approve via the admin
 * dashboard (or a future admin API).
 *
 * For the demo build (no DB seed), the endpoint validates input,
 * generates a reference ID and persists to the database when
 * available, otherwise returns a deterministic demo response.
 */

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";

interface AdSubmissionDTO {
  instituteName: string;
  contactEmail: string;
  contactPhone?: string;
  instituteWebsite?: string;
  bannerText: string;
  bannerImage?: string;
  landingUrl?: string;
  campaignStart?: string;
  campaignEnd?: string;
  message?: string;
  submittedBy?: string;
}

function validate(input: Partial<AdSubmissionDTO>): string[] {
  const errs: string[] = [];
  if (!input.instituteName || input.instituteName.trim().length < 3) errs.push("instituteName must be at least 3 characters");
  if (!input.contactEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.contactEmail)) errs.push("contactEmail is invalid");
  if (input.contactPhone && !/^[+]?[\d\s-]{8,15}$/.test(input.contactPhone)) errs.push("contactPhone is invalid");
  if (input.instituteWebsite && !/^https?:\/\/.+\..+/.test(input.instituteWebsite)) errs.push("instituteWebsite must be a valid URL");
  if (input.landingUrl && !/^https?:\/\/.+\..+/.test(input.landingUrl)) errs.push("landingUrl must be a valid URL");
  if (!input.bannerText || input.bannerText.length > 200) errs.push("bannerText is required and must be ≤200 chars");
  if (input.message && input.message.length > 500) errs.push("message must be ≤500 chars");
  if (input.campaignEnd && input.campaignStart && new Date(input.campaignEnd) < new Date(input.campaignStart)) {
    errs.push("campaignEnd must be after campaignStart");
  }
  return errs;
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Partial<AdSubmissionDTO>;
    const errors = validate(body);
    if (errors.length > 0) {
      return NextResponse.json({ error: "Validation failed", details: errors }, { status: 400 });
    }

    const refId = `IQ-AD-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;

    try {
      const created = await db.advertisement.create({
        data: {
          contactEmail: body.contactEmail!,
          contactPhone: body.contactPhone,
          instituteName: body.instituteName!,
          instituteWebsite: body.instituteWebsite,
          bannerText: body.bannerText!,
          bannerImage: body.bannerImage,
          landingUrl: body.landingUrl,
          campaignStart: body.campaignStart,
          campaignEnd: body.campaignEnd,
          message: body.message,
          submittedBy: body.submittedBy,
          status: "PENDING",
        },
      });
      return NextResponse.json({
        ok: true,
        referenceId: created.id,
        status: "PENDING",
        message: "Submission received. Pending admin moderation. No advertisement will be published automatically.",
      }, { status: 201 });
    } catch (dbErr) {
      // DB unavailable — return a demo reference so the UI flow works.
      return NextResponse.json({
        ok: true,
        referenceId: refId,
        status: "PENDING",
        message: "Submission received (demo — database not seeded). Pending admin moderation.",
        demo: true,
      }, { status: 201 });
    }
  } catch (err) {
    return NextResponse.json({ error: "Submission failed", detail: String(err) }, { status: 500 });
  }
}

export async function GET() {
  try {
    const pending = await db.advertisement.count({ where: { status: "PENDING" } });
    const approved = await db.advertisement.count({ where: { status: "APPROVED" } });
    const published = await db.advertisement.count({ where: { status: "PUBLISHED" } });
    return NextResponse.json({ pending, approved, published });
  } catch {
    return NextResponse.json({ pending: 0, approved: 0, published: 0, demo: true });
  }
}
