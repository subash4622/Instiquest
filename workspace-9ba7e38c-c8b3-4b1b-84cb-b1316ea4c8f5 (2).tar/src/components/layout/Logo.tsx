/**
 * INSTIQUEST logo component.
 * -------------------------------------------------------------
 * Primary brand mark: the official INSTIQUEST PNG logo
 * (graduation cap + figure + star + book + classical column
 *  with "InstiQuest™" wordmark, "EXPLORE • PREPARE • EXCEL"
 *  tagline, and the "WEB CREATORS" badge).
 *
 * - `variant="image"` (default): the full 3:2 logo PNG with wordmark
 * - `variant="square"`: a 1:1 square crop of the logo (icon-focused)
 * - `variant="mark"`: tiny square icon (favicon-style)
 */

import { cn } from "@/lib/utils";
import { siteConfig } from "@/data/site-config";

interface LogoProps {
  size?: number;
  showSubtitle?: boolean;
  showWordmark?: boolean;
  className?: string;
  animated?: boolean;
  variant?: "image" | "square" | "mark";
}

export function Logo({
  size = 48,
  showSubtitle = true,
  showWordmark = true,
  className,
  animated = true,
  variant = "image",
}: LogoProps) {
  // Square 1:1 version — used in header, sticky bars, anywhere space is constrained
  if (variant === "square") {
    return (
      <div className={cn("flex items-center select-none", className)}>
        <img
          src="/instiquest-logo-square.png"
          alt="INSTIQUEST logo — graduation cap, figure, star, book and classical column."
          height={size}
          width={size}
          style={{ height: size, width: size }}
          className={cn("object-contain rounded-md", animated && "float-y")}
          draggable={false}
        />
        {showWordmark && showSubtitle && (
          <span className="sr-only">
            {siteConfig.brand} · {siteConfig.tagline}
          </span>
        )}
      </div>
    );
  }

  // Compact favicon-style icon
  if (variant === "mark") {
    return <LogoMark size={size} className={className} animated={animated} />;
  }

  // Full 3:2 logo with wordmark + tagline + WEB CREATORS badge
  return (
    <div className={cn("flex items-center select-none", className)}>
      <img
        src="/instiquest-logo.png"
        alt="INSTIQUEST logo — graduation cap, figure, star, book and classical column. Wordmark: InstiQuest. Tagline: Explore, Prepare, Excel. Badge: WEB CREATORS."
        height={size}
        width={size * 1.5}
        style={{ height: size, width: "auto" }}
        className={cn("object-contain", animated && "float-y")}
        draggable={false}
      />
      {showWordmark && showSubtitle && (
        <span className="sr-only">
          {siteConfig.brand} · {siteConfig.tagline}
        </span>
      )}
    </div>
  );
}

/** Compact icon-only mark — uses the small square cropped version of the official logo. */
export function LogoMark({ size = 36, className, animated = false }: { size?: number; className?: string; animated?: boolean }) {
  return (
    <img
      src="/instiquest-logo-256.png"
      alt="INSTIQUEST logo mark"
      width={size}
      height={size}
      className={cn("object-contain rounded-md", animated && "float-y", className)}
      draggable={false}
    />
  );
}
