"use client";

import { useRouter, type Route } from "@/lib/router";
import { siteConfig } from "@/data/site-config";
import { Logo } from "./Logo";
import { GraduationCap, Mail, MapPin, Phone, Twitter, Linkedin, Youtube, Instagram } from "lucide-react";

const linkGroups: { title: string; links: { label: string; route: Route }[] }[] = [
  {
    title: "Explore",
    links: [
      { label: "Home", route: "home" },
      { label: "Entrance Exams", route: "exams" },
      { label: "Institutions", route: "institutions" },
      { label: "Mock Tests", route: "mock-tests" },
    ],
  },
  {
    title: "Tools",
    links: [
      { label: "Application Guidance", route: "guidance" },
      { label: "AI Assistant", route: "chatbot" },
      { label: "Advertising Portal", route: "advertising" },
      { label: "Student Dashboard", route: "student-dashboard" },
    ],
  },
  {
    title: "Information",
    links: [
      { label: "About & Mission", route: "about" },
      { label: "Contact", route: "contact" },
      { label: "Privacy Policy", route: "privacy" },
      { label: "Terms of Use", route: "terms" },
      { label: "Disclaimer", route: "disclaimer" },
    ],
  },
];

export function Footer() {
  const { navigate } = useRouter();
  return (
    <footer className="mt-auto border-t border-border/60 bg-sidebar/30 backdrop-blur-sm">
      <div className="px-6 py-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
        <div className="lg:col-span-2 space-y-4">
          <Logo size={56} />
          <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-cyan-glow/80">{siteConfig.tagline}</p>
          <p className="text-sm text-muted-foreground max-w-sm">
            A futuristic admission portal aggregating 120+ entrance exams, 100+ institutions, hard-level
            mock tests, an AI assistant and an advertising gateway — with verified data clearly separated
            from AI-generated guidance.
          </p>
          <div className="flex items-center gap-3 pt-2">
            <a href={siteConfig.social.twitter} target="_blank" rel="noopener noreferrer" aria-label="Twitter" className="text-muted-foreground hover:text-cyan-glow transition-colors">
              <Twitter className="h-4 w-4" />
            </a>
            <a href={siteConfig.social.linkedin} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" className="text-muted-foreground hover:text-cyan-glow transition-colors">
              <Linkedin className="h-4 w-4" />
            </a>
            <a href={siteConfig.social.youtube} target="_blank" rel="noopener noreferrer" aria-label="YouTube" className="text-muted-foreground hover:text-cyan-glow transition-colors">
              <Youtube className="h-4 w-4" />
            </a>
            <a href={siteConfig.social.instagram} target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="text-muted-foreground hover:text-cyan-glow transition-colors">
              <Instagram className="h-4 w-4" />
            </a>
          </div>
        </div>
        {linkGroups.map((g) => (
          <div key={g.title}>
            <p className="text-sm font-semibold mb-3 text-foreground">{g.title}</p>
            <ul className="space-y-2">
              {g.links.map((l) => (
                <li key={l.route}>
                  <button
                    onClick={() => navigate(l.route)}
                    className="text-sm text-muted-foreground hover:text-cyan-glow transition-colors text-left"
                  >
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-border/40 px-6 py-5 grid grid-cols-1 md:grid-cols-3 gap-4 text-[11px] text-muted-foreground">
        <div className="flex items-center gap-2">
          <GraduationCap className="h-3 w-3 text-electric" />
          <span>© {siteConfig.year} {siteConfig.brand}. Owned by {siteConfig.owner.name}{siteConfig.owner.approvedForPublication ? "" : " — placeholder, pending approval for publication"}.</span>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 md:justify-center">
          <span className="flex items-center gap-1"><Mail className="h-3 w-3" /> {siteConfig.contact.businessEmail}</span>
          <span className="flex items-center gap-1"><Phone className="h-3 w-3" /> {siteConfig.contact.phoneDisplay}</span>
          <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {siteConfig.contact.address}</span>
        </div>
        <p className="md:text-right">
          Demo build · clearly-labelled demo features are visible in the UI. <button onClick={() => navigate("disclaimer")} className="text-electric hover:underline">Read disclaimer</button>.
        </p>
      </div>
    </footer>
  );
}
