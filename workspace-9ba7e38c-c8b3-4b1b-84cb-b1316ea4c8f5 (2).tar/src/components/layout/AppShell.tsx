"use client";

import { useEffect } from "react";
import { Sidebar } from "./Sidebar";
import { Header } from "./Header";
import { Footer } from "./Footer";
import { useRouter } from "@/lib/router";
import { FloatingVisitWidget } from "@/components/common/VisitCounter";
import { HomePage } from "@/components/pages/HomePage";
import { ExamDirectoryPage } from "@/components/pages/ExamDirectoryPage";
import { InstitutionDirectoryPage } from "@/components/pages/InstitutionDirectoryPage";
import { MockTestListPage } from "@/components/pages/MockTestListPage";
import { MockTestRunner } from "@/components/pages/MockTestRunner";
import { MockTestResultPage } from "@/components/pages/MockTestResultPage";
import { ApplicationGuidancePage } from "@/components/pages/ApplicationGuidancePage";
import { ChatbotPage } from "@/components/pages/ChatbotPage";
import { AdvertisingPortalPage } from "@/components/pages/AdvertisingPortalPage";
import { StudentDashboardPage } from "@/components/pages/StudentDashboardPage";
import { AdminDashboardPage } from "@/components/pages/AdminDashboardPage";
import { AboutPage } from "@/components/pages/AboutPage";
import { ContactPage } from "@/components/pages/ContactPage";
import { PrivacyPage } from "@/components/pages/PrivacyPage";
import { TermsPage } from "@/components/pages/TermsPage";
import { DisclaimerPage } from "@/components/pages/DisclaimerPage";
import { FaqPage } from "@/components/pages/FaqPage";
import { PreviousPapersPage } from "@/components/pages/PreviousPapersPage";
import { TemplateEditorPage } from "@/components/pages/TemplateEditorPage";

export function AppShell() {
  const { route, hydrate } = useRouter();

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  return (
    <div className="min-h-screen flex flex-col bg-background bg-radial-glow">
      <div className="flex flex-1 min-h-0">
        <Sidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <Header />
          <main className="flex-1 min-w-0">
            <RouteRenderer route={route} />
          </main>
          <Footer />
        </div>
      </div>
      {/* Floating live visitor widget — bottom-right corner */}
      <FloatingVisitWidget />
    </div>
  );
}

function RouteRenderer({ route }: { route: string }) {
  switch (route) {
    case "home":
      return <HomePage />;
    case "exams":
      return <ExamDirectoryPage />;
    case "institutions":
      return <InstitutionDirectoryPage />;
    case "mock-tests":
      return <MockTestListPage />;
    case "mock-tests/active":
      return <MockTestRunner />;
    case "mock-tests/result":
      return <MockTestResultPage />;
    case "guidance":
      return <ApplicationGuidancePage />;
    case "chatbot":
      return <ChatbotPage />;
    case "advertising":
      return <AdvertisingPortalPage />;
    case "student-dashboard":
      return <StudentDashboardPage />;
    case "admin":
      return <AdminDashboardPage />;
    case "about":
      return <AboutPage />;
    case "contact":
      return <ContactPage />;
    case "privacy":
      return <PrivacyPage />;
    case "terms":
      return <TermsPage />;
    case "disclaimer":
      return <DisclaimerPage />;
    case "faq":
      return <FaqPage />;
    case "previous-papers":
      return <PreviousPapersPage />;
    case "template-editor":
      return <TemplateEditorPage />;
    default:
      return <HomePage />;
  }
}
