"use client";

import { useRouter } from "@/lib/router";
import { useAuth } from "@/lib/stores";
import { siteConfig } from "@/data/site-config";
import { ISTClock } from "@/components/common/ISTClock";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Search, Bell, User, LogOut, Settings, ChevronDown, GraduationCap, ShieldCheck } from "lucide-react";
import { MobileNav } from "./Sidebar";
import { useState } from "react";

export function Header() {
  const { navigate } = useRouter();
  const user = useAuth((s) => s.user);
  const login = useAuth((s) => s.login);
  const logout = useAuth((s) => s.logout);
  const [q, setQ] = useState("");

  const onSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (q.trim()) {
      navigate("exams", undefined, { q: q.trim() });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/60 bg-background/70 backdrop-blur-xl">
      <div className="flex h-16 items-center gap-3 px-4 lg:px-6">
        <MobileNav />
        {/* Square 1:1 logo — visible on every page (desktop + mobile). Click to go home. */}
        <button
          className="flex items-center shrink-0 rounded-md hover:ring-2 hover:ring-primary/40 transition-all"
          onClick={() => navigate("home")}
          aria-label="INSTIQUEST home"
        >
          <img
            src="/instiquest-logo-square.png"
            alt="INSTIQUEST logo"
            height={36}
            width={36}
            className="object-contain rounded-md"
          />
        </button>

        {/* Search */}
        <form onSubmit={onSearch} className="flex-1 max-w-xl mx-auto hidden sm:block">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search exams, institutions, mock tests…"
              className="pl-9 bg-muted/40 border-border/40 placeholder:text-muted-foreground/70 focus-visible:border-electric focus-visible:ring-electric/30"
              aria-label="Search INSTIQUEST"
            />
          </div>
        </form>

        <div className="ml-auto flex items-center gap-2">
          {/* IST clock — top right corner */}
          <div className="hidden md:flex flex-col items-end px-2 border-l border-r border-border/40 py-0.5">
            <ISTClock compact />
          </div>
          {/* Notifications */}
          <Button variant="ghost" size="icon" className="relative" aria-label="Notifications"
                  onClick={() => navigate("home")}>
            <Bell className="h-4 w-4" />
            <span className="absolute top-1.5 right-1.5 h-1.5 w-1.5 rounded-full bg-accent pulse-glow" />
          </Button>

          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-2 px-2">
                  <Avatar className="h-7 w-7">
                    <AvatarFallback className="bg-gradient-to-br from-electric to-purple-sub text-primary-foreground text-xs font-semibold">
                      {user.name.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <span className="hidden md:inline text-sm">{user.name.split(" ")[0]}</span>
                  <ChevronDown className="h-3 w-3 text-muted-foreground" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 bg-popover/95 backdrop-blur-xl border-border/60">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col gap-1">
                    <p className="text-sm font-medium">{user.name}</p>
                    <p className="text-xs text-muted-foreground">{user.email}</p>
                    <Badge variant="outline" className="w-fit text-[10px] capitalize border-electric/40 text-electric mt-1">
                      {user.role} {user.demo ? "· demo" : ""}
                    </Badge>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate("student-dashboard")}>
                  <User className="mr-2 h-4 w-4" /> Dashboard
                </DropdownMenuItem>
                {user.role === "admin" && (
                  <DropdownMenuItem onClick={() => navigate("admin")}>
                    <ShieldCheck className="mr-2 h-4 w-4" /> Admin Console
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={() => navigate("about")}>
                  <GraduationCap className="mr-2 h-4 w-4" /> About
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate("contact")}>
                  <Settings className="mr-2 h-4 w-4" /> Contact & Support
                </DropdownMenuItem>
                <DropdownMenuItem onClick={logout} className="text-destructive focus:text-destructive">
                  <LogOut className="mr-2 h-4 w-4" /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={() => login("student")} className="text-muted-foreground">
                Sign in
              </Button>
              <Button size="sm" className="glow-button hidden sm:inline-flex" onClick={() => login("student")}>
                Get Started
              </Button>
            </div>
          )}
        </div>
      </div>
      {/* secondary ticker / ownership line */}
      <div className="hidden md:flex h-7 items-center gap-4 px-6 text-[11px] text-muted-foreground border-t border-border/40 bg-muted/10">
        <span className="font-medium text-foreground/80">{siteConfig.brand}</span>
        <span className="text-muted-foreground/50">·</span>
        <span className="text-accent font-semibold tracking-[0.15em] uppercase text-[10px]">{siteConfig.tagline}</span>
        <span className="text-muted-foreground/50">·</span>
        <span>Ownership: {siteConfig.owner.name}{siteConfig.owner.approvedForPublication ? "" : " (placeholder — pending approval)"}</span>
        <span className="ml-auto flex items-center gap-3">
          <ISTClock compact />
          <span className="text-muted-foreground/50">·</span>
          <span>Contact: <a className="text-primary hover:underline" href={`mailto:${siteConfig.contact.businessEmail}`}>{siteConfig.contact.businessEmail}</a></span>
        </span>
      </div>
    </header>
  );
}
