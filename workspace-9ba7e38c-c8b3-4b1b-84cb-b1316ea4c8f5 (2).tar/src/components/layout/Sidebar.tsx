"use client";

import { cn } from "@/lib/utils";
import { Logo } from "./Logo";
import { useRouter, type Route } from "@/lib/router";
import { useAuth, useStudentData } from "@/lib/stores";
import { siteConfig } from "@/data/site-config";
import { Sheet, SheetContent, SheetTrigger, SheetTitle, SheetHeader } from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Home, BookOpen, Building2, Brain, Compass, MessageSquare,
  Megaphone, LayoutDashboard, Shield, Info, Mail, FileText,
  Scale, AlertTriangle, Menu, X, GraduationCap, HelpCircle, FileEdit,
} from "lucide-react";
import { useState } from "react";

interface NavItem {
  route: Route;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
  section?: "main" | "tools" | "resources" | "account" | "info";
  requiresRole?: "admin" | "institute" | "owner";
}

export function Sidebar() {
  const { route, navigate } = useRouter();
  const user = useAuth((s) => s.user);
  const savedCount = useStudentData((s) => s.savedExams.length);

  const items: NavItem[] = [
    { route: "home", label: "Home", icon: Home, section: "main" },
    { route: "exams", label: "Entrance Exams", icon: BookOpen, section: "main" },
    { route: "institutions", label: "Institutions", icon: Building2, section: "main" },
    { route: "mock-tests", label: "Mock Tests", icon: Brain, section: "tools" },
    { route: "guidance", label: "Application Guidance", icon: Compass, section: "tools" },
    { route: "chatbot", label: "AI Assistant", icon: MessageSquare, section: "tools" },
    { route: "advertising", label: "Advertising Portal", icon: Megaphone, section: "tools", requiresRole: "institute" },
    { route: "previous-papers", label: "Previous Year Papers", icon: FileText, section: "resources" },
    { route: "faq", label: "FAQs", icon: HelpCircle, section: "resources" },
    { route: "student-dashboard", label: "Student Dashboard", icon: LayoutDashboard, section: "account", badge: savedCount || undefined },
    { route: "admin", label: "Admin Dashboard", icon: Shield, section: "account", requiresRole: "admin" },
    { route: "template-editor", label: "Template Editor", icon: FileEdit, section: "account", requiresRole: "owner" },
    { route: "about", label: "About & Mission", icon: Info, section: "info" },
    { route: "contact", label: "Contact", icon: Mail, section: "info" },
    { route: "privacy", label: "Privacy Policy", icon: FileText, section: "info" },
    { route: "terms", label: "Terms of Use", icon: Scale, section: "info" },
    { route: "disclaimer", label: "Disclaimer", icon: AlertTriangle, section: "info" },
  ];

  const sectionTitles: Record<string, string> = {
    main: "Explore",
    tools: "Tools",
    resources: "Resources",
    account: "Account",
    info: "Information",
  };
  const sectionOrder = ["main", "tools", "resources", "account", "info"];

  const filterItem = (it: NavItem) => {
    if (!it.requiresRole) return true;
    if (!user) return false; // gated
    if (it.requiresRole === "owner") return user.role === "owner";
    if (it.requiresRole === "admin") return user.role === "admin" || user.role === "owner";
    if (it.requiresRole === "institute") return user.role === "institute" || user.role === "admin" || user.role === "owner";
    return true;
  };

  return (
    <aside className="hidden lg:flex h-screen sticky top-0 w-[260px] flex-col border-r border-border/60 bg-sidebar/80 backdrop-blur-xl">
      <div className="px-5 py-5 border-b border-border/60">
        <button onClick={() => navigate("home")} className="w-full text-left" aria-label="Go to home">
          <Logo size={40} />
        </button>
      </div>
      <ScrollArea className="flex-1 px-3 py-4">
        <nav className="space-y-6">
          {sectionOrder.map((sec) => {
            const items2 = items.filter((i) => i.section === sec && filterItem(i));
            if (!items2.length) return null;
            return (
              <div key={sec}>
                <p className="px-3 mb-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">
                  {sectionTitles[sec]}
                </p>
                <ul className="space-y-1">
                  {items2.map((it) => {
                    const active = route === it.route || route.startsWith(it.route + "/");
                    const Icon = it.icon;
                    return (
                      <li key={it.route}>
                        <button
                          onClick={() => navigate(it.route)}
                          className={cn(
                            "group w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-all",
                            active
                              ? "bg-gradient-to-r from-electric/20 via-cyan-glow/10 to-transparent text-foreground border-l-2 border-electric"
                              : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground"
                          )}
                          aria-current={active ? "page" : undefined}
                        >
                          <Icon className={cn("h-4 w-4 shrink-0", active ? "text-electric" : "text-muted-foreground group-hover:text-cyan-glow")} />
                          <span className="flex-1 text-left">{it.label}</span>
                          {it.badge ? (
                            <Badge className="bg-electric/20 text-cyan-glow border-electric/40 text-[10px] h-5 px-1.5">
                              {it.badge}
                            </Badge>
                          ) : null}
                          {it.requiresRole === "admin" ? (
                            <Shield className="h-3 w-3 text-purple-sub" />
                          ) : null}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </div>
            );
          })}
        </nav>
      </ScrollArea>
      <div className="px-4 py-3 border-t border-border/60 text-[10px] text-muted-foreground">
        <p className="flex items-center gap-1.5">
          <GraduationCap className="h-3 w-3 text-electric" />
          <span>v{siteConfig.version} · {siteConfig.year}</span>
        </p>
        <p className="mt-1">© {siteConfig.owner.name}</p>
      </div>
    </aside>
  );
}

export function MobileNav() {
  const [open, setOpen] = useState(false);
  const { route, navigate } = useRouter();
  const user = useAuth((s) => s.user);
  const savedCount = useStudentData((s) => s.savedExams.length);
  const logout = useAuth((s) => s.logout);
  const login = useAuth((s) => s.login);

  const items: NavItem[] = [
    { route: "home", label: "Home", icon: Home },
    { route: "exams", label: "Entrance Exams", icon: BookOpen },
    { route: "institutions", label: "Institutions", icon: Building2 },
    { route: "mock-tests", label: "Mock Tests", icon: Brain },
    { route: "guidance", label: "Application Guidance", icon: Compass },
    { route: "chatbot", label: "AI Assistant", icon: MessageSquare },
    { route: "advertising", label: "Advertising Portal", icon: Megaphone },
    { route: "previous-papers", label: "Previous Year Papers", icon: FileText },
    { route: "faq", label: "FAQs", icon: HelpCircle },
    { route: "student-dashboard", label: "Student Dashboard", icon: LayoutDashboard, badge: savedCount || undefined },
    { route: "admin", label: "Admin Dashboard", icon: Shield, requiresRole: "admin" },
    { route: "template-editor", label: "Template Editor", icon: FileEdit, requiresRole: "owner" },
    { route: "about", label: "About & Mission", icon: Info },
    { route: "contact", label: "Contact", icon: Mail },
    { route: "privacy", label: "Privacy Policy", icon: FileText },
    { route: "terms", label: "Terms of Use", icon: Scale },
    { route: "disclaimer", label: "Disclaimer", icon: AlertTriangle },
  ];

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="lg:hidden text-foreground" aria-label="Open navigation menu">
          <Menu className="h-5 w-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[280px] bg-sidebar/95 backdrop-blur-xl border-border/60 p-0">
        <SheetHeader className="px-5 py-5 border-b border-border/60">
          <SheetTitle asChild>
            <div><Logo size={36} /></div>
          </SheetTitle>
        </SheetHeader>
        <ScrollArea className="h-[calc(100vh-100px)] px-3 py-4">
          <nav className="space-y-1">
            {items.filter((it) => {
              if (!it.requiresRole) return true;
              if (!user) return false;
              if (it.requiresRole === "owner") return user.role === "owner";
              if (it.requiresRole === "admin") return user.role === "admin" || user.role === "owner";
              if (it.requiresRole === "institute") return ["institute", "admin", "owner"].includes(user.role);
              return true;
            }).map((it) => {
              const active = route === it.route || route.startsWith(it.route + "/");
              const Icon = it.icon;
              return (
                <button
                  key={it.route}
                  onClick={() => {
                    navigate(it.route);
                    setOpen(false);
                  }}
                  className={cn(
                    "w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors",
                    active ? "bg-electric/15 text-foreground" : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground"
                  )}
                >
                  <Icon className="h-4 w-4" />
                  <span className="flex-1 text-left">{it.label}</span>
                  {it.badge ? <Badge className="bg-electric/20 text-cyan-glow text-[10px] h-5 px-1.5">{it.badge}</Badge> : null}
                </button>
              );
            })}
          </nav>
          <div className="mt-6 pt-4 border-t border-border/60">
            {user ? (
              <div className="space-y-2">
                <div className="px-3 py-2 rounded-lg bg-sidebar-accent/40">
                  <p className="text-xs text-muted-foreground">Signed in as</p>
                  <p className="text-sm font-medium">{user.name}</p>
                  <Badge variant="outline" className="mt-1 text-[10px] capitalize border-electric/40 text-electric">
                    {user.role} {user.demo ? "· demo" : ""}
                  </Badge>
                </div>
                <Button variant="outline" size="sm" className="w-full" onClick={logout}>Sign out</Button>
              </div>
            ) : (
              <div className="space-y-2">
                <Button className="w-full glow-button" size="sm" onClick={() => login("student")}>Continue as Student (demo)</Button>
                <Button variant="outline" size="sm" className="w-full" onClick={() => login("institute")}>Institute Rep (demo)</Button>
                <Button variant="ghost" size="sm" className="w-full text-muted-foreground" onClick={() => login("admin")}>Admin (demo)</Button>
              </div>
            )}
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}

export { X };
