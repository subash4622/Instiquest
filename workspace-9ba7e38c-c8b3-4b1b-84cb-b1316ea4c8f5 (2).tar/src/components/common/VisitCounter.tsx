"use client";

import { useState, useEffect } from "react";
import { Eye, TrendingUp, Users } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Visitor counter — demo, client-side.
 * -------------------------------------------------------------
 * Tracks visit counts in localStorage (key `instiquest-visits`):
 *   { total, today, lastVisitDate, sessionStart }
 *
 * In production, replace this with calls to a real analytics
 * backend (e.g., /api/visits). The UI contract stays the same.
 */

interface VisitData {
  total: number;
  today: number;
  lastVisitDate: string;   // YYYY-MM-DD
  sessions: number;        // unique browser sessions
}

const KEY = "instiquest-visits";

function todayStr(): string {
  return new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" });
}

function loadVisits(): VisitData {
  if (typeof window === "undefined") {
    return { total: 0, today: 0, lastVisitDate: todayStr(), sessions: 0 };
  }
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) {
      return { total: 0, today: 0, lastVisitDate: "", sessions: 0 };
    }
    return JSON.parse(raw) as VisitData;
  } catch {
    return { total: 0, today: 0, lastVisitDate: "", sessions: 0 };
  }
}

function saveVisits(v: VisitData) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(KEY, JSON.stringify(v));
  } catch {
    /* ignore quota */
  }
}

/**
 * On mount: increment total visits. If the visit date is today,
 * also increment `today`. If the date changed, reset `today` to 1.
 */
function useVisitTracking() {
  const [data, setData] = useState<VisitData>({ total: 0, today: 0, lastVisitDate: "", sessions: 0 });

  useEffect(() => {
    const cur = loadVisits();
    const today = todayStr();
    const isNewDay = cur.lastVisitDate !== today;
    const next: VisitData = {
      total: cur.total + 1,
      today: isNewDay ? 1 : cur.today + 1,
      lastVisitDate: today,
      sessions: cur.sessions + 1,
    };
    saveVisits(next);
    // Defer setState to avoid synchronous-in-effect warning
    Promise.resolve().then(() => setData(next));
  }, []);

  return data;
}

/** Compact pill — shown in the homepage hero or stats row. */
export function VisitCounterPill({ className }: { className?: string }) {
  const v = useVisitTracking();
  return (
    <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-muted/30 border border-border/40 text-xs", className)}>
      <Eye className="h-3 w-3 text-accent" />
      <span className="text-foreground font-semibold tabular-nums">{v.total.toLocaleString("en-IN")}</span>
      <span className="text-muted-foreground">total visits</span>
    </span>
  );
}

/** Stat block set — total / today / sessions. */
export function VisitStats({ className }: { className?: string }) {
  const v = useVisitTracking();
  return (
    <div className={cn("grid grid-cols-3 gap-2", className)}>
      <div className="rounded-lg bg-muted/30 p-3 text-center">
        <Eye className="h-4 w-4 mx-auto text-accent mb-1" />
        <p className="text-lg font-bold text-foreground tabular-nums">{v.total.toLocaleString("en-IN")}</p>
        <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Total visits</p>
      </div>
      <div className="rounded-lg bg-muted/30 p-3 text-center">
        <TrendingUp className="h-4 w-4 mx-auto text-primary mb-1" />
        <p className="text-lg font-bold text-foreground tabular-nums">{v.today.toLocaleString("en-IN")}</p>
        <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Today</p>
      </div>
      <div className="rounded-lg bg-muted/30 p-3 text-center">
        <Users className="h-4 w-4 text-primary mb-1 mx-auto" />
        <p className="text-lg font-bold text-foreground tabular-nums">{v.sessions.toLocaleString("en-IN")}</p>
        <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Sessions</p>
      </div>
    </div>
  );
}

/** Tiny floating corner widget — live visitor count. */
export function FloatingVisitWidget() {
  const v = useVisitTracking();
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    // Show after a short delay to avoid flash
    const t = setTimeout(() => setVisible(true), 800);
    return () => clearTimeout(t);
  }, []);
  if (!visible) return null;
  return (
    <div
      className="fixed bottom-4 right-4 z-40 glass-card rounded-full px-3 py-1.5 text-xs flex items-center gap-2 animate-in-up shadow-lg"
      role="status"
      aria-live="polite"
    >
      <span className="h-2 w-2 rounded-full bg-emerald-400 pulse-glow" aria-hidden />
      <Eye className="h-3 w-3 text-accent" />
      <span className="font-semibold text-foreground tabular-nums">{v.total.toLocaleString("en-IN")}</span>
      <span className="text-muted-foreground hidden sm:inline">visits</span>
    </div>
  );
}
