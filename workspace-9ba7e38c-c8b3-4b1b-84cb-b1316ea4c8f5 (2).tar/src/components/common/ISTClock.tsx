"use client";

import { useState, useEffect } from "react";
import { Clock } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Live Indian Standard Time (IST, UTC+5:30) clock.
 * Updates every second. Display-only.
 */
export function ISTClock({ className, compact = false }: { className?: string; compact?: boolean }) {
  const [now, setNow] = useState<string>("");
  const [date, setDate] = useState<string>("");

  useEffect(() => {
    const update = () => {
      const d = new Date();
      // Convert to IST (UTC+5:30) regardless of the viewer's timezone
      const utcMs = d.getTime() + d.getTimezoneOffset() * 60_000;
      const ist = new Date(utcMs + 5.5 * 60 * 60_000);
      const time = ist.toLocaleTimeString("en-IN", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
        timeZone: "Asia/Kolkata",
      });
      const day = ist.toLocaleDateString("en-IN", {
        weekday: "short",
        day: "2-digit",
        month: "short",
        year: "numeric",
        timeZone: "Asia/Kolkata",
      });
      setNow(time);
      setDate(day);
    };
    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }, []);

  if (compact) {
    return (
      <span className={cn("inline-flex items-center gap-1.5 font-mono text-xs", className)}>
        <Clock className="h-3 w-3 text-accent" />
        <span className="text-foreground">{now}</span>
        <span className="text-muted-foreground">IST</span>
      </span>
    );
  }

  return (
    <div className={cn("inline-flex flex-col items-end leading-tight", className)}>
      <span className="inline-flex items-center gap-1.5 font-mono text-sm">
        <Clock className="h-3.5 w-3.5 text-accent" />
        <span className="text-foreground tabular-nums">{now}</span>
        <span className="text-[10px] text-muted-foreground uppercase tracking-wider">IST</span>
      </span>
      <span className="text-[10px] text-muted-foreground">{date}</span>
    </div>
  );
}
