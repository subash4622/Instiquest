"use client";

import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, AlertTriangle, Sparkles } from "lucide-react";

/** Verified badge — clearly distinguish verified directory information. */
export function VerifiedBadge({ className, label = "Verified" }: { className?: string; label?: string }) {
  return (
    <Badge className={cn("verified-badge text-white border-0 gap-1 text-[10px] px-2 py-0.5", className)}>
      <CheckCircle2 className="h-3 w-3" />
      {label}
    </Badge>
  );
}

/** Unverified badge — clearly flag content pending editorial review. */
export function UnverifiedBadge({ className, label = "Unverified — pending review" }: { className?: string; label?: string }) {
  return (
    <Badge variant="outline" className={cn("text-amber-300 border-amber-500/40 bg-amber-500/10 gap-1 text-[10px] px-2 py-0.5", className)}>
      <AlertTriangle className="h-3 w-3" />
      {label}
    </Badge>
  );
}

/** AI-generated guidance badge — distinguishes AI from verified info. */
export function AIBadge({ className, label = "AI Guidance" }: { className?: string; label?: string }) {
  return (
    <Badge className={cn("ai-badge text-white border-0 gap-1 text-[10px] px-2 py-0.5", className)}>
      <Sparkles className="h-3 w-3" />
      {label}
    </Badge>
  );
}

/** Demo badge — labels features that are clearly demo. */
export function DemoBadge({ className, label = "Demo" }: { className?: string; label?: string }) {
  return (
    <Badge variant="outline" className={cn("text-purple-300 border-purple-500/40 bg-purple-500/10 text-[10px] px-2 py-0.5", className)}>
      {label}
    </Badge>
  );
}

/** Stat display block. */
export function StatBlock({
  label, value, icon: Icon, accent = "electric",
}: {
  label: string;
  value: React.ReactNode;
  icon?: React.ComponentType<{ className?: string }>;
  accent?: "electric" | "cyan" | "purple";
}) {
  const accentColor =
    accent === "cyan" ? "text-cyan-glow" : accent === "purple" ? "text-purple-sub" : "text-electric";
  return (
    <div className="glass-card rounded-xl p-4">
      <div className="flex items-center justify-between mb-1">
        <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
        {Icon && <Icon className={cn("h-4 w-4", accentColor)} />}
      </div>
      <p className={cn("text-2xl font-bold", accentColor)}>{value}</p>
    </div>
  );
}

/** Empty state component. */
export function EmptyState({
  title, description, icon: Icon, action,
}: {
  title: string;
  description?: string;
  icon?: React.ComponentType<{ className?: string }>;
  action?: React.ReactNode;
}) {
  return (
    <div className="text-center py-16 px-4">
      {Icon && (
        <div className="mx-auto mb-4 w-16 h-16 rounded-full bg-muted/30 flex items-center justify-center">
          <Icon className="h-8 w-8 text-muted-foreground" />
        </div>
      )}
      <h3 className="text-lg font-semibold mb-1">{title}</h3>
      {description && <p className="text-sm text-muted-foreground max-w-md mx-auto">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

/** Loading skeleton grid. */
export function LoadingGrid({ count = 6, className }: { count?: number; className?: string }) {
  return (
    <div className={cn("grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4", className)}>
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="glass-card rounded-xl p-4 space-y-3">
          <div className="h-4 w-1/2 shimmer rounded" />
          <div className="h-3 w-full shimmer rounded" />
          <div className="h-3 w-2/3 shimmer rounded" />
          <div className="h-8 w-full shimmer rounded mt-2" />
        </div>
      ))}
    </div>
  );
}

/** Section heading with optional accent. */
export function SectionHeading({
  eyebrow, title, description, action,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
      <div>
        {eyebrow && (
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-electric mb-2">{eyebrow}</p>
        )}
        <h2 className="text-2xl md:text-3xl font-bold text-gradient-static">{title}</h2>
        {description && <p className="mt-2 text-sm text-muted-foreground max-w-2xl">{description}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}
