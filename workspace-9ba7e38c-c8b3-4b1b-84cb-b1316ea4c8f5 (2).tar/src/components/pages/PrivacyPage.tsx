"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SectionHeading } from "@/components/common/ui-bits";
import { Shield, Database, Cookie, Eye, UserX, Mail } from "lucide-react";

const sections = [
  {
    icon: Database,
    title: "1. Information we collect",
    body: "INSTIQUEST collects only the minimal information needed to provide the admission portal: the email address and display name you provide at sign-in, your saved exams, bookmarks, mock-test results and application tracking data. Chat thread content is stored locally in your browser unless you sign in, in which case it may be persisted server-side. We do NOT collect sensitive personal data such as passwords in plain text — authentication is handled via hashed credentials through a server-side provider.",
  },
  {
    icon: Cookie,
    title: "2. Cookies and local storage",
    body: "We use browser local storage to keep you signed in (your opaque session), remember your saved exams and bookmarks between sessions, and persist your chat thread. We do not use third-party advertising cookies. Clearing your browser storage will remove all locally-stored INSTIQUEST data.",
  },
  {
    icon: Eye,
    title: "3. How we use your information",
    body: "Your data is used solely to: (a) display your personalised dashboard, saved items and mock-test history; (b) respond to messages you send via the contact form; (c) moderate institute advertising submissions; (d) improve the relevance of search results and AI guidance. We never sell your data to third parties.",
  },
  {
    icon: UserX,
    title: "4. AI chatbot data",
    body: "When you use the AI assistant, the text of your messages is sent to a server-side AI provider via a secure proxy. The provider may retain transcripts per its own retention policy. API keys are NEVER exposed in the frontend. AI responses are clearly labelled as guidance and are distinct from verified directory data.",
  },
  {
    icon: Shield,
    title: "5. Advertising submissions",
    body: "Institute advertising submissions (contact details, banner copy, campaign dates) are stored in a moderation queue. They are not published automatically. An admin must explicitly approve each submission before it appears anywhere on the site. Submissions remain in our records for audit purposes even if rejected.",
  },
  {
    icon: Mail,
    title: "6. Your rights",
    body: "You can request access to, correction of, or deletion of your personal data at any time by contacting the business email listed in the site footer. Because authentication in this build is a clearly-labelled demo, your local data is fully under your control via browser storage management.",
  },
];

export function PrivacyPage() {
  return (
    <div className="px-4 lg:px-10 py-10 max-w-4xl mx-auto animate-in-fade">
      <SectionHeading
        eyebrow="Legal"
        title="Privacy Policy"
        description="How INSTIQUEST collects, uses and protects your information. This is a draft policy for the demo build — replace it with a reviewed version before launch."
      />
      <Card className="glass-card p-4 mb-6 text-xs text-muted-foreground flex items-start gap-2">
        <Badge variant="outline" className="border-amber-500/40 text-amber-300 bg-amber-500/10 text-[10px] shrink-0">Draft</Badge>
        <p>This privacy policy is a template. Have it reviewed by a qualified legal professional before deploying INSTIQUEST to production.</p>
      </Card>
      <div className="space-y-5">
        {sections.map((s) => (
          <Card key={s.title} className="glass-card glass-card-hover p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="h-9 w-9 rounded-lg bg-electric/20 flex items-center justify-center shrink-0">
                <s.icon className="h-4 w-4 text-electric" />
              </div>
              <h2 className="text-base font-semibold">{s.title}</h2>
            </div>
            <CardContent className="p-0 text-sm text-muted-foreground leading-relaxed">{s.body}</CardContent>
          </Card>
        ))}
        <Card className="glass-card p-5 text-sm text-muted-foreground">
          <p>For privacy-related questions, contact the business email in the footer. Last updated: <span className="text-foreground">November 2026</span>.</p>
        </Card>
      </div>
    </div>
  );
}
