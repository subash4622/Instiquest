"use client";

import { useState, useEffect, useMemo, useRef } from "react";
import { useRouter } from "@/lib/router";
import { getMockTestById, type MockQuestion } from "@/data/mock-tests";
import { useMockSession, useStudentData } from "@/lib/stores";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Clock, Flag, ChevronLeft, ChevronRight, AlertTriangle, CheckCircle2,
  Circle, Send, Eye, EyeOff, ArrowLeft, ListChecks, Timer,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function MockTestRunner() {
  const { param, navigate } = useRouter();
  const test = param ? getMockTestById(param) : undefined;
  const session = useMockSession();
  const addMockResult = useStudentData((s) => s.addMockResult);

  // Question-level timing
  const questionStartRef = useRef<number>(Date.now());

  // Initialize session
  useEffect(() => {
    if (test && !session.mockTestId) {
      session.start(test.id, test.totalDurationMinutes, test.sections[0].id);
      questionStartRef.current = Date.now();
    }
  }, [test, session.mockTestId]);

  // Countdown
  const [remainingSec, setRemainingSec] = useState(0);
  const submitTestRef = useRef<() => void>(() => {});
  useEffect(() => {
    if (!session.endsAt) return;
    const tick = () => {
      const rem = Math.max(0, Math.floor((session.endsAt! - Date.now()) / 1000));
      setRemainingSec(rem);
      if (rem <= 0) {
        submitTestRef.current();
      }
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [session.endsAt]);

  if (!test) {
    return (
      <div className="px-4 py-16 text-center">
        <p className="text-muted-foreground">Mock test not found.</p>
        <Button className="mt-4" onClick={() => navigate("mock-tests")}>Back to mock tests</Button>
      </div>
    );
  }

  if (!session.mockTestId) {
    return (
      <div className="px-4 py-16 text-center">
        <div className="h-8 w-8 mx-auto border-2 border-electric border-t-transparent animate-spin rounded-full" />
        <p className="text-sm text-muted-foreground mt-3">Preparing your test…</p>
      </div>
    );
  }

  const section = test.sections.find((s) => s.id === session.currentSectionId) ?? test.sections[0];
  const sectionQuestions = test.questions.filter((q) => q.sectionId === section.id);
  const currentQ = sectionQuestions[session.currentIndex];

  const recordCurrent = (patch: Partial<Parameters<typeof session.recordAnswer>[1]>) => {
    if (!currentQ) return;
    const elapsed = Math.floor((Date.now() - questionStartRef.current) / 1000);
    session.recordAnswer(currentQ.id, { ...patch, timeSpentSec: elapsed });
  };

  const selectOption = (optIdx: number) => {
    if (!currentQ) return;
    const existing = session.answers[currentQ.id];
    let next: number[] = [];
    if (currentQ.type === "multiple") {
      const cur = existing?.selectedOptions ?? [];
      next = cur.includes(optIdx) ? cur.filter((i) => i !== optIdx) : [...cur, optIdx].sort();
    } else {
      next = [optIdx];
    }
    const status = (existing?.status === "marked-for-review" || existing?.status === "answered-marked") ? "answered-marked" : "answered";
    recordCurrent({ selectedOptions: next, status });
  };

  const setNumerical = (val: string) => {
    if (!currentQ) return;
    const num = val === "" ? undefined : Number(val);
    const existing = session.answers[currentQ.id];
    const status = (existing?.status === "marked-for-review" || existing?.status === "answered-marked") ? "answered-marked" : "answered";
    recordCurrent({ numericalAnswer: num, status });
  };

  const toggleMark = () => {
    if (!currentQ) return;
    const existing = session.answers[currentQ.id];
    const isAnswered = existing && (existing.status === "answered" || existing.status === "answered-marked");
    const nextStatus = isAnswered ? "answered-marked" : "marked-for-review";
    recordCurrent({ status: nextStatus });
  };

  const goNext = () => {
    const nextIdx = session.currentIndex + 1;
    if (nextIdx < sectionQuestions.length) {
      questionStartRef.current = Date.now();
      session.setIndex(nextIdx);
    } else {
      // Move to next section
      const secIdx = test.sections.findIndex((s) => s.id === session.currentSectionId);
      if (secIdx + 1 < test.sections.length) {
        session.setSection(test.sections[secIdx + 1].id);
        questionStartRef.current = Date.now();
      }
    }
  };

  const goPrev = () => {
    if (session.currentIndex > 0) {
      session.setIndex(session.currentIndex - 1);
      questionStartRef.current = Date.now();
    } else {
      const secIdx = test.sections.findIndex((s) => s.id === session.currentSectionId);
      if (secIdx - 1 >= 0) {
        const prevSec = test.sections[secIdx - 1];
        const prevQs = test.questions.filter((q) => q.sectionId === prevSec.id);
        session.setSection(prevSec.id);
        session.setIndex(prevQs.length - 1);
        questionStartRef.current = Date.now();
      }
    }
  };

  const answeredCount = test.questions.filter((q) => {
    const a = session.answers[q.id];
    return a && (a.status === "answered" || a.status === "answered-marked");
  }).length;
  const markedCount = test.questions.filter((q) => {
    const a = session.answers[q.id];
    return a && (a.status === "marked-for-review" || a.status === "answered-marked");
  }).length;

  function submitTest() {
    if (!test) return;
    // Calculate score
    let scoredMarks = 0, correct = 0, wrong = 0, unattempted = 0;
    const perSection = test.sections.map((s) => ({
      sectionId: s.id, name: s.name, scored: 0, total: 0, correct: 0, wrong: 0, unattempted: 0,
    }));
    const perQuestion: { questionId: string; correct: boolean; scored: number; chosen: number[]; correctAnswers: number[]; timeSpentSec: number; unattempted: boolean }[] = [];

    for (const q of test.questions) {
      const ans = session.answers[q.id];
      const secStat = perSection.find((ps) => ps.sectionId === q.sectionId)!;
      secStat.total += q.marks;
      const isAnswered = ans && (ans.status === "answered" || ans.status === "answered-marked") && (ans.selectedOptions.length > 0 || ans.numericalAnswer !== undefined);
      if (!isAnswered) {
        unattempted++;
        secStat.unattempted++;
        perQuestion.push({ questionId: q.id, correct: false, scored: 0, chosen: [], correctAnswers: q.correct, timeSpentSec: ans?.timeSpentSec ?? 0, unattempted: true });
        continue;
      }
      // Check correctness
      let isCorrect = false;
      if (q.type === "numerical") {
        const val = ans!.numericalAnswer ?? NaN;
        const tol = q.tolerance ?? 0;
        isCorrect = Math.abs(val - (q.numericalAnswer ?? NaN)) <= tol;
      } else if (q.type === "multiple") {
        const chosen = [...ans!.selectedOptions].sort().join(",");
        const correctStr = [...q.correct].sort().join(",");
        isCorrect = chosen === correctStr && chosen !== "";
      } else {
        isCorrect = ans!.selectedOptions.length === 1 && q.correct.includes(ans!.selectedOptions[0]);
      }
      if (isCorrect) {
        scoredMarks += q.marks; correct++; secStat.scored += q.marks; secStat.correct++;
        perQuestion.push({ questionId: q.id, correct: true, scored: q.marks, chosen: ans!.selectedOptions, correctAnswers: q.correct, timeSpentSec: ans!.timeSpentSec ?? 0, unattempted: false });
      } else {
        scoredMarks -= q.negativeMarks; wrong++; secStat.scored -= q.negativeMarks; secStat.wrong++;
        perQuestion.push({ questionId: q.id, correct: false, scored: -q.negativeMarks, chosen: ans!.selectedOptions, correctAnswers: q.correct, timeSpentSec: ans!.timeSpentSec ?? 0, unattempted: false });
      }
    }

    const accuracy = (correct + wrong) > 0 ? (correct / (correct + wrong)) * 100 : 0;
    const durationSec = session.startedAt ? Math.floor((Date.now() - session.startedAt) / 1000) : 0;

    const result = {
      mockTestId: test.id,
      mockTestTitle: test.title,
      scoredMarks: Math.max(0, scoredMarks),
      totalMarks: test.totalMarks,
      accuracy: Math.round(accuracy * 10) / 10,
      correct,
      wrong,
      unattempted,
      durationSec,
      perSection,
      perQuestion,
    };

    // Save to student dashboard
    addMockResult({
      id: `result-${Date.now()}`,
      mockTestId: test.id,
      mockTestTitle: test.title,
      scoredMarks: result.scoredMarks,
      totalMarks: result.totalMarks,
      accuracy: result.accuracy,
      takenAt: Date.now(),
      durationSec,
    });

    session.finish(result);
    navigate("mock-tests/result");
  }
  submitTestRef.current = submitTest;

  const fmtTime = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;
  const totalRemainingPct = session.endsAt ? ((session.endsAt - Date.now()) / 1000 / (test.totalDurationMinutes * 60)) * 100 : 0;
  const isLow = remainingSec <= 60;

  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col animate-in-fade">
      {/* Test header */}
      <div className="border-b border-border/60 bg-sidebar/40 backdrop-blur-md px-4 lg:px-6 py-3 flex flex-wrap items-center gap-3">
        <div className="flex-1 min-w-0">
          <p className="text-xs text-muted-foreground">{test.category}</p>
          <p className="text-sm font-semibold truncate">{test.title}</p>
        </div>
        <div className={cn("flex items-center gap-2 px-3 py-1.5 rounded-md font-mono text-sm", isLow ? "bg-destructive/15 text-destructive" : "bg-muted/30")}>
          <Timer className={cn("h-4 w-4", isLow && "animate-pulse")} />
          {fmtTime(remainingSec)}
        </div>
        <Button variant="ghost" size="sm" onClick={() => navigate("mock-tests")} className="text-xs">
          <ArrowLeft className="h-3 w-3 mr-1" /> Exit
        </Button>
      </div>

      <div className="flex flex-1 min-h-0">
        {/* Main question area */}
        <div className="flex-1 flex flex-col min-w-0 p-4 lg:p-6">
          {/* Section tabs */}
          <div className="flex flex-wrap gap-2 mb-4">
            {test.sections.map((s) => {
              const active = s.id === session.currentSectionId;
              return (
                <button
                  key={s.id}
                  onClick={() => { session.setSection(s.id); questionStartRef.current = Date.now(); }}
                  className={cn("px-3 py-1.5 rounded-md text-xs transition-colors border",
                    active ? "bg-electric/20 border-electric text-foreground" : "border-border/60 text-muted-foreground hover:bg-muted/30")}
                >
                  {s.name}
                </button>
              );
            })}
          </div>

          {/* Progress */}
          <div className="mb-4">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-muted-foreground">Question {session.currentIndex + 1} of {sectionQuestions.length} · Section: {section.name}</span>
              <span className="text-muted-foreground">{answeredCount}/{test.questions.length} answered · {markedCount} marked</span>
            </div>
            <Progress value={totalRemainingPct} className="h-1" />
          </div>

          {/* Question card */}
          {currentQ && (
            <Card className="glass-card flex-1 p-5 lg:p-6">
              <div className="flex flex-wrap items-start gap-2 mb-3">
                <Badge variant="outline" className="text-[10px] border-electric/40 text-electric">Q{session.currentIndex + 1}</Badge>
                <Badge variant="outline" className="text-[10px]">{currentQ.topic}</Badge>
                <Badge variant="outline" className="text-[10px] capitalize">{currentQ.difficulty}</Badge>
                <Badge variant="outline" className="text-[10px] capitalize">{currentQ.type.replace("-", " ")}</Badge>
                <div className="ml-auto text-[11px] text-muted-foreground">
                  +{currentQ.marks} / −{currentQ.negativeMarks}
                </div>
              </div>
              <p className="text-base leading-relaxed mb-5">{currentQ.question}</p>

              {/* Options / Numerical */}
              {currentQ.type === "numerical" ? (
                <div className="space-y-2 max-w-xs">
                  <label className="text-xs text-muted-foreground">Enter your numerical answer</label>
                  <input
                    type="number"
                    step="any"
                    value={session.answers[currentQ.id]?.numericalAnswer ?? ""}
                    onChange={(e) => setNumerical(e.target.value)}
                    className="w-full h-11 px-3 rounded-md bg-muted/30 border border-border/60 text-sm focus:border-electric focus:ring-electric/30 outline-none"
                    placeholder="e.g. 500"
                  />
                  {currentQ.tolerance !== undefined && (
                    <p className="text-[11px] text-muted-foreground">Tolerance: ±{currentQ.tolerance}</p>
                  )}
                </div>
              ) : (
                <div className="space-y-2">
                  {currentQ.options.map((opt, idx) => {
                    const selected = session.answers[currentQ.id]?.selectedOptions.includes(idx);
                    return (
                      <button
                        key={idx}
                        onClick={() => selectOption(idx)}
                        className={cn(
                          "w-full text-left px-4 py-3 rounded-lg border text-sm transition-all flex items-start gap-3",
                          selected
                            ? "border-electric bg-electric/15 text-foreground"
                            : "border-border/50 hover:border-electric/50 hover:bg-muted/30 text-muted-foreground"
                        )}
                      >
                        <span className={cn("h-5 w-5 shrink-0 rounded-full border flex items-center justify-center text-[10px] font-bold",
                          selected ? "border-electric bg-electric text-primary-foreground" : "border-border/60 text-muted-foreground")}>
                          {String.fromCharCode(65 + idx)}
                        </span>
                        <span className="flex-1">{opt}</span>
                      </button>
                    );
                  })}
                  {currentQ.type === "multiple" && (
                    <p className="text-[11px] text-muted-foreground mt-2">Multiple correct options — select all that apply.</p>
                  )}
                </div>
              )}

              {/* Action row */}
              <div className="flex flex-wrap items-center justify-between gap-3 mt-6 pt-4 border-t border-border/40">
                <Button variant="ghost" size="sm" onClick={toggleMark} className="gap-1">
                  <Flag className={cn("h-4 w-4", (session.answers[currentQ.id]?.status === "marked-for-review" || session.answers[currentQ.id]?.status === "answered-marked") && "text-amber-400 fill-amber-400")} />
                  Mark for review
                </Button>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={goPrev} disabled={session.currentIndex === 0 && test.sections.findIndex((s) => s.id === session.currentSectionId) === 0}>
                    <ChevronLeft className="h-4 w-4" /> Prev
                  </Button>
                  <Button variant="default" size="sm" onClick={goNext} className="glow-button">
                    Next <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          )}
        </div>

        {/* Right panel — question palette */}
        <aside className="hidden md:flex w-[280px] border-l border-border/60 bg-sidebar/30 flex-col">
          <div className="px-4 py-3 border-b border-border/40">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Question palette</p>
          </div>
          <ScrollArea className="flex-1 px-4 py-3">
            {test.sections.map((s) => {
              const qs = test.questions.filter((q) => q.sectionId === s.id);
              const isCur = s.id === session.currentSectionId;
              return (
                <div key={s.id} className={cn("mb-4", !isCur && "opacity-70")}>
                  <p className="text-[11px] font-semibold text-muted-foreground mb-2">{s.name}</p>
                  <div className="grid grid-cols-5 gap-1.5">
                    {qs.map((q, idx) => {
                      const ans = session.answers[q.id];
                      const status = ans?.status ?? "unanswered";
                      const isCurrent = isCur && idx === session.currentIndex;
                      const bg = status === "answered-marked" ? "bg-amber-500/30 border-amber-500/60 text-amber-300"
                        : status === "answered" ? "bg-electric/30 border-electric/60 text-electric"
                        : status === "marked-for-review" ? "bg-purple-500/30 border-purple-500/60 text-purple-300"
                        : "bg-muted/40 border-border/60 text-muted-foreground";
                      return (
                        <button
                          key={q.id}
                          onClick={() => { session.setSection(s.id); session.setIndex(idx); questionStartRef.current = Date.now(); }}
                          className={cn("h-8 rounded-md border text-xs font-semibold flex items-center justify-center transition-all", bg, isCurrent && "ring-2 ring-cyan-glow")}
                          aria-label={`Question ${idx + 1}: ${status.replace("-", " ")}`}
                        >
                          {idx + 1}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </ScrollArea>
          <div className="px-4 py-3 border-t border-border/40 space-y-2">
            <div className="grid grid-cols-2 gap-1.5 text-[10px]">
              <Legend color="bg-electric/40 border-electric/60" label="Answered" />
              <Legend color="bg-amber-500/30 border-amber-500/60" label="Ans + Marked" />
              <Legend color="bg-purple-500/30 border-purple-500/60" label="Marked" />
              <Legend color="bg-muted/40 border-border/60" label="Not visited" />
            </div>
            <Button className="w-full glow-button" size="sm" onClick={submitTest}>
              <Send className="h-4 w-4 mr-1" /> Submit test
            </Button>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className={cn("h-3 w-3 rounded border", color)} />
      <span className="text-muted-foreground">{label}</span>
    </div>
  );
}
