"use client";

import { useState, useMemo, useEffect } from "react";
import { useRouter } from "@/lib/router";
import { institutions, institutionTypes, getInstitutionById, type InstitutionType } from "@/data/institutions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SectionHeading, VerifiedBadge, UnverifiedBadge, EmptyState, LoadingGrid } from "@/components/common/ui-bits";
import { useStudentData } from "@/lib/stores";
import { Bookmark, BookmarkCheck, ExternalLink, Search, X, ArrowLeft, ArrowRight, Building2, MapPin, Calendar } from "lucide-react";

export function InstitutionDirectoryPage() {
  const { param, navigate } = useRouter();
  const [q, setQ] = useState("");
  const [type, setType] = useState<string>("all");
  const [state, setState] = useState<string>("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 200);
    return () => clearTimeout(t);
  }, []);

  const states = useMemo(() => Array.from(new Set(institutions.map((i) => i.state))).sort(), []);
  const counts = useMemo(() => {
    const m: Record<string, number> = { all: institutions.length };
    for (const t of institutionTypes) m[t] = institutions.filter((i) => i.type === t).length;
    return m;
  }, []);

  const filtered = useMemo(() => {
    return institutions.filter((i) => {
      if (type !== "all" && i.type !== type) return false;
      if (state !== "all" && i.state !== state) return false;
      if (q.trim()) {
        const s = q.toLowerCase();
        const hay = `${i.name} ${i.fullName} ${i.location} ${i.state} ${i.admissionRoute} ${i.programmes.join(" ")}`.toLowerCase();
        if (!hay.includes(s)) return false;
      }
      return true;
    });
  }, [q, type, state]);

  const selected = param ? getInstitutionById(param) : undefined;
  if (selected) return <InstitutionDetail inst={selected} onBack={() => navigate("institutions")} />;

  return (
    <div className="px-4 lg:px-10 py-8 max-w-7xl mx-auto animate-in-fade">
      <SectionHeading
        eyebrow="Directory"
        title="Institutions Directory"
        description={`${institutions.length}+ Indian higher-education institutions across IITs, NITs, IIITs, IIMs, central universities, state universities and private/deemed universities.`}
      />

      <Card className="glass-card p-4 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="relative sm:col-span-2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name, location, programme…" className="pl-9 bg-muted/30" />
          </div>
          <Select value={type} onValueChange={setType}>
            <SelectTrigger className="bg-muted/30"><SelectValue placeholder="Type" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types ({counts.all})</SelectItem>
              {institutionTypes.map((t) => (
                <SelectItem key={t} value={t}>{t} ({counts[t] ?? 0})</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={state} onValueChange={setState}>
            <SelectTrigger className="bg-muted/30"><SelectValue placeholder="State" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All states</SelectItem>
              {states.map((s) => (
                <SelectItem key={s} value={s}>{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        {(q || type !== "all" || state !== "all") && (
          <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border/40">
            <span className="text-xs text-muted-foreground">{filtered.length} match{filtered.length !== 1 ? "es" : ""}</span>
            <Button variant="ghost" size="sm" onClick={() => { setQ(""); setType("all"); setState("all"); }} className="ml-auto text-xs gap-1">
              <X className="h-3 w-3" /> Clear filters
            </Button>
          </div>
        )}
      </Card>

      {loading ? (
        <LoadingGrid count={9} />
      ) : filtered.length === 0 ? (
        <EmptyState title="No institutions match your filters" description="Try clearing the filters or use a different keyword." icon={Search} action={<Button variant="outline" onClick={() => { setQ(""); setType("all"); setState("all"); }}>Clear filters</Button>} />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((it, i) => (
            <Card key={it.id} className="glass-card glass-card-hover animate-in-up" style={{ animationDelay: `${Math.min(i, 6) * 0.04}s` }}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <Badge variant="outline" className="text-[10px] border-purple-sub/40 text-purple-sub">{it.type}</Badge>
                  <span className="text-[10px] text-muted-foreground">est. {it.established}</span>
                </div>
                <CardTitle className="text-base mt-2 cursor-pointer hover:text-electric" onClick={() => navigate("institutions", it.id)}>{it.name}</CardTitle>
                <CardDescription className="text-xs">{it.fullName}</CardDescription>
              </CardHeader>
              <CardContent className="pt-0 text-xs text-muted-foreground space-y-1.5">
                <p className="flex items-center gap-1.5"><MapPin className="h-3 w-3 shrink-0" /> {it.location}</p>
                <p className="line-clamp-1">Programmes: {it.programmes.slice(0, 3).join(", ")}{it.programmes.length > 3 ? "…" : ""}</p>
                <p className="line-clamp-1"><span className="text-muted-foreground/70">Admission:</span> {it.admissionRoute}</p>
                <div className="pt-2 mt-1 border-t border-border/30 flex items-center justify-between">
                  <Button size="sm" variant="ghost" className="h-7 text-xs px-2" onClick={() => navigate("institutions", it.id)}>Details <ArrowRight className="h-3 w-3 ml-1" /></Button>
                  <a href={it.officialWebsite} target="_blank" rel="noopener noreferrer" className="text-electric hover:underline text-xs inline-flex items-center gap-1">
                    <ExternalLink className="h-3 w-3" /> Official
                  </a>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function InstitutionDetail({ inst, onBack }: { inst: NonNullable<ReturnType<typeof getInstitutionById>>; onBack: () => void }) {
  const { navigate } = useRouter();
  const { toggleBookmark, isBookmarked } = useStudentData();
  const bm = isBookmarked("INSTITUTION", inst.id);
  return (
    <div className="px-4 lg:px-10 py-8 max-w-5xl mx-auto animate-in-fade">
      <Button variant="ghost" size="sm" onClick={onBack} className="mb-4 gap-1">
        <ArrowLeft className="h-4 w-4" /> Back to directory
      </Button>
      <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="outline" className="border-purple-sub/40 text-purple-sub">{inst.type}</Badge>
            <Badge variant="outline"><Calendar className="h-3 w-3 mr-1 inline" /> Est. {inst.established}</Badge>
            <VerifiedBadge />
          </div>
          <h1 className="text-3xl font-bold text-gradient-static">{inst.name}</h1>
          <p className="text-sm text-muted-foreground">{inst.fullName}</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => toggleBookmark("INSTITUTION", inst.id)} className="gap-1">
          {bm ? <BookmarkCheck className="h-4 w-4 text-cyan-glow" /> : <Bookmark className="h-4 w-4" />}
          {bm ? "Bookmarked" : "Bookmark"}
        </Button>
      </div>
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card className="glass-card p-5">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-electric mb-2">Overview</h2>
            <p className="text-sm">{inst.description}</p>
          </Card>
          <Card className="glass-card p-5">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-electric mb-3">Programmes offered</h2>
            <div className="flex flex-wrap gap-2">
              {inst.programmes.map((p) => (
                <Badge key={p} variant="outline" className="text-xs border-electric/30 text-foreground">{p}</Badge>
              ))}
            </div>
          </Card>
          <Card className="glass-card p-5">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-electric mb-3">Admission route</h2>
            <p className="text-sm">{inst.admissionRoute}</p>
            <p className="text-[11px] text-muted-foreground mt-2">Specific counselling body and schedule vary by programme. Refer to the official website for the current admission notification.</p>
          </Card>
        </div>
        <div className="space-y-4">
          <Card className="glass-card p-5">
            <h3 className="text-sm font-semibold mb-3">Quick facts</h3>
            <dl className="space-y-2 text-sm">
              <div><dt className="text-xs text-muted-foreground">Location</dt><dd className="font-medium">{inst.location}</dd></div>
              <div><dt className="text-xs text-muted-foreground">State</dt><dd className="font-medium">{inst.state}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Type</dt><dd className="font-medium">{inst.type}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Established</dt><dd className="font-medium">{inst.established}</dd></div>
            </dl>
          </Card>
          <Card className="glass-card p-5">
            <h3 className="text-sm font-semibold mb-3">Official website</h3>
            <a href={inst.officialWebsite} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-electric hover:underline text-sm">
              <ExternalLink className="h-4 w-4" /> Visit official site
            </a>
            <p className="text-[11px] text-muted-foreground mt-2 break-all">{inst.officialWebsite}</p>
          </Card>
          <Card className="glass-card p-5">
            <h3 className="text-sm font-semibold mb-3">Explore</h3>
            <Button variant="outline" className="w-full mb-2" size="sm" onClick={() => navigate("exams")}>Related entrance exams</Button>
            <Button variant="outline" className="w-full" size="sm" onClick={() => navigate("guidance")}>Application guidance</Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
