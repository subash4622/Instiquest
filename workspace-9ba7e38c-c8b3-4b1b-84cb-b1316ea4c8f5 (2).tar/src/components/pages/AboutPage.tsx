"use client";

import { useRouter } from "@/lib/router";
import { siteConfig } from "@/data/site-config";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SectionHeading, VerifiedBadge, UnverifiedBadge, DemoBadge, StatBlock } from "@/components/common/ui-bits";
import { exams } from "@/data/exams";
import { institutions } from "@/data/institutions";
import { mockTests } from "@/data/mock-tests";
import { Target, Eye, Compass, Heart, Shield, Users, BookOpen, Building2, Brain, ArrowRight, Sparkles } from "lucide-react";

export function AboutPage() {
  const { navigate } = useRouter();

  return (
    <div className="px-4 lg:px-10 py-10 max-w-5xl mx-auto animate-in-fade">
      <div className="relative overflow-hidden rounded-2xl mb-8 bg-aurora border border-border/40 p-8">
        <div className="absolute inset-0 bg-grid opacity-30 pointer-events-none" />
        <div className="relative space-y-3">
          <Badge className="ai-badge border-0 gap-1"><Sparkles className="h-3 w-3" /> About INSTIQUEST</Badge>
          <h1 className="text-3xl md:text-4xl font-extrabold text-gradient-static">A premium admission portal for the next generation of aspirants.</h1>
          <p className="text-muted-foreground max-w-3xl">
            INSTIQUEST is built by <strong className="text-foreground">WEB CREATORS</strong> as a futuristic, single-stop
            platform for entrance exam discovery, institution research, hard-level mock practice, AI-guided admission
            assistance and institute advertising — with verified information clearly separated from AI-generated guidance.
          </p>
        </div>
      </div>

      {/* Mission / Vision */}
      <div className="grid lg:grid-cols-2 gap-5 mb-8">
        <Card className="glass-card glass-card-hover p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="h-10 w-10 rounded-lg bg-electric/20 flex items-center justify-center">
              <Target className="h-5 w-5 text-electric" />
            </div>
            <CardTitle>Our Mission</CardTitle>
          </div>
          <CardContent className="p-0 text-sm text-muted-foreground leading-relaxed">
            To democratise access to accurate admission information by aggregating verified exam and institution data,
            hard-level original mock tests and AI-assisted guidance — while clearly distinguishing verified facts from
            AI-generated suggestions, and never inventing dates or eligibility.
          </CardContent>
        </Card>

        <Card className="glass-card glass-card-hover p-6">
          <div className="flex items-center gap-3 mb-3">
            <div className="h-10 w-10 rounded-lg bg-cyan-glow/20 flex items-center justify-center">
              <Eye className="h-5 w-5 text-cyan-glow" />
            </div>
            <CardTitle>Our Vision</CardTitle>
          </div>
          <CardContent className="p-0 text-sm text-muted-foreground leading-relaxed">
            A future where every aspirant — irrespective of geography or background — can plan their admission journey
            with confidence, backed by verified information, transparent moderation of paid promotions and responsible
            AI guidance that augments human judgement rather than replacing it.
          </CardContent>
        </Card>
      </div>

      {/* Values */}
      <SectionHeading eyebrow="What we stand for" title="Core values" />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
        {[
          { icon: Shield, title: "Verified over viral", desc: "Every directory entry carries a verified badge or an explicit 'pending review' marker. We never publish unverified dates as fact." },
          { icon: Users, title: "Aspirant-first", desc: "Every feature — from mock tests to the AI assistant — is designed to reduce information asymmetry for the aspirant." },
          { icon: Compass, title: "Transparent moderation", desc: "Institute advertisements go through admin moderation before publishing. No ad goes live automatically." },
          { icon: Brain, title: "Responsible AI", desc: "AI guidance is clearly labelled and never merged with verified facts. API keys never touch the frontend." },
          { icon: Heart, title: "Original content", desc: "Mock questions are authored originally by INSTIQUEST. We do not host copyrighted exam papers." },
          { icon: BookOpen, title: "Open, editable source", desc: "Every data file is structured and editable. Update exams, institutions and KB entries in TypeScript data files." },
        ].map((v, i) => (
          <Card key={v.title} className="glass-card glass-card-hover p-5 animate-in-up" style={{ animationDelay: `${i * 0.05}s` }}>
            <div className="flex items-center gap-3 mb-2">
              <v.icon className="h-5 w-5 text-electric" />
              <p className="font-semibold">{v.title}</p>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">{v.desc}</p>
          </Card>
        ))}
      </div>

      {/* Stats */}
      <SectionHeading eyebrow="By the numbers" title="What's inside" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        <StatBlock label="Entrance Exams" value={`${exams.length}+`} icon={BookOpen} />
        <StatBlock label="Institutions" value={`${institutions.length}+`} icon={Building2} accent="cyan" />
        <StatBlock label="Mock Tests" value={`${mockTests.length}`} icon={Brain} accent="purple" />
        <StatBlock label="Exam Categories" value="11" icon={Target} accent="electric" />
      </div>

      {/* Ownership */}
      <Card className="glass-card p-6 mb-6">
        <div className="flex flex-wrap items-start justify-between gap-3 mb-2">
          <h3 className="text-lg font-semibold">Ownership & publication status</h3>
          {siteConfig.owner.approvedForPublication ? <VerifiedBadge label="Approved for publication" /> : <UnverifiedBadge label="Placeholder — pending approval" />}
        </div>
        <p className="text-sm text-muted-foreground">
          INSTIQUEST is owned by <strong className="text-foreground">{siteConfig.owner.name}</strong>. Until formal
          approval for publication is granted, the owner name displayed throughout the site is treated as a configurable
          placeholder. Update <code className="text-electric">src/data/site-config.ts</code> to change the owner name
          and toggle the <code className="text-electric">approvedForPublication</code> flag.
        </p>
      </Card>

      <div className="flex flex-wrap items-center gap-3">
        <Button onClick={() => navigate("contact")} className="glow-button gap-2">Contact us <ArrowRight className="h-4 w-4" /></Button>
        <Button variant="outline" onClick={() => navigate("exams")} className="gap-2 border-electric/40 text-electric">Browse exams <ArrowRight className="h-4 w-4" /></Button>
        <Button variant="ghost" onClick={() => navigate("disclaimer")} className="text-muted-foreground">Read disclaimer</Button>
        <DemoBadge label="Demo build" />
      </div>
    </div>
  );
}
