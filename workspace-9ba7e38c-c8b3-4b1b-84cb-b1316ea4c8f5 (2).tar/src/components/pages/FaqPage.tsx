"use client";

import { useState, useMemo } from "react";
import { useRouter } from "@/lib/router";
import { faqs, faqCategories, getFaqsByCategory } from "@/data/faqs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";
import { SectionHeading, EmptyState } from "@/components/common/ui-bits";
import { Search, HelpCircle, MessageSquare, Compass, FileText, X } from "lucide-react";

export function FaqPage() {
  const { navigate } = useRouter();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string>("all");

  const filtered = useMemo(() => {
    return faqs.filter((f) => {
      if (cat !== "all" && f.category !== cat) return false;
      if (q.trim()) {
        const s = q.toLowerCase();
        if (!`${f.question} ${f.answer} ${f.category}`.toLowerCase().includes(s)) return false;
      }
      return true;
    });
  }, [q, cat]);

  return (
    <div className="px-4 lg:px-10 py-10 max-w-5xl mx-auto animate-in-fade">
      <SectionHeading
        eyebrow="Help"
        title="Frequently Asked Questions"
        description="Quick answers about INSTIQUEST, exams, mock tests, the AI assistant, advertising and your account. Can't find what you need? Use the AI assistant or contact us."
      />

      {/* Search + category chips */}
      <Card className="glass-card p-4 mb-6">
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search FAQs…"
            className="pl-9 bg-muted/30"
            aria-label="Search FAQs"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setCat("all")}
            className={`px-3 py-1.5 rounded-full text-xs border transition-all ${cat === "all" ? "bg-primary/20 border-primary text-primary" : "bg-muted/30 border-border/60 text-muted-foreground hover:bg-muted/50"}`}
          >
            All ({faqs.length})
          </button>
          {faqCategories.map((c) => {
            const count = getFaqsByCategory(c).length;
            return (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={`px-3 py-1.5 rounded-full text-xs border transition-all ${cat === c ? "bg-primary/20 border-primary text-primary" : "bg-muted/30 border-border/60 text-muted-foreground hover:bg-muted/50"}`}
              >
                {c} ({count})
              </button>
            );
          })}
        </div>
        {(q || cat !== "all") && (
          <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border/40">
            <span className="text-xs text-muted-foreground">{filtered.length} match{filtered.length !== 1 ? "es" : ""}</span>
            <Button variant="ghost" size="sm" onClick={() => { setQ(""); setCat("all"); }} className="ml-auto text-xs gap-1">
              <X className="h-3 w-3" /> Clear
            </Button>
          </div>
        )}
      </Card>

      {/* FAQs */}
      {filtered.length === 0 ? (
        <EmptyState
          title="No FAQs match your search"
          description="Try a different keyword or browse all FAQs."
          icon={HelpCircle}
          action={<Button variant="outline" onClick={() => { setQ(""); setCat("all"); }}>Show all FAQs</Button>}
        />
      ) : (
        <Card className="glass-card p-2 sm:p-4">
          <Accordion type="single" collapsible className="space-y-1">
            {filtered.map((f) => (
              <AccordionItem key={f.id} value={f.id} className="border-b border-border/40 last:border-0 px-2 sm:px-3">
                <AccordionTrigger className="text-left hover:no-underline py-4 group">
                  <div className="flex items-start gap-3 flex-1">
                    <Badge variant="outline" className="text-[10px] border-primary/40 text-primary shrink-0 mt-0.5">{f.category}</Badge>
                    <span className="text-sm font-medium group-hover:text-primary transition-colors">{f.question}</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground leading-relaxed pb-4 pl-1">
                  {f.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Card>
      )}

      {/* Still need help */}
      <div className="grid sm:grid-cols-3 gap-4 mt-10">
        <Card className="glass-card glass-card-hover p-5">
          <MessageSquare className="h-5 w-5 text-primary mb-2" />
          <CardTitle className="text-sm mb-1">Ask the AI</CardTitle>
          <CardDescription className="text-xs mb-3">Get instant guidance on admission routes, counselling and eligibility.</CardDescription>
          <Button size="sm" variant="outline" onClick={() => navigate("chatbot")} className="w-full">Open assistant</Button>
        </Card>
        <Card className="glass-card glass-card-hover p-5">
          <Compass className="h-5 w-5 text-accent mb-2" />
          <CardTitle className="text-sm mb-1">Application guidance</CardTitle>
          <CardDescription className="text-xs mb-3">Step-by-step walkthrough of the application process.</CardDescription>
          <Button size="sm" variant="outline" onClick={() => navigate("guidance")} className="w-full">View guide</Button>
        </Card>
        <Card className="glass-card glass-card-hover p-5">
          <FileText className="h-5 w-5 text-primary mb-2" />
          <CardTitle className="text-sm mb-1">Contact us</CardTitle>
          <CardDescription className="text-xs mb-3">Reach the WEB CREATORS team for anything else.</CardDescription>
          <Button size="sm" variant="outline" onClick={() => navigate("contact")} className="w-full">Contact</Button>
        </Card>
      </div>
    </div>
  );
}
