"use client";

import { useState, useEffect, useMemo } from "react";
import { toast } from "sonner";
import { useAuth } from "@/lib/stores";
import { exams } from "@/data/exams";
import { institutions } from "@/data/institutions";
import { mockTests } from "@/data/mock-tests";
import { verifiedKB } from "@/data/kb";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell,
} from "@/components/ui/table";
import { SectionHeading, DemoBadge, VerifiedBadge, UnverifiedBadge } from "@/components/common/ui-bits";
import {
  ShieldCheck, ShieldAlert, FileText, Building2, ListChecks, Megaphone,
  Sparkles, Calendar, Pencil, Trash2, Plus, Check, X, Inbox, BookOpen,
} from "lucide-react";

// ---------- Types for ad submissions in localStorage ----------
type SubmissionStatus = "Pending" | "Approved" | "Rejected" | "Published";

interface AdSubmission {
  id: string;
  createdAt: number;
  status: SubmissionStatus;
  instituteName: string;
  contactEmail: string;
  contactPhone?: string;
  instituteWebsite?: string;
  bannerHeadline: string;
  bannerCopy: string;
  landingUrl?: string;
  campaignStart?: string;
  campaignEnd?: string;
  additionalMessage?: string;
}

const AD_STORAGE_KEY = "instiquest-ad-submissions";

// Example application dates (clearly demo — no real exam-specific dates published)
const SAMPLE_DATES = [
  { examId: "jee-main", label: "Application window (typical cycle)", dateValue: "Refer official NTA portal", verified: false, source: "jeemain.nta.ac.in" },
  { examId: "jee-advanced", label: "Registration window (typical cycle)", dateValue: "Refer official JEE Advanced portal", verified: false, source: "jeeadv.ac.in" },
  { examId: "neet-ug", label: "Application window (typical cycle)", dateValue: "Refer official NEET portal", verified: false, source: "neet.nta.nic.in" },
  { examId: "cat", label: "Registration window (typical cycle)", dateValue: "Refer official IIM CAT portal", verified: false, source: "iimcat.ac.in" },
  { examId: "clat", label: "Application window (typical cycle)", dateValue: "Refer Consortium of NLUs portal", verified: false, source: "consortiumofnlus.ac.in" },
  { examId: "cuet-ug", label: "Application window (typical cycle)", dateValue: "Refer NTA CUET portal", verified: false, source: "exams.nta.ac.in/CUET-UG/" },
];

const STATUS_BADGE: Record<SubmissionStatus, string> = {
  Pending: "bg-amber-500/15 text-amber-300 border-amber-500/40",
  Approved: "bg-emerald-500/15 text-emerald-300 border-emerald-500/40",
  Rejected: "bg-destructive/15 text-destructive border-destructive/40",
  Published: "bg-electric/15 text-electric border-electric/40",
};

export function AdminDashboardPage() {
  const { user, login } = useAuth();
  const [adSubs, setAdSubs] = useState<AdSubmission[]>([]);

  // Load ad submissions from localStorage on mount
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const raw = window.localStorage.getItem(AD_STORAGE_KEY);
      const parsed: AdSubmission[] = raw ? JSON.parse(raw) : [];
      const sorted = parsed.sort((a, b) => b.createdAt - a.createdAt);
      // Defer setState to avoid synchronous-in-effect warning
      Promise.resolve().then(() => setAdSubs(sorted));
    } catch {
      Promise.resolve().then(() => setAdSubs([]));
    }
  }, []);

  const persistAds = (next: AdSubmission[]) => {
    setAdSubs(next);
    if (typeof window !== "undefined") {
      try {
        window.localStorage.setItem(AD_STORAGE_KEY, JSON.stringify(next));
      } catch {
        /* ignore quota errors */
      }
    }
  };

  const setAdStatus = (id: string, status: SubmissionStatus) => {
    const next = adSubs.map((s) => (s.id === id ? { ...s, status } : s));
    persistAds(next);
    toast.success(`Demo: ad marked as ${status}`);
  };

  // Flatten mock test questions
  const flatQuestions = useMemo(() => {
    return mockTests.flatMap((t) =>
      t.questions.map((q) => ({
        testTitle: t.title,
        section: t.sections.find((s) => s.id === q.sectionId)?.name ?? q.sectionId,
        topic: q.topic,
        difficulty: q.difficulty,
        type: q.type,
        marks: q.marks,
        qid: q.id,
      }))
    );
  }, []);

  // ---------- Role gate ----------
  if (!user || user.role !== "admin") {
    return (
      <div className="px-4 lg:px-10 py-12 max-w-3xl mx-auto animate-in-fade">
        <Card className="glass-card p-8 text-center">
          <div className="mx-auto mb-5 w-16 h-16 rounded-full bg-destructive/15 flex items-center justify-center">
            <ShieldAlert className="h-8 w-8 text-destructive" />
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-gradient-static mb-2">Admin access required</h1>
          <p className="text-sm text-muted-foreground max-w-md mx-auto mb-6">
            This area is gated to admin sessions only. The current session is not an admin
            session. Use the demo button below to sign in as an admin (clearly labelled demo —
            no real credentials are stored).
          </p>
          <Button onClick={() => login("admin")} className="glow-button gap-2">
            <ShieldCheck className="h-4 w-4" /> Sign in as Admin (demo)
          </Button>
          <div className="mt-6 flex items-center justify-center gap-2">
            <DemoBadge label="Demo admin console" />
            <span className="text-xs text-muted-foreground">Replace with NextAuth role-based auth before going live.</span>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="px-4 lg:px-10 py-8 max-w-7xl mx-auto animate-in-fade">
      <SectionHeading
        eyebrow="Admin Console"
        title="Admin Dashboard"
        description="Manage exam directory entries, institutions, mock questions, advertising submissions, chatbot KB content and application-date catalogue. All actions here are clearly-labelled demo actions."
        action={<DemoBadge label="Demo admin console" />}
      />

      <Tabs defaultValue="exams" className="w-full">
        <div className="overflow-x-auto pb-2">
          <TabsList className="mb-6">
            <TabsTrigger value="exams" className="gap-1.5"><FileText className="h-4 w-4" /> Exams</TabsTrigger>
            <TabsTrigger value="institutions" className="gap-1.5"><Building2 className="h-4 w-4" /> Institutions</TabsTrigger>
            <TabsTrigger value="questions" className="gap-1.5"><ListChecks className="h-4 w-4" /> Mock Questions</TabsTrigger>
            <TabsTrigger value="ads" className="gap-1.5"><Megaphone className="h-4 w-4" /> Advertisements</TabsTrigger>
            <TabsTrigger value="chatbot" className="gap-1.5"><Sparkles className="h-4 w-4" /> Chatbot Content</TabsTrigger>
            <TabsTrigger value="dates" className="gap-1.5"><Calendar className="h-4 w-4" /> Application Dates</TabsTrigger>
          </TabsList>
        </div>

        {/* ============== EXAMS ============== */}
        <TabsContent value="exams" className="animate-in-up">
          <Card className="glass-card">
            <CardHeader>
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div>
                  <CardTitle className="text-lg">Examinations directory</CardTitle>
                  <CardDescription>Showing the first 20 of {exams.length} exams. Edit and Delete are demo actions only.</CardDescription>
                </div>
                <Button size="sm" variant="outline" onClick={() => toast.success("Demo: add exam action recorded")} className="gap-1">
                  <Plus className="h-3 w-3" /> Add exam
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Conducting Authority</TableHead>
                    <TableHead>Verified</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {exams.slice(0, 20).map((e) => (
                    <TableRow key={e.id}>
                      <TableCell>
                        <div className="font-medium">{e.name}</div>
                        <div className="text-[10px] text-muted-foreground">{e.id}</div>
                      </TableCell>
                      <TableCell><Badge variant="outline" className="text-[10px] border-border/60 text-muted-foreground">{e.category}</Badge></TableCell>
                      <TableCell className="text-xs">{e.conductingAuthority}</TableCell>
                      <TableCell>{e.verified ? <VerifiedBadge /> : <UnverifiedBadge />}</TableCell>
                      <TableCell className="text-right">
                        <div className="inline-flex items-center gap-1">
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs gap-1" onClick={() => toast.success("Demo: edit exam recorded")}>
                            <Pencil className="h-3 w-3" /> Edit
                          </Button>
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-destructive gap-1" onClick={() => toast.success("Demo: delete exam recorded")}>
                            <Trash2 className="h-3 w-3" /> Delete
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ============== INSTITUTIONS ============== */}
        <TabsContent value="institutions" className="animate-in-up">
          <Card className="glass-card">
            <CardHeader>
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div>
                  <CardTitle className="text-lg">Institutions directory</CardTitle>
                  <CardDescription>Showing the first 20 of {institutions.length} institutions. Edit and Delete are demo actions only.</CardDescription>
                </div>
                <Button size="sm" variant="outline" onClick={() => toast.success("Demo: add institution action recorded")} className="gap-1">
                  <Plus className="h-3 w-3" /> Add institution
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Admission Route</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {institutions.slice(0, 20).map((i) => (
                    <TableRow key={i.id}>
                      <TableCell>
                        <div className="font-medium">{i.name}</div>
                        <div className="text-[10px] text-muted-foreground">{i.id}</div>
                      </TableCell>
                      <TableCell><Badge variant="outline" className="text-[10px] border-border/60 text-muted-foreground">{i.type}</Badge></TableCell>
                      <TableCell className="text-xs">{i.location}</TableCell>
                      <TableCell className="text-xs">{i.admissionRoute}</TableCell>
                      <TableCell className="text-right">
                        <div className="inline-flex items-center gap-1">
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs gap-1" onClick={() => toast.success("Demo: edit institution recorded")}>
                            <Pencil className="h-3 w-3" /> Edit
                          </Button>
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-destructive gap-1" onClick={() => toast.success("Demo: delete institution recorded")}>
                            <Trash2 className="h-3 w-3" /> Delete
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ============== MOCK QUESTIONS ============== */}
        <TabsContent value="questions" className="animate-in-up">
          <Card className="glass-card">
            <CardHeader>
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div>
                  <CardTitle className="text-lg">Mock test questions</CardTitle>
                  <CardDescription>
                    {flatQuestions.length} questions flattened across {mockTests.length} mock tests. &quot;Add question&quot; is a demo action.
                  </CardDescription>
                </div>
                <Button size="sm" variant="outline" onClick={() => toast.success("Demo: add question action recorded")} className="gap-1">
                  <Plus className="h-3 w-3" /> Add question
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Test</TableHead>
                    <TableHead>Section</TableHead>
                    <TableHead>Topic</TableHead>
                    <TableHead>Difficulty</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="text-right">Marks</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {flatQuestions.map((q) => (
                    <TableRow key={q.qid}>
                      <TableCell className="text-xs max-w-[240px] truncate">{q.testTitle}</TableCell>
                      <TableCell className="text-xs">{q.section}</TableCell>
                      <TableCell className="text-xs">{q.topic}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={
                          q.difficulty === "hard"
                            ? "text-[10px] border-destructive/40 text-destructive"
                            : q.difficulty === "medium"
                              ? "text-[10px] border-amber-500/40 text-amber-300"
                              : "text-[10px] border-emerald-500/40 text-emerald-300"
                        }>{q.difficulty}</Badge>
                      </TableCell>
                      <TableCell><Badge variant="outline" className="text-[10px] border-border/60 text-muted-foreground">{q.type}</Badge></TableCell>
                      <TableCell className="text-right text-xs font-medium">{q.marks}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ============== ADVERTISEMENTS ============== */}
        <TabsContent value="ads" className="animate-in-up">
          <Card className="glass-card">
            <CardHeader>
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div>
                  <CardTitle className="text-lg">Advertising submissions</CardTitle>
                  <CardDescription>
                    Submissions loaded from <code className="text-[10px] bg-muted/30 px-1 py-0.5 rounded">localStorage[{`"${AD_STORAGE_KEY}"`}]</code>.
                    Approve / Reject are demo actions — they update local state and persist back to localStorage.
                  </CardDescription>
                </div>
                <Button size="sm" variant="outline" onClick={() => toast.success("Demo: refresh queue (already live)")} className="gap-1">
                  <Inbox className="h-3 w-3" /> Refresh
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {adSubs.length === 0 ? (
                <div className="py-12 text-center">
                  <Inbox className="h-10 w-10 text-muted-foreground mx-auto mb-3 opacity-50" />
                  <p className="text-sm text-muted-foreground">No ad submissions in the queue.</p>
                  <p className="text-xs text-muted-foreground/70 mt-1">
                    Submit an ad from the Advertising Portal to see it here.
                  </p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Institute</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead>Banner Headline</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {adSubs.map((s) => (
                      <TableRow key={s.id}>
                        <TableCell>
                          <div className="font-medium text-sm">{s.instituteName}</div>
                          {s.instituteWebsite && (
                            <a href={s.instituteWebsite} target="_blank" rel="noopener noreferrer" className="text-[10px] text-electric hover:underline">
                              {s.instituteWebsite}
                            </a>
                          )}
                        </TableCell>
                        <TableCell className="text-xs">
                          <div>{s.contactEmail}</div>
                          {s.contactPhone && <div className="text-muted-foreground">{s.contactPhone}</div>}
                        </TableCell>
                        <TableCell className="text-xs max-w-[260px] truncate">{s.bannerHeadline}</TableCell>
                        <TableCell>
                          <Badge className={`border ${STATUS_BADGE[s.status]} text-[10px]`}>{s.status}</Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="inline-flex items-center gap-1">
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-7 px-2 text-xs gap-1 text-emerald-300"
                              disabled={s.status === "Approved"}
                              onClick={() => setAdStatus(s.id, "Approved")}
                            >
                              <Check className="h-3 w-3" /> Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-7 px-2 text-xs gap-1 text-destructive"
                              disabled={s.status === "Rejected"}
                              onClick={() => setAdStatus(s.id, "Rejected")}
                            >
                              <X className="h-3 w-3" /> Reject
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ============== CHATBOT CONTENT ============== */}
        <TabsContent value="chatbot" className="animate-in-up">
          <Card className="glass-card">
            <CardHeader>
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div>
                  <CardTitle className="text-lg">Verified chatbot KB entries</CardTitle>
                  <CardDescription>
                    {verifiedKB.length} verified short-facts used as the verified-context source for the AI chatbot.
                    Read-only here — edit <code className="text-[10px] bg-muted/30 px-1 py-0.5 rounded">src/data/kb.ts</code> to update verified content.
                  </CardDescription>
                </div>
                <Button size="sm" variant="outline" onClick={() => toast.success("Demo: export KB action recorded")} className="gap-1">
                  <BookOpen className="h-3 w-3" /> Export
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Keywords</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Answer snippet</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {verifiedKB.map((k) => (
                    <TableRow key={k.id}>
                      <TableCell className="max-w-[240px]">
                        <div className="flex flex-wrap gap-1">
                          {k.keywords.slice(0, 4).map((kw) => (
                            <Badge key={kw} variant="outline" className="text-[10px] border-border/60 text-muted-foreground">{kw}</Badge>
                          ))}
                          {k.keywords.length > 4 && (
                            <span className="text-[10px] text-muted-foreground">+{k.keywords.length - 4}</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell><Badge variant="outline" className="text-[10px] border-electric/40 text-electric">{k.category}</Badge></TableCell>
                      <TableCell className="text-xs max-w-[420px] truncate" title={k.answer}>{k.answer}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ============== APPLICATION DATES ============== */}
        <TabsContent value="dates" className="animate-in-up">
          <Card className="glass-card">
            <CardHeader>
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div>
                  <CardTitle className="text-lg">Application date catalogue (demo)</CardTitle>
                  <CardDescription>
                    Example rows showing the shape INSTIQUEST would store for application windows.
                    All rows point users back to the official portal — no invented dates are published.
                  </CardDescription>
                </div>
                <Button size="sm" variant="outline" onClick={() => toast.success("Demo: add date action recorded")} className="gap-1">
                  <Plus className="h-3 w-3" /> Add date
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Exam ID</TableHead>
                    <TableHead>Label</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead>Verified</TableHead>
                    <TableHead>Source</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {SAMPLE_DATES.map((d, i) => (
                    <TableRow key={`${d.examId}-${i}`}>
                      <TableCell><Badge variant="outline" className="text-[10px] border-border/60 text-muted-foreground">{d.examId}</Badge></TableCell>
                      <TableCell className="text-xs">{d.label}</TableCell>
                      <TableCell className="text-xs text-cyan-glow">{d.dateValue}</TableCell>
                      <TableCell>{d.verified ? <VerifiedBadge /> : <UnverifiedBadge />}</TableCell>
                      <TableCell>
                        <a href={`https://${d.source}`} target="_blank" rel="noopener noreferrer" className="text-[10px] text-electric hover:underline">
                          {d.source}
                        </a>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <p className="text-[10px] text-muted-foreground/70 mt-3">
                Note: INSTIQUEST editorial policy does not publish specific application-window dates unless broadly verified. The catalogue above is a structural demo only.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
