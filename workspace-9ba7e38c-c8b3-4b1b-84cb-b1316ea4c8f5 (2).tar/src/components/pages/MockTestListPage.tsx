"use client";

import { useRouter } from "@/lib/router";
import { mockTests, getMockTestById, type MockTest } from "@/data/mock-tests";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SectionHeading, EmptyState, StatBlock, DemoBadge } from "@/components/common/ui-bits";
import { Brain, Clock, FileText, ListChecks, AlertTriangle, ArrowRight, CheckCircle2, Target, Trophy } from "lucide-react";

export function MockTestListPage() {
  const { navigate } = useRouter();
  return (
    <div className="px-4 lg:px-10 py-8 max-w-7xl mx-auto animate-in-fade">
      <SectionHeading
        eyebrow="Practice"
        title="Hard-Level Mock Tests"
        description="Original INSTIQUEST-authored questions in Engineering, Medical, Management and Law streams. Timed sections, negative marking, full explanations and analytics."
        action={<DemoBadge label="Original questions" />}
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatBlock label="Mock tests" value={mockTests.length} icon={Brain} />
        <StatBlock label="Total questions" value={mockTests.reduce((a, t) => a + t.questions.length, 0)} icon={ListChecks} accent="cyan" />
        <StatBlock label="Categories" value={new Set(mockTests.map((t) => t.category)).size} icon={Target} accent="purple" />
        <StatBlock label="Avg. duration" value={`${Math.round(mockTests.reduce((a, t) => a + t.totalDurationMinutes, 0) / mockTests.length)}m`} icon={Clock} accent="electric" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        {mockTests.map((t, i) => (
          <Card key={t.id} className="glass-card glass-card-hover animate-in-up" style={{ animationDelay: `${i * 0.08}s` }}>
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-2">
                <Badge variant="outline" className="border-electric/40 text-electric text-[10px]">{t.category}</Badge>
                <Badge variant="outline" className="text-[10px]">
                  <AlertTriangle className="h-3 w-3 mr-1 inline text-amber-400" />
                  Negative marking
                </Badge>
              </div>
              <CardTitle className="text-lg mt-2">{t.title}</CardTitle>
              <CardDescription className="text-xs">{t.description}</CardDescription>
            </CardHeader>
            <CardContent className="pt-0 space-y-3">
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="rounded-md bg-muted/30 p-2 text-center">
                  <Clock className="h-3 w-3 mx-auto text-muted-foreground" />
                  <p className="font-semibold mt-1">{t.totalDurationMinutes}m</p>
                  <p className="text-[10px] text-muted-foreground">duration</p>
                </div>
                <div className="rounded-md bg-muted/30 p-2 text-center">
                  <FileText className="h-3 w-3 mx-auto text-muted-foreground" />
                  <p className="font-semibold mt-1">{t.questions.length}</p>
                  <p className="text-[10px] text-muted-foreground">questions</p>
                </div>
                <div className="rounded-md bg-muted/30 p-2 text-center">
                  <Trophy className="h-3 w-3 mx-auto text-muted-foreground" />
                  <p className="font-semibold mt-1">{t.totalMarks}</p>
                  <p className="text-[10px] text-muted-foreground">marks</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {t.sections.map((s) => (
                  <Badge key={s.id} variant="outline" className="text-[10px] border-border/60 text-muted-foreground">
                    {s.name} · {s.durationMinutes}m
                  </Badge>
                ))}
              </div>
              <p className="text-[11px] text-muted-foreground">
                Marking: +{t.questions[0].marks} for correct, −{t.questions[0].negativeMarks} for wrong · {t.sections.length} sections
              </p>
              <Button className="w-full glow-button" size="sm" onClick={() => navigate("mock-tests/active", t.id)}>
                Start test <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="glass-card mt-8 p-5 text-xs text-muted-foreground">
        <p className="flex items-center gap-2 mb-2"><CheckCircle2 className="h-4 w-4 text-electric" /> Original content</p>
        <p>All mock questions are authored originally by INSTIQUEST. They are not copied from any copyrighted exam paper. They mirror the style and difficulty of competitive exams to help you practise under timed conditions.</p>
      </Card>
    </div>
  );
}

// Re-export for runner
export { getMockTestById };
export type { MockTest };
