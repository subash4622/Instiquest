"use client";

import { useState, useMemo, useEffect } from "react";
import { useRouter } from "@/lib/router";
import { exams, examCategories, getExamById, type ExamCategory } from "@/data/exams";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { SectionHeading, VerifiedBadge, UnverifiedBadge, EmptyState, LoadingGrid } from "@/components/common/ui-bits";
import { useStudentData } from "@/lib/stores";
import { Bookmark, BookmarkCheck, ExternalLink, Search, Filter, X, ArrowLeft, ArrowRight, Building2, FileText } from "lucide-react";

export function ExamDirectoryPage() {
  const { param, query, navigate } = useRouter();
  const [q, setQ] = useState(query.q ?? "");
  const [category, setCategory] = useState<string>("all");
  const [level, setLevel] = useState<string>("all");
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [loading, setLoading] = useState(true);
  const toggleBookmark = useStudentData((s) => s.toggleBookmark);
  const isBookmarked = useStudentData((s) => s.isBookmarked);
  const saveExam = useStudentData((s) => s.saveExam);
  const unsaveExam = useStudentData((s) => s.unsaveExam);
  const isExamSaved = useStudentData((s) => s.isExamSaved);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 250);
    return () => clearTimeout(t);
  }, []);

  const filtered = useMemo(() => {
    return exams.filter((e) => {
      if (category !== "all" && e.category !== category) return false;
      if (level !== "all" && e.level !== level) return false;
      if (verifiedOnly && !e.verified) return false;
      if (q.trim()) {
        const s = q.toLowerCase();
        const hay = `${e.name} ${e.fullName} ${e.conductingAuthority} ${e.course} ${e.category}`.toLowerCase();
        if (!hay.includes(s)) return false;
      }
      return true;
    });
  }, [q, category, level, verifiedOnly]);

  const counts = useMemo(() => {
    const m: Record<string, number> = { all: exams.length };
    for (const c of examCategories) m[c] = exams.filter((e) => e.category === c).length;
    return m;
  }, []);

  const selectedExam = param ? getExamById(param) : undefined;

  if (selectedExam) {
    return <ExamDetail exam={selectedExam} onBack={() => navigate("exams")} />;
  }

  return (
    <div className="px-4 lg:px-10 py-8 max-w-7xl mx-auto animate-in-fade">
      <SectionHeading
        eyebrow="Directory"
        title="Entrance Exams Directory"
        description={`${exams.length} Indian and international entrance exams across ${examCategories.length} categories. Verified entries carry a green badge; unverified items are clearly flagged for review.`}
      />

      {/* Filters */}
      <Card className="glass-card p-4 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div className="relative sm:col-span-2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search by name, authority, course…"
              className="pl-9 bg-muted/30"
              aria-label="Search exams"
            />
          </div>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="bg-muted/30"><SelectValue placeholder="Category" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All categories ({counts.all})</SelectItem>
              {examCategories.map((c) => (
                <SelectItem key={c} value={c}>{c} ({counts[c] ?? 0})</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={level} onValueChange={setLevel}>
            <SelectTrigger className="bg-muted/30"><SelectValue placeholder="Level" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All levels</SelectItem>
              <SelectItem value="National">National</SelectItem>
              <SelectItem value="State">State</SelectItem>
              <SelectItem value="Institutional">Institutional</SelectItem>
              <SelectItem value="International">International</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant={verifiedOnly ? "default" : "outline"}
            onClick={() => setVerifiedOnly((v) => !v)}
            className="gap-2"
          >
            <Filter className="h-4 w-4" /> Verified only
          </Button>
        </div>
        {(q || category !== "all" || level !== "all" || verifiedOnly) && (
          <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border/40">
            <span className="text-xs text-muted-foreground">{filtered.length} match{filtered.length !== 1 ? "es" : ""}</span>
            <Button variant="ghost" size="sm" onClick={() => { setQ(""); setCategory("all"); setLevel("all"); setVerifiedOnly(false); }} className="ml-auto text-xs gap-1">
              <X className="h-3 w-3" /> Clear filters
            </Button>
          </div>
        )}
      </Card>

      {/* List */}
      {loading ? (
        <LoadingGrid count={9} />
      ) : filtered.length === 0 ? (
        <EmptyState
          title="No exams match your filters"
          description="Try clearing the filters or search with a different keyword."
          icon={Search}
          action={<Button onClick={() => { setQ(""); setCategory("all"); setLevel("all"); setVerifiedOnly(false); }} variant="outline">Clear filters</Button>}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((ex, i) => {
            const saved = isExamSaved(ex.id);
            const bm = isBookmarked("EXAM", ex.id);
            return (
              <Card key={ex.id} className="glass-card glass-card-hover animate-in-up" style={{ animationDelay: `${Math.min(i, 6) * 0.04}s` }}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <Badge variant="outline" className="text-[10px] border-electric/40 text-electric">{ex.category}</Badge>
                    <div className="flex items-center gap-1">
                      {ex.featured && <Badge className="bg-amber-500/15 text-amber-300 border-0 text-[10px]">Featured</Badge>}
                      <button
                        onClick={() => toggleBookmark("EXAM", ex.id)}
                        className="text-muted-foreground hover:text-cyan-glow p-1 rounded"
                        aria-label={bm ? "Remove bookmark" : "Add bookmark"}
                      >
                        {bm ? <BookmarkCheck className="h-3.5 w-3.5 text-cyan-glow" /> : <Bookmark className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                  </div>
                  <CardTitle className="text-base mt-2 cursor-pointer hover:text-electric" onClick={() => navigate("exams", ex.id)}>{ex.name}</CardTitle>
                  <CardDescription className="text-xs line-clamp-2">{ex.fullName}</CardDescription>
                </CardHeader>
                <CardContent className="pt-0 text-xs text-muted-foreground space-y-1.5">
                  <p className="flex items-center gap-1.5"><Building2 className="h-3 w-3 shrink-0" /> {ex.conductingAuthority}</p>
                  <p className="flex items-center gap-1.5"><FileText className="h-3 w-3 shrink-0" /> {ex.course}</p>
                  <div className="flex items-center gap-1.5 pt-1">
                    {ex.verified ? <VerifiedBadge /> : <UnverifiedBadge />}
                    <Badge variant="outline" className="text-[10px]">{ex.level}</Badge>
                  </div>
                  <div className="flex items-center justify-between pt-2 mt-1 border-t border-border/30">
                    <Button size="sm" variant="ghost" className="h-7 text-xs px-2" onClick={() => navigate("exams", ex.id)}>
                      Details <ArrowRight className="h-3 w-3 ml-1" />
                    </Button>
                    <Button
                      size="sm"
                      variant={saved ? "default" : "outline"}
                      className="h-7 text-xs px-2"
                      onClick={() => (saved ? unsaveExam(ex.id) : saveExam(ex.id))}
                    >
                      {saved ? "Saved" : "Save"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ExamDetail({ exam, onBack }: { exam: ReturnType<typeof getExamById> & object; onBack: () => void }) {
  const { navigate } = useRouter();
  const { saveExam, unsaveExam, isExamSaved, toggleBookmark, isBookmarked } = useStudentData();
  if (!exam) return null;
  const saved = isExamSaved(exam.id);
  const bm = isBookmarked("EXAM", exam.id);
  return (
    <div className="px-4 lg:px-10 py-8 max-w-5xl mx-auto animate-in-fade">
      <Button variant="ghost" size="sm" onClick={onBack} className="mb-4 gap-1">
        <ArrowLeft className="h-4 w-4" /> Back to directory
      </Button>
      <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="outline" className="border-electric/40 text-electric">{exam.category}</Badge>
            <Badge variant="outline">{exam.level}</Badge>
            {exam.featured && <Badge className="bg-amber-500/15 text-amber-300 border-0">Featured</Badge>}
            {exam.verified ? <VerifiedBadge /> : <UnverifiedBadge />}
          </div>
          <h1 className="text-3xl font-bold text-gradient-static">{exam.name}</h1>
          <p className="text-sm text-muted-foreground">{exam.fullName}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => toggleBookmark("EXAM", exam.id)} className="gap-1">
            {bm ? <BookmarkCheck className="h-4 w-4 text-cyan-glow" /> : <Bookmark className="h-4 w-4" />}
            {bm ? "Bookmarked" : "Bookmark"}
          </Button>
          <Button size="sm" variant={saved ? "default" : "outline"} onClick={() => (saved ? unsaveExam(exam.id) : saveExam(exam.id))} className="glow-button">
            {saved ? "Saved" : "Save exam"}
          </Button>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card className="glass-card p-5">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-electric mb-2">Overview</h2>
            <p className="text-sm">{exam.description}</p>
          </Card>
          <Card className="glass-card p-5 space-y-3">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-electric">Key information</h2>
            <dl className="grid sm:grid-cols-2 gap-3 text-sm">
              <div><dt className="text-xs text-muted-foreground">Conducting authority</dt><dd className="font-medium">{exam.conductingAuthority}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Course(s)</dt><dd className="font-medium">{exam.course}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Category</dt><dd className="font-medium">{exam.category}</dd></div>
              <div><dt className="text-xs text-muted-foreground">Level</dt><dd className="font-medium">{exam.level}</dd></div>
            </dl>
          </Card>
          <Card className="glass-card p-5">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-electric mb-2">Eligibility</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">{exam.eligibility}</p>
            {!exam.verified && (
              <p className="text-[11px] mt-2 text-amber-300/80 bg-amber-500/10 rounded px-2 py-1 border border-amber-500/20">
                Eligibility text has not been independently verified. Cross-check on the official portal before applying.
              </p>
            )}
          </Card>
          <Card className="glass-card p-5">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-electric mb-2">Application information</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">{exam.applicationInfo}</p>
            {!exam.verified && (
              <p className="text-[11px] mt-2 text-amber-300/80 bg-amber-500/10 rounded px-2 py-1 border border-amber-500/20">
                Application windows are not specified here. Always check the official notification for the current cycle.
              </p>
            )}
          </Card>
        </div>
        <div className="space-y-4">
          <Card className="glass-card p-5">
            <h3 className="text-sm font-semibold mb-3">Official portal</h3>
            <a href={exam.officialWebsite} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-electric hover:underline text-sm">
              <ExternalLink className="h-4 w-4" /> Visit official website
            </a>
            <p className="text-[11px] text-muted-foreground mt-2 break-all">{exam.officialWebsite}</p>
          </Card>
          <Card className="glass-card p-5">
            <h3 className="text-sm font-semibold mb-3">Practice</h3>
            <Button className="w-full glow-button mb-2" size="sm" onClick={() => navigate("mock-tests")}>
              Take a mock test
            </Button>
            <Button variant="outline" className="w-full" size="sm" onClick={() => navigate("guidance")}>
              Application guidance
            </Button>
          </Card>
          <Card className="glass-card p-5">
            <h3 className="text-sm font-semibold mb-2">Disclaimer</h3>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              INSTIQUEST aggregates publicly available information. Exam dates, eligibility and application windows
              change every cycle. Always verify on the official portal before applying.
            </p>
            <Button variant="link" className="h-auto p-0 mt-2 text-electric text-[11px]" onClick={() => navigate("disclaimer")}>
              Read full disclaimer <ArrowRight className="h-3 w-3 ml-1" />
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
