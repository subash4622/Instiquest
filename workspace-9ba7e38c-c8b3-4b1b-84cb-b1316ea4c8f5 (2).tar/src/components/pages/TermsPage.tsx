"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SectionHeading } from "@/components/common/ui-bits";
import { FileText, Scale, AlertTriangle, ShieldCheck } from "lucide-react";

const sections = [
  {
    title: "1. Acceptance of terms",
    body: "By accessing or using INSTIQUEST, you agree to be bound by these Terms of Use. If you do not agree with any part of these terms, please do not use the platform.",
  },
  {
    title: "2. Nature of the service",
    body: "INSTIQUEST is an educational information aggregator. It provides directory listings of entrance exams and institutions, original mock tests, an AI admission assistant and an institute advertising portal. The service is provided on an 'as is' basis and is currently a clearly-labelled demo build.",
  },
  {
    title: "3. Verified vs AI-generated content",
    body: "Verified directory entries display a green 'Verified' badge. Entries whose eligibility, dates or application windows could not be independently verified are clearly flagged as 'Unverified — pending review'. AI chatbot responses are labelled as 'AI Guidance' and are distinct from verified directory data. You must not rely on AI guidance as the sole basis for admission decisions.",
  },
  {
    title: "4. No warranty on dates and eligibility",
    body: "Exam dates, application windows and specific eligibility percentages change every cycle and across categories. INSTIQUEST does not warrant that any date or eligibility text shown is current. Always verify on the official portal linked from each exam page before applying.",
  },
  {
    title: "5. Mock test content",
    body: "All mock-test questions on INSTIQUEST are originally authored by the INSTIQUEST team. They are not copied from any copyrighted exam paper. They are intended for practice and do not represent the actual questions of any examination body.",
  },
  {
    title: "6. Institute advertising",
    body: "Institute advertising submissions are subject to admin moderation and approval. INSTIQUEST reserves the right to reject, edit or remove any advertisement at its sole discretion. Approval of an advertisement does not constitute an endorsement by INSTIQUEST of the advertising institute.",
  },
  {
    title: "7. User conduct",
    body: "You agree not to misuse the platform, including but not limited to: submitting fraudulent advertising requests, attempting to access admin features without authorisation, scraping bulk data, or using the AI assistant to generate unlawful, harmful or misleading content.",
  },
  {
    title: "8. Intellectual property",
    body: "The INSTIQUEST name, logo, design and original mock-test content are the property of the platform owner. Verified directory facts (exam names, conducting authorities, official websites) belong to their respective owners and are referenced for educational purposes.",
  },
  {
    title: "9. Limitation of liability",
    body: "To the maximum extent permitted by law, INSTIQUEST and its owner shall not be liable for any indirect, incidental or consequential damages arising from the use of, or inability to use, the platform — including any admission decisions made in reliance on information displayed here.",
  },
  {
    title: "10. Changes to these terms",
    body: "INSTIQUEST may update these Terms of Use at any time. Continued use of the platform after changes constitutes acceptance of the updated terms.",
  },
];

export function TermsPage() {
  return (
    <div className="px-4 lg:px-10 py-10 max-w-4xl mx-auto animate-in-fade">
      <SectionHeading
        eyebrow="Legal"
        title="Terms of Use"
        description="The terms under which you may use INSTIQUEST. This is a draft — replace with a reviewed version before launch."
      />
      <Card className="glass-card p-4 mb-6 text-xs text-muted-foreground flex items-start gap-2">
        <Badge variant="outline" className="border-amber-500/40 text-amber-300 bg-amber-500/10 text-[10px] shrink-0">Draft</Badge>
        <p>These terms are a template. Have them reviewed by a qualified legal professional before deploying to production.</p>
      </Card>
      <div className="space-y-4">
        {sections.map((s) => (
          <Card key={s.title} className="glass-card p-5">
            <h2 className="text-base font-semibold mb-1.5 flex items-center gap-2">
              <Scale className="h-4 w-4 text-electric" />
              {s.title}
            </h2>
            <CardContent className="p-0 text-sm text-muted-foreground leading-relaxed">{s.body}</CardContent>
          </Card>
        ))}
        <Card className="glass-card p-5 text-sm text-muted-foreground flex items-start gap-2">
          <ShieldCheck className="h-4 w-4 text-electric shrink-0 mt-0.5" />
          <p>For questions about these terms, contact the business email listed in the footer. Last updated: <span className="text-foreground">November 2026</span>.</p>
        </Card>
      </div>
    </div>
  );
}
