"use client";

import { useState } from "react";
import { useRouter } from "@/lib/router";
import { siteConfig } from "@/data/site-config";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { SectionHeading, DemoBadge } from "@/components/common/ui-bits";
import { Mail, MapPin, Phone, Send, Twitter, Linkedin, Youtube, Instagram, MessageSquare, Building2 } from "lucide-react";
import { toast } from "sonner";

export function ContactPage() {
  const { navigate } = useRouter();
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Name is required";
    if (!form.email.trim()) e.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "Enter a valid email address";
    if (!form.subject.trim()) e.subject = "Subject is required";
    if (!form.message.trim()) e.message = "Message is required";
    else if (form.message.length < 10) e.message = "Message must be at least 10 characters";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const onSubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    // Demo: simulate async submission
    await new Promise((r) => setTimeout(r, 800));
    setSubmitting(false);
    toast.success("Message sent (demo)", {
      description: "This is a demo contact form. In production this would email " + siteConfig.contact.businessEmail,
    });
    setForm({ name: "", email: "", subject: "", message: "" });
  };

  return (
    <div className="px-4 lg:px-10 py-10 max-w-6xl mx-auto animate-in-fade">
      <SectionHeading
        eyebrow="Get in touch"
        title="Contact INSTIQUEST"
        description="Reach the WEB CREATORS team with questions, feedback, partnership enquiries or advertising requests. All contact details below are configurable placeholders."
        action={<DemoBadge />}
      />

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Contact info cards */}
        <div className="space-y-4">
          <Card className="glass-card glass-card-hover p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="h-10 w-10 rounded-lg bg-electric/20 flex items-center justify-center">
                <Building2 className="h-5 w-5 text-electric" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Business contact (dedicated)</p>
                <p className="text-sm font-semibold">{siteConfig.contact.businessEmail}</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">For partnerships, advertising and institutional enquiries.</p>
            <a href={`mailto:${siteConfig.contact.businessEmail}`} className="text-xs text-electric hover:underline mt-2 inline-block">Send business email →</a>
          </Card>

          <Card className="glass-card glass-card-hover p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="h-10 w-10 rounded-lg bg-cyan-glow/20 flex items-center justify-center">
                <Mail className="h-5 w-5 text-cyan-glow" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Support</p>
                <p className="text-sm font-semibold">{siteConfig.contact.supportEmail}</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">For student queries and technical help.</p>
          </Card>

          <Card className="glass-card glass-card-hover p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="h-10 w-10 rounded-lg bg-purple-sub/20 flex items-center justify-center">
                <Phone className="h-5 w-5 text-purple-sub" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Phone (display only)</p>
                <p className="text-sm font-semibold">{siteConfig.contact.phoneDisplay}</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Placeholder — do not call. Configure in site-config.ts.</p>
          </Card>

          <Card className="glass-card glass-card-hover p-5">
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-electric mt-0.5" />
              <div>
                <p className="text-xs text-muted-foreground">Address</p>
                <p className="text-sm font-medium">{siteConfig.contact.address}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 mt-4 pt-4 border-t border-border/40">
              <a href={siteConfig.social.twitter} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-cyan-glow"><Twitter className="h-4 w-4" /></a>
              <a href={siteConfig.social.linkedin} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-cyan-glow"><Linkedin className="h-4 w-4" /></a>
              <a href={siteConfig.social.youtube} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-cyan-glow"><Youtube className="h-4 w-4" /></a>
              <a href={siteConfig.social.instagram} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-cyan-glow"><Instagram className="h-4 w-4" /></a>
            </div>
          </Card>
        </div>

        {/* Contact form */}
        <div className="lg:col-span-2">
          <Card className="glass-card p-6">
            <CardHeader className="px-0 pt-0">
              <CardTitle className="flex items-center gap-2"><MessageSquare className="h-5 w-5 text-electric" /> Send a message</CardTitle>
              <CardDescription>Demo form — submissions are not actually delivered. Use the business email above for real contact.</CardDescription>
            </CardHeader>
            <CardContent className="px-0">
              <form onSubmit={onSubmit} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Name *</Label>
                    <Input id="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1 bg-muted/30" />
                    {errors.name && <p className="text-xs text-destructive mt-1">{errors.name}</p>}
                  </div>
                  <div>
                    <Label htmlFor="email">Email *</Label>
                    <Input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="mt-1 bg-muted/30" />
                    {errors.email && <p className="text-xs text-destructive mt-1">{errors.email}</p>}
                  </div>
                </div>
                <div>
                  <Label htmlFor="subject">Subject *</Label>
                  <Input id="subject" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} className="mt-1 bg-muted/30" />
                  {errors.subject && <p className="text-xs text-destructive mt-1">{errors.subject}</p>}
                </div>
                <div>
                  <Label htmlFor="message">Message *</Label>
                  <Textarea id="message" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="mt-1 bg-muted/30 min-h-[140px]" />
                  {errors.message && <p className="text-xs text-destructive mt-1">{errors.message}</p>}
                </div>
                <div className="flex items-center justify-between">
                  <p className="text-[11px] text-muted-foreground">By submitting, you agree to our <button type="button" onClick={() => navigate("privacy")} className="text-electric hover:underline">privacy policy</button>.</p>
                  <Button type="submit" disabled={submitting} className="glow-button gap-2">
                    {submitting ? (
                      <><span className="h-3 w-3 border-2 border-primary-foreground border-t-transparent animate-spin rounded-full" /> Sending…</>
                    ) : (
                      <>Send message <Send className="h-4 w-4" /></>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          <Card className="glass-card p-4 mt-4 text-xs text-muted-foreground">
            <p className="flex items-center gap-2"><Badge variant="outline" className="border-amber-500/40 text-amber-300 bg-amber-500/10 text-[10px]">Configurable</Badge>
              All contact details are <strong className="text-foreground">placeholders</strong>. Update <code className="text-electric">src/data/site-config.ts</code> with real values before going live.
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
