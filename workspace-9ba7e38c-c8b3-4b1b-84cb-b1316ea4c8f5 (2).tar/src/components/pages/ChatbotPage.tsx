"use client";

import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AIBadge, VerifiedBadge, SectionHeading, EmptyState } from "@/components/common/ui-bits";
import { verifiedKB, searchKB, type KBEntry } from "@/data/kb";
import { siteConfig } from "@/data/site-config";
import {
  Send, Sparkles, ShieldCheck, AlertTriangle, RefreshCw,
  BookOpen, MessageSquare, Bot, User, Lightbulb, ExternalLink,
} from "lucide-react";

/**
 * INSTIQUEST AI Admission Chatbot
 * -------------------------------------------------------------
 * - All AI-generated replies are clearly labelled with the
 *   `AIBadge` and a disclaimer line so they are visually
 *   distinct from the verified KB facts shown with
 *   `VerifiedBadge`.
 * - The chat calls the server-side proxy at `/api/chat`. The
 *   frontend NEVER holds an API key. If the endpoint is
 *   unavailable, we gracefully fall back to surfacing the
 *   best matching verified KB entry as a verified fact.
 */

interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
  /** Marks this assistant message as a verified KB fact (no disclaimer). */
  verified?: boolean;
}

const STORAGE_KEY = "instiquest-chat";

const QUICK_QUESTIONS = [
  "How do I get into an IIT?",
  "What is the NEET counselling process?",
  "Tell me about CUET",
  "Explain negative marking in mock tests",
];

const WELCOME_MESSAGE: ChatMessage = {
  role: "assistant",
  content:
    "Hi, I'm the INSTIQUEST AI admission assistant. I can guide you on entrance exam routes, counselling processes, eligibility and timelines.\n\n" +
    "Two things to keep in mind:\n" +
    "• Replies I write carry an 'AI Guidance' badge — they are generated guidance, not verified directory data.\n" +
    "• Verified facts pulled from the INSTIQUEST knowledge base show a 'Verified' badge.\n\n" +
    "Always verify critical information on official portals before deciding. Ask away!",
};

export function ChatbotPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([WELCOME_MESSAGE]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hydrated, setHydrated] = useState(false);

  const scrollRef = useRef<HTMLDivElement | null>(null);
  const viewportRef = useRef<HTMLDivElement | null>(null);

  // ---------- Load from localStorage ----------
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as ChatMessage[];
        if (Array.isArray(parsed) && parsed.length > 0) {
          setMessages(parsed);
        }
      }
    } catch {
      // ignore malformed storage
    }
    setHydrated(true);
  }, []);

  // ---------- Persist to localStorage ----------
  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
    } catch {
      // storage may be full or disabled — non-fatal
    }
  }, [messages, hydrated]);

  // ---------- Smooth scroll to bottom on new message / loading change ----------
  const scrollToBottom = useCallback(() => {
    const el = viewportRef.current;
    if (el) {
      el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
    } else {
      const fallback = scrollRef.current;
      if (fallback) fallback.scrollTo({ top: fallback.scrollHeight, behavior: "smooth" });
    }
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading, scrollToBottom]);

  // ---------- Top verified KB entries for the side panel ----------
  const topKB = useMemo<KBEntry[]>(() => verifiedKB.slice(0, 8), []);

  // ---------- Send handler ----------
  const send = useCallback(async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || loading) return;

    setError(null);
    const userMsg: ChatMessage = { role: "user", content: trimmed };
    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: nextMessages.map((m) => ({ role: m.role, content: m.content })),
        }),
      });

      if (!res.ok) {
        throw new Error(`Chat endpoint responded with ${res.status}`);
      }

      const data = (await res.json()) as { content?: string; reply?: string; role?: string };
      const reply = data.content ?? data.reply ?? "";

      if (!reply) {
        throw new Error("Empty reply from assistant");
      }

      setMessages((prev) => [...prev, { role: "assistant", content: reply }]);
    } catch (err) {
      const reason = err instanceof Error ? err.message : "Unknown error";
      setError(`AI assistant unavailable (${reason}). Showing the best verified fact instead.`);

      // ---- Graceful fallback: surface the best matching verified KB entry ----
      const matches = searchKB(trimmed);
      const best = matches[0];

      if (best) {
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: best.answer,
            verified: true,
          },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content:
              "I couldn't reach the live AI service and no verified KB entry matched your question. " +
              "Please rephrase, or try one of the suggested questions below. " +
              "For critical deadlines, always check the official conducting-authority portal.",
          },
        ]);
      }
    } finally {
      setLoading(false);
    }
  }, [loading, messages]);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void send(input);
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void send(input);
    }
  };

  const clearChat = () => {
    setMessages([WELCOME_MESSAGE]);
    setError(null);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  return (
    <div className="px-4 lg:px-10 py-8 max-w-7xl mx-auto animate-in-fade">
      <SectionHeading
        eyebrow="AI Assistant"
        title="Admission Chatbot"
        description="Get instant guidance on exam routes, counselling, eligibility and timelines. AI responses are clearly labelled and distinct from verified directory data."
        action={<AIBadge label="AI Guidance" />}
      />

      {/* TOP DISCLAIMER BANNER */}
      <Card className="glass-card p-4 mb-6 border-amber-500/30 bg-amber-500/5">
        <div className="flex items-start gap-3 text-sm">
          <AlertTriangle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
          <p className="text-amber-100/90">
            <strong className="text-amber-200">AI responses are guidance only.</strong>{" "}
            Always verify critical information on official portals. API keys are kept server-side and
            never exposed in the browser. Provider:{" "}
            <span className="font-medium text-amber-200">{siteConfig.chatbot.providerLabel}</span>.
          </p>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">
        {/* CHAT THREAD */}
        <Card className="glass-card glass-card-hover overflow-hidden flex flex-col h-[calc(100vh-22rem)] min-h-[520px]">
          <CardHeader className="border-b border-border/40 pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="grid place-items-center h-8 w-8 rounded-lg bg-purple-sub/20 border border-purple-sub/40">
                  <Bot className="h-4 w-4 text-purple-sub" />
                </span>
                <div>
                  <CardTitle className="text-sm">INSTIQUEST AI Assistant</CardTitle>
                  <CardDescription className="text-xs">
                    Guidance · verified facts kept separate
                  </CardDescription>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-[10px] border-purple-sub/40 text-purple-sub">
                  {siteConfig.chatbot.enabled ? "Live" : "Demo"}
                </Badge>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={clearChat}
                  className="h-7 px-2 text-[11px] text-muted-foreground hover:text-foreground"
                >
                  <RefreshCw className="h-3 w-3 mr-1" /> Clear
                </Button>
              </div>
            </div>
          </CardHeader>

          {/* MESSAGES */}
          <div ref={scrollRef} className="flex-1 min-h-0 relative">
            <ScrollArea className="h-full">
              <div
                ref={viewportRef}
                className="px-4 py-4 space-y-4"
              >
                {messages.map((m, i) => (
                  <MessageBubble key={i} message={m} />
                ))}

                {/* Loading / typing indicator */}
                {loading && <TypingIndicator />}

                {/* Empty state for brand-new thread (no user msg yet) */}
                {!loading &&
                  messages.filter((m) => m.role === "user").length === 0 && (
                    <div className="pt-2">
                      <EmptyState
                        title="Ask your first question"
                        description="Pick a suggested question below or type your own. AI guidance is clearly labelled."
                        icon={Lightbulb}
                      />
                    </div>
                  )}
              </div>
            </ScrollArea>
          </div>

          {/* SUGGESTED QUICK QUESTIONS */}
          <div className="px-4 pt-3 border-t border-border/40">
            <div className="flex flex-wrap gap-2">
              {QUICK_QUESTIONS.map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => void send(q)}
                  disabled={loading}
                  className="text-[11px] px-2.5 py-1 rounded-full border border-purple-sub/30 bg-purple-sub/5 text-purple-sub hover:bg-purple-sub/15 transition-colors disabled:opacity-50"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* INPUT */}
          <form onSubmit={onSubmit} className="p-4 border-t border-border/40">
            <div className="flex items-end gap-2">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={onKeyDown}
                placeholder="Ask about exam routes, counselling, eligibility… (Enter to send, Shift+Enter for newline)"
                className="min-h-[52px] max-h-40 bg-muted/30 border-border/60 resize-none focus-visible:border-electric focus-visible:ring-electric/30"
                disabled={loading}
                aria-label="Chat message"
              />
              <Button
                type="submit"
                disabled={loading || !input.trim()}
                className="glow-button h-[52px] px-4 shrink-0"
                aria-label="Send message"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            {error && (
              <p className="mt-2 text-[11px] text-amber-300 flex items-center gap-1.5">
                <AlertTriangle className="h-3 w-3" /> {error}
              </p>
            )}
          </form>
        </Card>

        {/* VERIFIED KB QUICK REFERENCE PANEL */}
        <Card className="glass-card glass-card-hover h-fit lg:sticky lg:top-4">
          <CardHeader className="border-b border-border/40 pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-electric" />
                <CardTitle className="text-sm">Verified Quick Reference</CardTitle>
              </div>
              <VerifiedBadge />
            </div>
            <CardDescription className="text-xs">
              Short, factual entries from the INSTIQUEST knowledge base. These are not AI-generated.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-3">
            <ScrollArea className="h-[calc(100vh-26rem)] min-h-[300px]">
              <div className="space-y-2 pr-2">
                {topKB.map((e) => (
                  <div
                    key={e.id}
                    className="rounded-lg border border-border/50 bg-muted/20 p-2.5 hover:bg-electric/5 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <Badge variant="outline" className="text-[9px] border-electric/40 text-electric uppercase">
                        {e.category}
                      </Badge>
                      <VerifiedBadge />
                    </div>
                    <p className="text-[11.5px] leading-relaxed text-foreground/90">{e.answer}</p>
                  </div>
                ))}
              </div>
            </ScrollArea>

            <div className="mt-3 pt-3 border-t border-border/40 text-[11px] text-muted-foreground flex items-center gap-1.5">
              <BookOpen className="h-3 w-3" />
              {verifiedKB.length} verified entries · refreshed manually
            </div>
          </CardContent>
        </Card>
      </div>

      {/* LEGEND */}
      <Card className="glass-card mt-6 p-4">
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <AIBadge /> AI-generated guidance — verify on official portals.
          </span>
          <span className="flex items-center gap-1.5">
            <VerifiedBadge /> Verified fact from INSTIQUEST KB.
          </span>
          <span className="flex items-center gap-1.5">
            <MessageSquare className="h-3 w-3" /> Thread auto-saved to this browser only.
          </span>
        </div>
      </Card>
    </div>
  );
}

// ---------- Message bubble ----------
function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";
  const isVerified = message.verified === true;

  return (
    <div className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}>
      {/* Avatar */}
      <span
        className={`grid place-items-center h-8 w-8 rounded-lg shrink-0 ${
          isUser
            ? "bg-electric/20 border border-electric/40"
            : isVerified
            ? "bg-electric/15 border border-electric/40"
            : "bg-purple-sub/20 border border-purple-sub/40"
        }`}
      >
        {isUser ? (
          <User className="h-4 w-4 text-electric" />
        ) : isVerified ? (
          <ShieldCheck className="h-4 w-4 text-electric" />
        ) : (
          <Bot className="h-4 w-4 text-purple-sub" />
        )}
      </span>

      {/* Bubble */}
      <div className={`max-w-[80%] ${isUser ? "items-end text-right" : ""}`}>
        <div className="flex items-center gap-2 mb-1 flex-wrap" style={{ justifyContent: isUser ? "flex-end" : "flex-start" }}>
          {isUser ? (
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground">You</span>
          ) : isVerified ? (
            <VerifiedBadge label="Verified fact" />
          ) : (
            <AIBadge />
          )}
        </div>
        <div
          className={`rounded-xl px-3.5 py-2.5 text-sm whitespace-pre-wrap leading-relaxed ${
            isUser
              ? "bg-electric/15 border border-electric/30 text-foreground"
              : isVerified
              ? "bg-electric/10 border border-electric/30 text-foreground"
              : "bg-purple-sub/10 border border-purple-sub/30 text-foreground"
          }`}
        >
          {message.content}
        </div>
        {/* AI disclaimer line */}
        {!isUser && !isVerified && (
          <p className="mt-1 text-[10px] text-muted-foreground flex items-center gap-1">
            <AlertTriangle className="h-2.5 w-2.5" />
            AI-generated guidance. Verify on official portals.
          </p>
        )}
      </div>
    </div>
  );
}

// ---------- Typing indicator ----------
function TypingIndicator() {
  return (
    <div className="flex gap-3">
      <span className="grid place-items-center h-8 w-8 rounded-lg bg-purple-sub/20 border border-purple-sub/40">
        <Sparkles className="h-4 w-4 text-purple-sub" />
      </span>
      <div className="flex items-center gap-1.5 px-3.5 py-3 rounded-xl bg-purple-sub/10 border border-purple-sub/30">
        <span className="h-2 w-2 rounded-full bg-purple-sub pulse-glow" />
        <span className="h-2 w-2 rounded-full bg-purple-sub pulse-glow" style={{ animationDelay: "0.2s" }} />
        <span className="h-2 w-2 rounded-full bg-purple-sub pulse-glow" style={{ animationDelay: "0.4s" }} />
        <span className="ml-2 text-[11px] text-muted-foreground">AI is typing…</span>
      </div>
    </div>
  );
}

// Re-export so callers can use KB search without a separate import path.
export { searchKB };
export type { ChatMessage };
