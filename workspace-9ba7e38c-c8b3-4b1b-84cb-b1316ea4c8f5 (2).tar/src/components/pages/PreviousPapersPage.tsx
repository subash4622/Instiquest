"use client";

import { useState, useMemo } from "react";
import { useRouter } from "@/lib/router";
import { previousPaperSources, REVIEW } from "@/data/previous-papers";
import { exams } from "@/data/exams";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SectionHeading, VerifiedBadge, UnverifiedBadge, EmptyState, StatBlock } from "@/components/common/ui-bits";
import { Search, ExternalLink, FileQuestion, FileText, ShieldCheck, AlertTriangle, Info, BookOpen } from "lucide-react";

export function PreviousPapersPage() {
  const { navigate } = useRouter();
  const [q, setQ] = useState("");
  const [type, setType] = useState("all");

  const filtered = useMemo(() => {
    return previousPaperSources.filter((p) => {
      if (type !== "all" && p.paperType !== type) return false;
      if (q.trim()) {
        const s = q.toLowerCase();
        if (!`${p.examName} ${p.paperType} ${p.availability} ${p.notes ?? ""}`.toLowerCase().includes(s)) return false;
      }
      return true;
    });
  }, [q, type]);

  const paperTypes = Array.from(new Set(previousPaperSources.map((p) => p.paperType)));

  return (
    <div className="px-4 lg:px-10 py-10 max-w-6xl mx-auto animate-in-fade">
      <SectionHeading
        eyebrow="Resources"
        title="Previous Year Question Papers"
        description="Direct links to the official portals where exam authorities publish previous year papers, sample papers and question banks. INSTIQUEST does NOT host copyrighted papers — every link goes to the official source."
      />

      {/* Notice card */}
      <Card className="glass-card p-4 mb-6 border-l-4 border-l-primary">
        <div className="flex items-start gap-3">
          <ShieldCheck className="h-5 w-5 text-primary shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="font-semibold text-foreground mb-1">Why we link to official sources only</p>
            <p className="text-muted-foreground leading-relaxed">
              Previous year question papers are typically owned by the respective examination authorities.
              INSTIQUEST does not host, reproduce or redistribute copyrighted exam papers. Instead, we link
              directly to the official portals where the authorities themselves publish past papers and
              sample tests. Always download from the official source to ensure authenticity.
            </p>
          </div>
        </div>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <StatBlock label="Official sources" value={previousPaperSources.length} icon={ExternalLink} />
        <StatBlock label="Verified links" value={previousPaperSources.filter((p) => p.verified).length} icon={ShieldCheck} accent="cyan" />
        <StatBlock label="Paper types" value={paperTypes.length} icon={FileText} accent="purple" />
      </div>

      {/* Filters */}
      <Card className="glass-card p-4 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="relative sm:col-span-2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by exam name or paper type…" className="pl-9 bg-muted/30" />
          </div>
          <Select value={type} onValueChange={setType}>
            <SelectTrigger className="bg-muted/30"><SelectValue placeholder="Paper type" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              {paperTypes.map((t) => (
                <SelectItem key={t} value={t}>{t}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Sources */}
      {filtered.length === 0 ? (
        <EmptyState
          title="No sources match your filters"
          description="Try clearing the filters or searching for a different exam."
          icon={FileQuestion}
          action={<Button variant="outline" onClick={() => { setQ(""); setType("all"); }}>Clear filters</Button>}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filtered.map((p, i) => (
            <Card key={p.id} className="glass-card glass-card-hover animate-in-up" style={{ animationDelay: `${Math.min(i, 6) * 0.05}s` }}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <CardTitle className="text-base flex items-center gap-2">
                      <BookOpen className="h-4 w-4 text-primary" />
                      {p.examName}
                    </CardTitle>
                    <CardDescription className="text-xs mt-1">{p.paperType}</CardDescription>
                  </div>
                  {p.verified ? <VerifiedBadge /> : <UnverifiedBadge />}
                </div>
              </CardHeader>
              <CardContent className="pt-0 space-y-2 text-xs">
                <p className="text-muted-foreground">
                  <span className="text-muted-foreground/70">Availability:</span> {p.availability}
                </p>
                {p.notes && (
                  <div className="flex items-start gap-2 p-2 rounded bg-muted/30 border border-border/40">
                    <Info className="h-3 w-3 text-accent shrink-0 mt-0.5" />
                    <p className="text-muted-foreground leading-relaxed">{p.notes}</p>
                  </div>
                )}
                <div className="flex items-center justify-between pt-2 mt-1 border-t border-border/30">
                  <Button size="sm" variant="ghost" onClick={() => navigate("exams", p.examId)} className="h-7 text-xs">
                    View exam details
                  </Button>
                  <a href={p.officialUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs text-primary hover:underline font-medium">
                    <ExternalLink className="h-3 w-3" /> Open official source
                  </a>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Disclaimer */}
      <Card className="glass-card p-4 mt-8 border-l-4 border-l-amber-500">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs text-muted-foreground">
            <p className="font-semibold text-foreground mb-1">Disclaimer</p>
            <p>
              INSTIQUEST aggregates links to official sources for convenience only. The availability, format
              and licensing of previous year papers is determined solely by the respective examination
              authorities. Some authorities may require candidate login to access papers. Do not redistribute
              copyrighted papers; always refer to the official portal for the latest authentic content.
            </p>
            <p className="mt-2">
              If an official source URL is broken or you believe a source is missing, please report it via the{" "}
              <button onClick={() => navigate("contact")} className="text-primary hover:underline">contact page</button>.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
