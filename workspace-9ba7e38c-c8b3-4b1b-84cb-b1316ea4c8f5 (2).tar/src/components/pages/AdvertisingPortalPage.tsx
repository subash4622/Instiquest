"use client";

import { useState, useEffect, useMemo, useCallback } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SectionHeading, DemoBadge } from "@/components/common/ui-bits";
import { siteConfig } from "@/data/site-config";
import { useAuth } from "@/lib/stores";
import {
  Megaphone,
  ShieldCheck,
  CheckCircle2,
  Clock,
  XCircle,
  Rocket,
  CreditCard,
  ExternalLink,
  Send,
  Inbox,
  AlertTriangle,
  ArrowRight,
} from "lucide-react";

/**
 * INSTIQUEST Institute Advertising Portal
 * -------------------------------------------------------------
 * Institutes submit banner-ad requests. No ad is ever published
 * automatically — every submission goes through admin moderation
 * before being displayed anywhere on the platform. Payment
 * integration is a demo placeholder (clearly labelled).
 *
 * Submissions are sent to `/api/ads`. If the endpoint is not
 * available (e.g. in the preview sandbox), we simulate the same
 * flow client-side, persist the submission to localStorage so an
 * admin can review it later, and clearly label it as a demo.
 */

type SubmissionStatus = "Pending" | "Approved" | "Rejected" | "Published";

interface AdSubmission {
  id: string;
  createdAt: number;
  status: SubmissionStatus;
  // form payload
  instituteName: string;
  contactEmail: string;
  contactPhone?: string;
  instituteWebsite?: string;
  bannerHeadline: string;
  bannerCopy: string;
  landingUrl?: string;
  campaignStart?: string;
  campaignEnd?: string;
  additionalMessage?: string;
}

const STORAGE_KEY = "instiquest-ad-submissions";

// ---------- Validators ----------
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const URL_RE = /^(https?:\/\/)?([\w-]+\.)+[\w-]{2,}(\/[\w\-./?%&=#]*)?$/i;
// Indian phone: optional +91, then 10 digits starting 6-9
const PHONE_RE = /^(\+91[\-\s]?)?[6-9]\d{9}$/;

interface FormState {
  instituteName: string;
  contactEmail: string;
  contactPhone: string;
  instituteWebsite: string;
  bannerHeadline: string;
  bannerCopy: string;
  landingUrl: string;
  campaignStart: string;
  campaignEnd: string;
  additionalMessage: string;
}

const EMPTY_FORM: FormState = {
  instituteName: "",
  contactEmail: "",
  contactPhone: "",
  instituteWebsite: "",
  bannerHeadline: "",
  bannerCopy: "",
  landingUrl: "",
  campaignStart: "",
  campaignEnd: "",
  additionalMessage: "",
};

interface FormErrors {
  instituteName?: string;
  contactEmail?: string;
  contactPhone?: string;
  instituteWebsite?: string;
  bannerHeadline?: string;
  bannerCopy?: string;
  landingUrl?: string;
  campaignEnd?: string;
  additionalMessage?: string;
}

function validate(form: FormState): FormErrors {
  const e: FormErrors = {};

  if (!form.instituteName.trim()) e.instituteName = "Institute name is required.";
  else if (form.instituteName.trim().length < 3) e.instituteName = "Must be at least 3 characters.";

  if (!form.contactEmail.trim()) e.contactEmail = "Contact email is required.";
  else if (!EMAIL_RE.test(form.contactEmail.trim())) e.contactEmail = "Enter a valid email address.";

  if (form.contactPhone.trim() && !PHONE_RE.test(form.contactPhone.trim())) {
    e.contactPhone = "Enter a valid Indian phone (e.g. +91 9876543210).";
  }

  if (form.instituteWebsite.trim() && !URL_RE.test(form.instituteWebsite.trim())) {
    e.instituteWebsite = "Enter a valid URL.";
  }

  if (!form.bannerHeadline.trim()) e.bannerHeadline = "Banner headline is required.";
  else if (form.bannerHeadline.length > 80) e.bannerHeadline = "Max 80 characters.";

  if (!form.bannerCopy.trim()) e.bannerCopy = "Banner copy is required.";
  else if (form.bannerCopy.length > 200) e.bannerCopy = "Max 200 characters.";

  if (form.landingUrl.trim() && !URL_RE.test(form.landingUrl.trim())) {
    e.landingUrl = "Enter a valid URL.";
  }

  if (
    form.campaignStart &&
    form.campaignEnd &&
    new Date(form.campaignEnd) < new Date(form.campaignStart)
  ) {
    e.campaignEnd = "End date must be after the start date.";
  }

  if (form.additionalMessage.length > 500) {
    e.additionalMessage = "Max 500 characters.";
  }

  return e;
}

export function AdvertisingPortalPage() {
  const user = useAuth((s) => s.user);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState<{ ref: string; demo: boolean } | null>(null);
  const [submissions, setSubmissions] = useState<AdSubmission[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [filterStatus, setFilterStatus] = useState<"all" | SubmissionStatus>("all");

  // ---------- Pre-fill contact email if signed in ----------
  useEffect(() => {
    if (user?.email) {
      setForm((f) => (f.contactEmail ? f : { ...f, contactEmail: user.email! }));
    }
  }, [user]);

  // ---------- Load prior submissions from localStorage ----------
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as AdSubmission[];
        if (Array.isArray(parsed)) setSubmissions(parsed);
      }
    } catch {
      // ignore
    }
    setHydrated(true);
  }, []);

  // ---------- Persist submissions ----------
  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(submissions));
    } catch {
      // ignore quota errors
    }
  }, [submissions, hydrated]);

  const errors = useMemo(() => validate(form), [form]);
  const isValid = Object.keys(errors).length === 0;

  const set = useCallback(
    <K extends keyof FormState>(key: K, value: FormState[K]) => {
      setForm((prev) => ({ ...prev, [key]: value }));
    },
    []
  );

  // ---------- Submit ----------
  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting || !isValid) return;

    setSubmitting(true);
    setSuccess(null);

    const payload: Omit<AdSubmission, "id" | "createdAt" | "status"> = {
      instituteName: form.instituteName.trim(),
      contactEmail: form.contactEmail.trim(),
      contactPhone: form.contactPhone.trim() || undefined,
      instituteWebsite: form.instituteWebsite.trim() || undefined,
      bannerHeadline: form.bannerHeadline.trim(),
      bannerCopy: form.bannerCopy.trim(),
      landingUrl: form.landingUrl.trim() || undefined,
      campaignStart: form.campaignStart || undefined,
      campaignEnd: form.campaignEnd || undefined,
      additionalMessage: form.additionalMessage.trim() || undefined,
    };

    let refId = "";
    let demo = false;

    try {
      const res = await fetch("/api/ads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) throw new Error(`Endpoint responded with ${res.status}`);

      const data = (await res.json()) as { id?: string; referenceId?: string; status?: SubmissionStatus };
      refId = data.id ?? data.referenceId ?? `AD-${Date.now().toString(36).toUpperCase()}`;
      const status: SubmissionStatus = data.status ?? "Pending";

      const newSub: AdSubmission = {
        id: refId,
        createdAt: Date.now(),
        status,
        ...payload,
      };
      setSubmissions((prev) => [newSub, ...prev]);
      toast.success("Submission received", {
        description: `Reference ID: ${refId} — status: ${status}. Admin review required.`,
      });
      setSuccess({ ref: refId, demo: false });
      setForm(EMPTY_FORM);
    } catch (err) {
      // ---- Fallback: simulate client-side (clearly labelled demo) ----
      demo = true;
      refId = `AD-DEMO-${Date.now().toString(36).toUpperCase()}`;
      const newSub: AdSubmission = {
        id: refId,
        createdAt: Date.now(),
        status: "Pending",
        ...payload,
      };
      setSubmissions((prev) => [newSub, ...prev]);

      const reason = err instanceof Error ? err.message : "endpoint unavailable";
      toast.warning("Demo submission saved locally", {
        description: `/api/ads unavailable (${reason}). Submission stored in your browser for admin review.`,
      });
      setSuccess({ ref: refId, demo: true });
      // Keep the form filled in demo mode so the user can re-submit when the
      // endpoint is back — but we still clear it to avoid double-submit.
      setForm(EMPTY_FORM);
    } finally {
      setSubmitting(false);
    }
  };

  // ---------- Filter submissions ----------
  const visibleSubs = useMemo(() => {
    if (filterStatus === "all") return submissions;
    return submissions.filter((s) => s.status === filterStatus);
  }, [submissions, filterStatus]);

  const statusCounts = useMemo(() => {
    const base: Record<SubmissionStatus, number> = {
      Pending: 0,
      Approved: 0,
      Rejected: 0,
      Published: 0,
    };
    for (const s of submissions) base[s.status]++;
    return base;
  }, [submissions]);

  return (
    <div className="px-4 lg:px-10 py-8 max-w-6xl mx-auto animate-in-fade">
      <SectionHeading
        eyebrow="For Institutes"
        title="Institute Advertising Portal"
        description="Submit a banner-ad request for your institute. Every submission is moderated by an INSTIQUEST admin before publication."
        action={<DemoBadge label="Demo submission portal" />}
      />

      {/* WORKFLOW INTRO CARD */}
      <Card className="glass-card glass-card-hover mb-6">
        <CardHeader className="border-b border-border/40 pb-3">
          <div className="flex items-center gap-2">
            <Megaphone className="h-4 w-4 text-electric" />
            <CardTitle className="text-base">How it works</CardTitle>
          </div>
          <CardDescription className="text-xs">
            Transparent, moderated publishing — never automatic.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 mb-4">
            {[
              { n: "1", t: "Submit", d: "Fill the form below.", icon: Send },
              { n: "2", t: "Admin moderation", d: "INSTIQUEST reviews.", icon: ShieldCheck },
              { n: "3", t: "Approved", d: "You're notified.", icon: CheckCircle2 },
              { n: "4", t: "Published", d: "Live on platform.", icon: Rocket },
            ].map((step) => (
              <div
                key={step.n}
                className="rounded-lg border border-border/50 bg-muted/20 p-3 flex flex-col gap-1"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold tracking-wider text-electric">
                    STEP {step.n}
                  </span>
                  <step.icon className="h-3.5 w-3.5 text-muted-foreground" />
                </div>
                <p className="text-sm font-medium">{step.t}</p>
                <p className="text-[11px] text-muted-foreground">{step.d}</p>
              </div>
            ))}
          </div>
          <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-xs text-amber-100/90 flex items-start gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
            <p>
              <strong className="text-amber-200">No advertisement is published automatically</strong>{" "}
              without admin approval. Payment integration is a demo placeholder — no real charges
              are made.
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-6">
        {/* SUBMISSION FORM */}
        <Card className="glass-card glass-card-hover">
          <CardHeader className="border-b border-border/40 pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">Submit a banner advertisement</CardTitle>
              {user && (
                <Badge variant="outline" className="text-[10px] border-electric/40 text-electric">
                  Signed in as {user.email}
                </Badge>
              )}
            </div>
            <CardDescription className="text-xs">
              All fields marked with <span className="text-electric">*</span> are required.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <form onSubmit={onSubmit} className="space-y-4" noValidate>
              {/* Institute name */}
              <Field
                label="Institute name"
                required
                error={errors.instituteName}
              >
                <Input
                  value={form.instituteName}
                  onChange={(e) => set("instituteName", e.target.value)}
                  placeholder="e.g. National Institute of Excellence"
                  maxLength={120}
                  aria-invalid={!!errors.instituteName}
                />
              </Field>

              {/* Contact email + phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="Contact email" required error={errors.contactEmail}>
                  <Input
                    type="email"
                    value={form.contactEmail}
                    onChange={(e) => set("contactEmail", e.target.value)}
                    placeholder="admissions@your-institute.in"
                    aria-invalid={!!errors.contactEmail}
                  />
                </Field>
                <Field
                  label="Contact phone"
                  hint="Indian format"
                  error={errors.contactPhone}
                >
                  <Input
                    value={form.contactPhone}
                    onChange={(e) => set("contactPhone", e.target.value)}
                    placeholder="+91 9876543210"
                    inputMode="tel"
                  />
                </Field>
              </div>

              {/* Website + landing URL */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="Institute website" error={errors.instituteWebsite}>
                  <Input
                    value={form.instituteWebsite}
                    onChange={(e) => set("instituteWebsite", e.target.value)}
                    placeholder="https://your-institute.in"
                    inputMode="url"
                  />
                </Field>
                <Field label="Landing URL" error={errors.landingUrl}>
                  <Input
                    value={form.landingUrl}
                    onChange={(e) => set("landingUrl", e.target.value)}
                    placeholder="https://your-institute.in/apply"
                    inputMode="url"
                  />
                </Field>
              </div>

              {/* Banner headline */}
              <Field
                label="Banner headline"
                required
                hint={`${form.bannerHeadline.length}/80`}
                error={errors.bannerHeadline}
              >
                <Input
                  value={form.bannerHeadline}
                  onChange={(e) => set("bannerHeadline", e.target.value)}
                  placeholder="Admissions open for B.Tech 2025"
                  maxLength={80}
                  aria-invalid={!!errors.bannerHeadline}
                />
              </Field>

              {/* Banner copy */}
              <Field
                label="Banner copy"
                required
                hint={`${form.bannerCopy.length}/200`}
                error={errors.bannerCopy}
              >
                <Textarea
                  value={form.bannerCopy}
                  onChange={(e) => set("bannerCopy", e.target.value)}
                  placeholder="Short, clear copy shown on the banner. State the offer, eligibility and a CTA."
                  maxLength={200}
                  className="min-h-[80px]"
                  aria-invalid={!!errors.bannerCopy}
                />
              </Field>

              {/* Campaign dates */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="Campaign start" hint="optional">
                  <Input
                    type="date"
                    value={form.campaignStart}
                    onChange={(e) => set("campaignStart", e.target.value)}
                  />
                </Field>
                <Field
                  label="Campaign end"
                  hint="optional"
                  error={errors.campaignEnd}
                >
                  <Input
                    type="date"
                    value={form.campaignEnd}
                    onChange={(e) => set("campaignEnd", e.target.value)}
                    aria-invalid={!!errors.campaignEnd}
                  />
                </Field>
              </div>

              {/* Additional message */}
              <Field
                label="Additional message"
                hint={`${form.additionalMessage.length}/500`}
                error={errors.additionalMessage}
              >
                <Textarea
                  value={form.additionalMessage}
                  onChange={(e) => set("additionalMessage", e.target.value)}
                  placeholder="Anything else our admin team should know — targeting, course highlight, regional focus…"
                  maxLength={500}
                  className="min-h-[80px]"
                />
              </Field>

              <div className="flex items-center justify-between gap-3 pt-2 border-t border-border/40">
                <p className="text-[11px] text-muted-foreground flex items-center gap-1.5">
                  <ShieldCheck className="h-3 w-3 text-electric" />
                  Submission triggers admin review — never auto-publish.
                </p>
                <Button
                  type="submit"
                  disabled={submitting || !isValid}
                  className="glow-button"
                >
                  {submitting ? (
                    <>
                      <span className="h-3.5 w-3.5 rounded-full border-2 border-white/40 border-t-white animate-spin" />
                      Submitting…
                    </>
                  ) : (
                    <>
                      Submit for review <ArrowRight className="h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>
            </form>

            {/* SUCCESS CARD */}
            {success && (
              <Card className="mt-4 border-electric/40 bg-electric/5">
                <CardContent className="pt-4">
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="h-5 w-5 text-electric shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-semibold">Submission received</p>
                        <Badge variant="outline" className="text-[10px] border-amber-500/40 text-amber-300 bg-amber-500/10">
                          Pending review
                        </Badge>
                        {success.demo && <DemoBadge label="Demo (saved locally)" />}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Reference ID:{" "}
                        <code className="font-mono text-electric bg-muted/30 px-1.5 py-0.5 rounded">
                          {success.ref}
                        </code>
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        An INSTIQUEST admin will review your request. You'll see the status update
                        in the panel on the right. No ad is published without approval.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </CardContent>
        </Card>

        {/* SUBMISSIONS STATUS PANEL */}
        <Card className="glass-card glass-card-hover h-fit lg:sticky lg:top-4">
          <CardHeader className="border-b border-border/40 pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Inbox className="h-4 w-4 text-electric" />
                <CardTitle className="text-sm">Submissions status</CardTitle>
              </div>
              <DemoBadge label="Admin review required" />
            </div>
            <CardDescription className="text-xs">
              Your previous submissions and their current moderation status.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-3 space-y-3">
            {/* Status summary */}
            <div className="grid grid-cols-4 gap-2">
              <StatusPill label="Pending" count={statusCounts.Pending} icon={Clock} color="amber" />
              <StatusPill label="Approved" count={statusCounts.Approved} icon={CheckCircle2} color="electric" />
              <StatusPill label="Rejected" count={statusCounts.Rejected} icon={XCircle} color="red" />
              <StatusPill label="Published" count={statusCounts.Published} icon={Rocket} color="cyan" />
            </div>

            {/* Filter */}
            <div className="flex items-center gap-2">
              <Label className="text-[11px] text-muted-foreground">Filter:</Label>
              <Select
                value={filterStatus}
                onValueChange={(v) => setFilterStatus(v as typeof filterStatus)}
              >
                <SelectTrigger size="sm" className="h-7 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Approved">Approved</SelectItem>
                  <SelectItem value="Rejected">Rejected</SelectItem>
                  <SelectItem value="Published">Published</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* List */}
            <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
              {visibleSubs.length === 0 ? (
                <div className="text-center py-8 text-xs text-muted-foreground">
                  <Inbox className="h-6 w-6 mx-auto mb-2 opacity-50" />
                  No submissions {filterStatus !== "all" && `with status "${filterStatus}"`} yet.
                </div>
              ) : (
                visibleSubs.map((s) => (
                  <div
                    key={s.id}
                    className="rounded-lg border border-border/50 bg-muted/20 p-2.5"
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <p className="text-xs font-semibold truncate">{s.instituteName}</p>
                      <StatusBadge status={s.status} />
                    </div>
                    <p className="text-[11px] text-muted-foreground truncate">
                      “{s.bannerHeadline}”
                    </p>
                    <div className="flex items-center justify-between mt-1.5 text-[10px] text-muted-foreground">
                      <span>
                        {new Date(s.createdAt).toLocaleString(undefined, {
                          dateStyle: "medium",
                          timeStyle: "short",
                        })}
                      </span>
                      <code className="font-mono text-electric bg-muted/30 px-1 py-0.5 rounded">
                        {s.id}
                      </code>
                    </div>
                  </div>
                ))
              )}
            </div>

            <p className="text-[11px] text-muted-foreground pt-2 border-t border-border/40 flex items-center gap-1.5">
              <ShieldCheck className="h-3 w-3 text-electric" />
              Only an INSTIQUEST admin can move a submission from Pending → Approved → Published.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* PAYMENT PLACEHOLDER CARD */}
      <Card className="glass-card glass-card-hover mt-6">
        <CardHeader className="border-b border-border/40 pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CreditCard className="h-4 w-4 text-purple-sub" />
              <CardTitle className="text-base">Payment integration</CardTitle>
            </div>
            <DemoBadge label="Payment integration (placeholder)" />
          </div>
          <CardDescription className="text-xs">
            Provider: {siteConfig.payments.providerLabel} · Enabled: {String(siteConfig.payments.enabled)}
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-4">
          <p className="text-sm text-muted-foreground">
            Checkout flow is a placeholder. Not enabled in demo. When enabled, approved
            advertisements will be billed via a server-side checkout session. API keys are kept
            server-side only.
          </p>
          <Button
            asChild
            variant="outline"
            size="sm"
            className="mt-3 gap-2 border-purple-sub/40 text-purple-sub hover:bg-purple-sub/10"
          >
            <a href={siteConfig.payments.apiEndpoint} target="_blank" rel="noopener noreferrer">
              <ExternalLink className="h-3.5 w-3.5" />
              Checkout endpoint (placeholder)
            </a>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

// ---------- Field wrapper ----------
function Field({
  label,
  required,
  hint,
  error,
  children,
}: {
  label: string;
  required?: boolean;
  hint?: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <Label className="text-xs">
          {label} {required && <span className="text-electric">*</span>}
        </Label>
        {hint && <span className="text-[10px] text-muted-foreground">{hint}</span>}
      </div>
      {children}
      {error && (
        <p className="text-[11px] text-destructive flex items-center gap-1">
          <AlertTriangle className="h-3 w-3" /> {error}
        </p>
      )}
    </div>
  );
}

// ---------- Status pill ----------
function StatusPill({
  label,
  count,
  icon: Icon,
  color,
}: {
  label: string;
  count: number;
  icon: React.ComponentType<{ className?: string }>;
  color: "amber" | "electric" | "red" | "cyan";
}) {
  const colorMap = {
    amber: "border-amber-500/40 text-amber-300 bg-amber-500/10",
    electric: "border-electric/40 text-electric bg-electric/10",
    red: "border-red-500/40 text-red-300 bg-red-500/10",
    cyan: "border-cyan-glow/40 text-cyan-glow bg-cyan-glow/10",
  } as const;
  return (
    <div className={`rounded-md border p-2 text-center ${colorMap[color]}`}>
      <Icon className="h-3 w-3 mx-auto mb-0.5" />
      <p className="text-sm font-bold leading-none">{count}</p>
      <p className="text-[9px] uppercase tracking-wider mt-1 opacity-80">{label}</p>
    </div>
  );
}

// ---------- Status badge ----------
function StatusBadge({ status }: { status: SubmissionStatus }) {
  const map: Record<
    SubmissionStatus,
    { className: string; icon: React.ComponentType<{ className?: string }> }
  > = {
    Pending: {
      className: "border-amber-500/40 text-amber-300 bg-amber-500/10",
      icon: Clock,
    },
    Approved: {
      className: "border-electric/40 text-electric bg-electric/10",
      icon: CheckCircle2,
    },
    Rejected: {
      className: "border-red-500/40 text-red-300 bg-red-500/10",
      icon: XCircle,
    },
    Published: {
      className: "border-cyan-glow/40 text-cyan-glow bg-cyan-glow/10",
      icon: Rocket,
    },
  };
  const cfg = map[status];
  const Icon = cfg.icon;
  return (
    <Badge variant="outline" className={`text-[10px] gap-1 ${cfg.className}`}>
      <Icon className="h-3 w-3" /> {status}
    </Badge>
  );
}
