"use client";

import { useState, useMemo } from "react";
import { useRouter } from "@/lib/router";
import { exams, getFeaturedExams, examCategories } from "@/data/exams";
import { institutions, getFeaturedInstitutions } from "@/data/institutions";
import { mockTests } from "@/data/mock-tests";
import { announcements, getPinnedAnnouncements } from "@/data/announcements";
import { siteConfig } from "@/data/site-config";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { SectionHeading, StatBlock, VerifiedBadge, UnverifiedBadge, DemoBadge } from "@/components/common/ui-bits";
import { VisitCounterPill, VisitStats } from "@/components/common/VisitCounter";
import {
  Search, ArrowRight, Sparkles, BookOpen, Building2, Brain, Compass,
  Megaphone, GraduationCap, TrendingUp, Trophy, Users, FileText,
  ExternalLink, Bell, ChevronRight, Star,
} from "lucide-react";

export function HomePage() {
  const { navigate } = useRouter();
  const [q, setQ] = useState("");

  const featuredExams = useMemo(() => getFeaturedExams(), []);
  const featuredInstitutions = useMemo(() => getFeaturedInstitutions(), []);
  const pinned = useMemo(() => getPinnedAnnouncements(), []);

  const stats = [
    { label: "Entrance Exams", value: `${exams.length}+`, icon: BookOpen, accent: "electric" as const },
    { label: "Institutions", value: `${institutions.length}+`, icon: Building2, accent: "cyan" as const },
    { label: "Mock Tests", value: `${mockTests.length}`, icon: Brain, accent: "purple" as const },
    { label: "Exam Categories", value: `${examCategories.length}`, icon: GraduationCap, accent: "electric" as const },
  ];

  const onSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate("exams", undefined, q.trim() ? { q: q.trim() } : undefined);
  };

  return (
    <div className="animate-in-fade">
      {/* HERO */}
      <section className="relative overflow-hidden bg-aurora border-b border-border/40">
        <div className="absolute inset-0 bg-grid opacity-30 pointer-events-none" />
        <div className="relative px-4 lg:px-10 py-16 lg:py-24 max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            <div className="space-y-6 animate-in-up">
              <div className="flex items-center gap-3 flex-wrap">
                <img src="/instiquest-logo.png" alt="INSTIQUEST" height={56} width={84} className="object-contain float-y" />
                <Badge className="ai-badge text-white border-0 gap-1.5 px-3 py-1">
                  <Sparkles className="h-3.5 w-3.5" />
                  v{siteConfig.version}
                </Badge>
              </div>
              <p className="text-[12px] font-semibold uppercase tracking-[0.3em] text-cyan-glow/90">{siteConfig.tagline}</p>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.05]">
                Your quest for the <br />
                <span className="text-gradient-electric">right institute</span>
                <br /> starts here.
              </h1>
              <p className="text-base md:text-lg text-muted-foreground max-w-xl">
                INSTIQUEST aggregates <strong className="text-foreground">{exams.length}+ entrance exams</strong>,
                <strong className="text-foreground"> {institutions.length}+ institutions</strong>, hard-level
                mock tests, an AI admission assistant and an institute advertising gateway — with verified
                information clearly separated from AI-generated guidance.
              </p>

              {/* Hero search */}
              <form onSubmit={onSearch} className="relative max-w-xl">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Search exams, institutions or courses…"
                  className="pl-12 h-14 bg-card/70 border-border/60 backdrop-blur-md text-base focus-visible:border-electric focus-visible:ring-electric/30"
                  aria-label="Search INSTIQUEST"
                />
                <Button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 h-10 glow-button" size="sm">
                  Search
                </Button>
              </form>

              <div className="flex flex-wrap gap-2 pt-2">
                <Button onClick={() => navigate("exams")} className="glow-button gap-2">
                  Browse Exams <ArrowRight className="h-4 w-4" />
                </Button>
                <Button variant="outline" onClick={() => navigate("mock-tests")} className="gap-2 border-electric/40 text-electric hover:bg-electric/10">
                  <Brain className="h-4 w-4" /> Try a Mock Test
                </Button>
                <Button variant="ghost" onClick={() => navigate("chatbot")} className="gap-2 text-muted-foreground">
                  <Sparkles className="h-4 w-4" /> Ask AI Assistant
                </Button>
              </div>
            </div>

            {/* Hero visual: floating dashboard preview */}
            <div className="relative hidden lg:block animate-in-up stagger-2">
              <div className="relative float-y">
                <Card className="glass-card glass-card-hover border-electric/30 overflow-hidden">
                  <CardHeader className="pb-3 border-b border-border/40">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-sm font-semibold">Live Dashboard</CardTitle>
                        <CardDescription className="text-xs">INSTIQUEST pulse · real-time</CardDescription>
                      </div>
                      <span className="flex items-center gap-1 text-[10px] text-cyan-glow">
                        <span className="h-1.5 w-1.5 rounded-full bg-cyan-glow pulse-glow" /> live
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent className="p-4 space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <StatBlock label="Exams" value={`${exams.length}+`} icon={BookOpen} />
                      <StatBlock label="Institutes" value={`${institutions.length}+`} icon={Building2} accent="cyan" />
                    </div>
                    <div className="space-y-2">
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">Featured</p>
                      {featuredExams.slice(0, 3).map((ex) => (
                        <button
                          key={ex.id}
                          onClick={() => navigate("exams", ex.id)}
                          className="w-full flex items-center justify-between p-2 rounded-lg bg-muted/30 hover:bg-electric/10 transition-colors text-left"
                        >
                          <div>
                            <p className="text-sm font-medium">{ex.name}</p>
                            <p className="text-[11px] text-muted-foreground">{ex.category}</p>
                          </div>
                          <ArrowRight className="h-3 w-3 text-muted-foreground" />
                        </button>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                {/* Floating chips */}
                <div className="absolute -top-3 -right-3 px-3 py-1.5 rounded-full bg-cyan-glow/20 backdrop-blur-md border border-cyan-glow/40 text-[11px] text-cyan-glow font-medium">
                  <Trophy className="inline h-3 w-3 mr-1" /> Hard mocks
                </div>
                <div className="absolute -bottom-3 -left-3 px-3 py-1.5 rounded-full bg-purple-sub/20 backdrop-blur-md border border-purple-sub/40 text-[11px] text-purple-sub font-medium">
                  <Sparkles className="inline h-3 w-3 mr-1" /> AI assistant
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className="px-4 lg:px-10 py-12 max-w-7xl mx-auto">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((s) => (
            <StatBlock key={s.label} label={s.label} value={s.value} icon={s.icon} accent={s.accent} />
          ))}
        </div>
        {/* Live visit analytics — demo, client-side */}
        <Card className="glass-card glass-card-hover p-5 mt-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-semibold flex items-center gap-2"><TrendingUp className="h-4 w-4 text-accent" /> Live visit analytics</h3>
              <p className="text-[11px] text-muted-foreground">Demo: tracked in your browser. Wire a real analytics backend in production.</p>
            </div>
            <VisitCounterPill />
          </div>
          <VisitStats />
        </Card>
      </section>

      {/* FEATURED EXAMS */}
      <section className="px-4 lg:px-10 py-8 max-w-7xl mx-auto">
        <SectionHeading
          eyebrow="Hand-picked"
          title="Featured Entrance Exams"
          description="The flagship exams most students start their quest with. Tap any card for full details."
          action={
            <Button variant="outline" size="sm" onClick={() => navigate("exams")} className="gap-2">
              View all <ArrowRight className="h-3 w-3" />
            </Button>
          }
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {featuredExams.slice(0, 4).map((ex, i) => (
            <button
              key={ex.id}
              onClick={() => navigate("exams", ex.id)}
              className="text-left animate-in-up"
              style={{ animationDelay: `${0.08 * i}s` }}
            >
              <Card className="glass-card glass-card-hover h-full transition-all hover:-translate-y-1 cursor-pointer">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <Badge variant="outline" className="text-[10px] border-electric/40 text-electric">{ex.category}</Badge>
                    <Star className="h-3.5 w-3.5 text-amber-400 fill-amber-400" />
                  </div>
                  <CardTitle className="text-base mt-2">{ex.name}</CardTitle>
                  <CardDescription className="text-xs line-clamp-2">{ex.fullName}</CardDescription>
                </CardHeader>
                <CardContent className="pt-0 text-xs text-muted-foreground space-y-1">
                  <p><span className="text-muted-foreground/70">Authority:</span> {ex.conductingAuthority}</p>
                  <p><span className="text-muted-foreground/70">Course:</span> {ex.course}</p>
                  {ex.verified ? <VerifiedBadge /> : <UnverifiedBadge />}
                </CardContent>
              </Card>
            </button>
          ))}
        </div>
      </section>

      {/* FEATURED INSTITUTIONS */}
      <section className="px-4 lg:px-10 py-8 max-w-7xl mx-auto">
        <SectionHeading
          eyebrow="Where aspirants land"
          title="Featured Institutions"
          description="A snapshot of India's most sought-after engineering, management and central universities."
          action={
            <Button variant="outline" size="sm" onClick={() => navigate("institutions")} className="gap-2">
              Browse directory <ArrowRight className="h-3 w-3" />
            </Button>
          }
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {featuredInstitutions.slice(0, 6).map((it, i) => (
            <button
              key={it.id}
              onClick={() => navigate("institutions", it.id)}
              className="text-left animate-in-up"
              style={{ animationDelay: `${0.08 * i}s` }}
            >
              <Card className="glass-card glass-card-hover h-full transition-all hover:-translate-y-1 cursor-pointer">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className="text-[10px] border-purple-sub/40 text-purple-sub">{it.type}</Badge>
                    <span className="text-[10px] text-muted-foreground">est. {it.established}</span>
                  </div>
                  <CardTitle className="text-base mt-2">{it.name}</CardTitle>
                  <CardDescription className="text-xs">{it.location}</CardDescription>
                </CardHeader>
                <CardContent className="pt-0 text-xs text-muted-foreground">
                  <p className="line-clamp-1">Programmes: {it.programmes.slice(0, 4).join(", ")}{it.programmes.length > 4 ? "…" : ""}</p>
                  <p className="mt-1"><span className="text-muted-foreground/70">Admission:</span> {it.admissionRoute}</p>
                </CardContent>
              </Card>
            </button>
          ))}
        </div>
      </section>

      {/* ANNOUNCEMENTS */}
      <section className="px-4 lg:px-10 py-8 max-w-7xl mx-auto">
        <SectionHeading
          eyebrow="Stay current"
          title="Announcements & Updates"
          description="Pinned updates from INSTIQUEST plus pointers to official exam portals."
        />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {pinned.concat(announcements.filter((a) => !a.pinned).slice(0, 5)).slice(0, 6).map((a) => (
            <Card key={a.id} className="glass-card glass-card-hover">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-2">
                  <Badge variant="outline" className="text-[10px] border-electric/40 text-electric">{a.category}</Badge>
                  {a.verified ? <VerifiedBadge label="Verified" /> : <UnverifiedBadge />}
                </div>
                <CardTitle className="text-sm mt-2">{a.title}</CardTitle>
              </CardHeader>
              <CardContent className="pt-0 text-xs text-muted-foreground">
                <p className="line-clamp-3">{a.summary}</p>
                {a.source && (
                  <a href={a.source} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 text-electric hover:underline">
                    <ExternalLink className="h-3 w-3" /> Official source
                  </a>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CATEGORY QUICK LINKS */}
      <section className="px-4 lg:px-10 py-8 max-w-7xl mx-auto">
        <SectionHeading
          eyebrow="Browse by category"
          title="Find your stream"
          description="Jump straight into the exam category you are preparing for."
        />
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {examCategories.map((c, i) => {
            const count = exams.filter((e) => e.category === c).length;
            return (
              <button
                key={c}
                onClick={() => navigate("exams", undefined, { category: c })}
                className="text-left animate-in-up"
                style={{ animationDelay: `${0.04 * i}s` }}
              >
                <Card className="glass-card glass-card-hover p-3 transition-all hover:-translate-y-1 cursor-pointer h-full">
                  <p className="text-sm font-semibold">{c}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">{count} exams</p>
                </Card>
              </button>
            );
          })}
        </div>
      </section>

      {/* FEATURE JUMBO STRIP */}
      <section className="px-4 lg:px-10 py-12 max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-4">
          <Card className="glass-card glass-card-hover p-6 lg:p-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 h-32 w-32 rounded-full bg-electric/20 blur-3xl" />
            <Badge className="ai-badge border-0 text-[10px] mb-3 gap-1"><Sparkles className="h-3 w-3" /> AI Assistant</Badge>
            <h3 className="text-2xl font-bold mb-2 text-gradient-static">Ask the AI admission assistant</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Get instant guidance on exam routes, counselling, eligibility and timelines. AI responses are clearly
              labelled and distinct from verified directory information. API keys never touch the frontend.
            </p>
            <Button onClick={() => navigate("chatbot")} className="glow-button gap-2">
              Open Assistant <ArrowRight className="h-4 w-4" />
            </Button>
          </Card>

          <Card className="glass-card glass-card-hover p-6 lg:p-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 h-32 w-32 rounded-full bg-purple-sub/20 blur-3xl" />
            <Badge className="ai-badge border-0 text-[10px] mb-3 gap-1"><Brain className="h-3 w-3" /> Mock Tests</Badge>
            <h3 className="text-2xl font-bold mb-2 text-gradient-static">Hard-level mock tests</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Original INSTIQUEST-authored questions in Engineering, Medical, Management and Law streams.
              Timed sections, negative marking, full explanations and performance analytics.
            </p>
            <Button variant="outline" onClick={() => navigate("mock-tests")} className="gap-2 border-electric/40 text-electric hover:bg-electric/10">
              Start practising <ArrowRight className="h-4 w-4" />
            </Button>
          </Card>
        </div>
      </section>

      {/* DEMO + VERIFIED INFO NOTICE */}
      <section className="px-4 lg:px-10 py-8 max-w-7xl mx-auto">
        <Card className="bg-muted/10 border-dashed border-border/60 p-4 text-xs text-muted-foreground">
          <div className="flex flex-wrap items-start gap-x-6 gap-y-2">
            <span className="flex items-center gap-1.5"><DemoBadge /> Demo features are clearly labelled in the UI.</span>
            <span className="flex items-center gap-1.5"><UnverifiedBadge /> Unverified items are pending editorial review and must be cross-checked on official portals.</span>
            <span className="flex items-center gap-1.5"><AIBadgeHelper /> AI guidance is distinct from verified directory data.</span>
          </div>
        </Card>
      </section>
    </div>
  );
}

function AIBadgeHelper() {
  return <Badge className="ai-badge text-white border-0 text-[10px] gap-1 px-2 py-0.5"><Sparkles className="h-3 w-3" /> AI Guidance</Badge>;
}
