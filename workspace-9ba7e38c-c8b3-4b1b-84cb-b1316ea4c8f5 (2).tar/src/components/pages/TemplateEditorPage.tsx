"use client";

import { useState } from "react";
import { useRouter } from "@/lib/router";
import { useAuth, useIsOwner } from "@/lib/stores";
import { siteConfig } from "@/data/site-config";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { SectionHeading, DemoBadge, VerifiedBadge, UnverifiedBadge } from "@/components/common/ui-bits";
import {
  ShieldAlert, Lock, Key, FileEdit, Eye, Save, AlertCircle, CheckCircle2,
  Sparkles, Code2, Palette,
} from "lucide-react";
import { toast } from "sonner";

export function TemplateEditorPage() {
  const { navigate } = useRouter();
  const isOwner = useIsOwner();
  const loginOwner = useAuth((s) => s.loginOwner);
  const user = useAuth((s) => s.user);

  const [keyInput, setKeyInput] = useState("");
  const [loginError, setLoginError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // ---- Owner-only template edit form state ----
  const [brandName, setBrandName] = useState(siteConfig.brand);
  const [tagline, setTagline] = useState(siteConfig.tagline);
  const [ownerName, setOwnerName] = useState(siteConfig.owner.name);
  const [businessEmail, setBusinessEmail] = useState(siteConfig.contact.businessEmail);
  const [cssAccent, setCssAccent] = useState("oklch(0.80 0.16 75)");
  const [cssPrimary, setCssPrimary] = useState("oklch(0.62 0.20 257)");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    setSubmitting(true);
    setTimeout(() => {
      const res = loginOwner(keyInput);
      setSubmitting(false);
      if (!res.ok) {
        setLoginError(res.error ?? "Login failed");
        toast.error("Owner login failed", { description: res.error });
      } else {
        toast.success("Owner signed in", { description: "You can now edit the site template." });
      }
    }, 400);
  };

  // ====== OWNER GATE ======
  if (!isOwner) {
    return (
      <div className="px-4 lg:px-10 py-12 max-w-3xl mx-auto animate-in-fade">
        <SectionHeading
          eyebrow="Owner-only"
          title="Template Editor"
          description="Only the site owner can edit the website's template. Sign in with your owner key below. Admins can manage content but cannot edit the template."
        />

        <Card className="glass-card p-8 mt-4">
          <div className="flex flex-col items-center text-center mb-6">
            <div className="mx-auto mb-4 w-16 h-16 rounded-full bg-primary/15 flex items-center justify-center pulse-glow">
              <Lock className="h-8 w-8 text-primary" />
            </div>
            <h2 className="text-xl font-semibold mb-1">Owner login</h2>
            <p className="text-xs text-muted-foreground max-w-sm">
              Enter your owner key to access the template editor. The owner key is configured in{" "}
              <code className="text-primary">src/data/site-config.ts</code>.
            </p>
            <div className="mt-2 flex items-center gap-2">
              <DemoBadge label="Demo auth" />
              <Badge variant="outline" className="text-[10px] border-amber-500/40 text-amber-300 bg-amber-500/10">
                Replace with NextAuth before production
              </Badge>
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="ownerKey">Owner key</Label>
              <div className="relative mt-1">
                <Key className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="ownerKey"
                  type="password"
                  value={keyInput}
                  onChange={(e) => setKeyInput(e.target.value)}
                  className="pl-9 bg-muted/30 font-mono"
                  placeholder="Enter owner key"
                  autoComplete="off"
                />
              </div>
              {loginError && (
                <p className="text-xs text-destructive mt-1.5 flex items-center gap-1">
                  <AlertCircle className="h-3 w-3" /> {loginError}
                </p>
              )}
            </div>

            {/* Demo hint */}
            <Alert className="bg-muted/20 border-border/40">
              <Sparkles className="h-4 w-4 text-accent" />
              <AlertTitle className="text-sm">Demo key</AlertTitle>
              <AlertDescription className="text-xs">
                For the demo build, the placeholder owner key is{" "}
                <code className="text-primary font-mono bg-muted/40 px-1 rounded">{siteConfig.owner.ownerKeyPlaceholder}</code>.
                Replace it in <code className="text-primary">src/data/site-config.ts</code> before launch.
              </AlertDescription>
            </Alert>

            <Button type="submit" disabled={submitting || !keyInput.trim()} className="w-full glow-button gap-2">
              {submitting ? (
                <><span className="h-3 w-3 border-2 border-primary-foreground border-t-transparent animate-spin rounded-full" /> Verifying…</>
              ) : (
                <><Lock className="h-4 w-4" /> Unlock template editor</>
              )}
            </Button>
          </form>
        </Card>

        <Card className="glass-card p-5 mt-4">
          <div className="flex items-start gap-3">
            <ShieldAlert className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs text-muted-foreground">
              <p className="font-semibold text-foreground mb-1">Why is this gated?</p>
              <p>
                The template editor controls the site-wide brand identity — logo, colors, tagline, owner name,
                contact email and CSS tokens. Admins can manage exams, institutions, ads and chatbot content,
                but only the owner can change the template. This separation prevents accidental or malicious
                rebranding of the site.
              </p>
              <p className="mt-2">
                Currently signed in as:{" "}
                <Badge variant="outline" className="text-[10px] capitalize">{user?.role ?? "guest"}</Badge>
              </p>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  // ====== TEMPLATE EDITOR (owner-only) ======
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Template saved (demo)", {
      description: "In production, this would persist to src/data/site-config.ts and rebuild the site.",
    });
  };

  return (
    <div className="px-4 lg:px-10 py-10 max-w-5xl mx-auto animate-in-fade">
      <SectionHeading
        eyebrow="Owner console"
        title="Template Editor"
        description="Edit the site-wide template. Changes here affect branding, colors and contact details across every page."
        action={
          <div className="flex items-center gap-2">
            <VerifiedBadge label={`Owner: ${user?.name ?? ""}`} />
            <DemoBadge />
          </div>
        }
      />

      <Alert className="bg-amber-500/5 border-amber-500/30 mb-6">
        <AlertCircle className="h-4 w-4 text-amber-400" />
        <AlertTitle className="text-sm">Demo build notice</AlertTitle>
        <AlertDescription className="text-xs">
          This editor demonstrates the template-editing UI. In the demo build, changes are NOT persisted —
          they reset on page reload. To persist changes, wire this form to a server-side endpoint that writes
          to <code className="text-primary">src/data/site-config.ts</code> (or a database) and triggers a rebuild.
        </AlertDescription>
      </Alert>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Branding */}
        <Card className="glass-card p-5">
          <CardHeader className="px-0 pt-0">
            <CardTitle className="flex items-center gap-2 text-base"><Palette className="h-4 w-4 text-primary" /> Branding</CardTitle>
            <CardDescription className="text-xs">Site-wide brand identity. Updates <code className="text-primary">siteConfig.brand</code> and <code className="text-primary">tagline</code>.</CardDescription>
          </CardHeader>
          <CardContent className="px-0 space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="brand">Brand name</Label>
                <Input id="brand" value={brandName} onChange={(e) => setBrandName(e.target.value)} className="mt-1 bg-muted/30" />
              </div>
              <div>
                <Label htmlFor="tagline">Tagline</Label>
                <Input id="tagline" value={tagline} onChange={(e) => setTagline(e.target.value)} className="mt-1 bg-muted/30" />
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="owner">Owner name</Label>
                <Input id="owner" value={ownerName} onChange={(e) => setOwnerName(e.target.value)} className="mt-1 bg-muted/30" />
                <p className="text-[11px] text-muted-foreground mt-1">Displayed in the footer. Placeholder until approved.</p>
              </div>
              <div>
                <Label htmlFor="email">Business email</Label>
                <Input id="email" type="email" value={businessEmail} onChange={(e) => setBusinessEmail(e.target.value)} className="mt-1 bg-muted/30" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Theme tokens */}
        <Card className="glass-card p-5">
          <CardHeader className="px-0 pt-0">
            <CardTitle className="flex items-center gap-2 text-base"><Code2 className="h-4 w-4 text-accent" /> Theme tokens (CSS)</CardTitle>
            <CardDescription className="text-xs">OKLCH color values for the primary and accent tokens used across the site.</CardDescription>
          </CardHeader>
          <CardContent className="px-0 space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="primary">--primary (royal blue)</Label>
                <div className="flex items-center gap-2 mt-1">
                  <Input id="primary" value={cssPrimary} onChange={(e) => setCssPrimary(e.target.value)} className="bg-muted/30 font-mono text-xs" />
                  <div className="h-9 w-12 rounded border border-border/40" style={{ background: cssPrimary }} />
                </div>
              </div>
              <div>
                <Label htmlFor="accent">--accent (gold)</Label>
                <div className="flex items-center gap-2 mt-1">
                  <Input id="accent" value={cssAccent} onChange={(e) => setCssAccent(e.target.value)} className="bg-muted/30 font-mono text-xs" />
                  <div className="h-9 w-12 rounded border border-border/40" style={{ background: cssAccent }} />
                </div>
              </div>
            </div>
            <p className="text-[11px] text-muted-foreground">
              Other tokens (background, sidebar, chart palette) derive from these. Edit <code className="text-primary">src/app/globals.css</code> for full control.
            </p>
          </CardContent>
        </Card>

        {/* Live preview */}
        <Card className="glass-card p-5">
          <CardHeader className="px-0 pt-0">
            <CardTitle className="flex items-center gap-2 text-base"><Eye className="h-4 w-4 text-primary" /> Live preview</CardTitle>
            <CardDescription className="text-xs">Snapshot of how the brand renders with current values.</CardDescription>
          </CardHeader>
          <CardContent className="px-0">
            <div className="rounded-lg border border-border/40 p-4 bg-background">
              <div className="flex items-center gap-3 mb-2">
                <img src="/instiquest-logo-square.png" alt="logo" height={40} width={40} className="rounded-md object-contain" />
                <div>
                  <p className="font-bold text-gradient-static">{brandName}</p>
                  <p className="text-[10px] text-accent font-semibold uppercase tracking-[0.2em]">{tagline}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 mt-3">
                <Button size="sm" style={{ background: cssPrimary, color: "white" }}>Primary button</Button>
                <Button size="sm" variant="outline" style={{ borderColor: cssAccent, color: cssAccent }}>Accent button</Button>
              </div>
              <p className="text-xs text-muted-foreground mt-3">Owner: {ownerName} · Contact: {businessEmail}</p>
            </div>
          </CardContent>
        </Card>

        {/* Save */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Button variant="ghost" onClick={() => navigate("admin")} className="text-muted-foreground">Back to admin</Button>
          <div className="flex gap-2">
            <Button variant="outline" type="button" onClick={() => {
              setBrandName(siteConfig.brand);
              setTagline(siteConfig.tagline);
              setOwnerName(siteConfig.owner.name);
              setBusinessEmail(siteConfig.contact.businessEmail);
              setCssPrimary("oklch(0.62 0.20 257)");
              setCssAccent("oklch(0.80 0.16 75)");
              toast.info("Reset to defaults");
            }}>Reset</Button>
            <Button type="submit" className="glow-button gap-2">
              <Save className="h-4 w-4" /> Save template
            </Button>
          </div>
        </div>
      </form>

      {/* Permissions explainer */}
      <Card className="glass-card p-5 mt-8">
        <div className="flex items-start gap-3">
          <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
          <div className="text-xs text-muted-foreground">
            <p className="font-semibold text-foreground mb-1">Permission model</p>
            <ul className="space-y-1 list-disc pl-4">
              <li><strong className="text-foreground">Owner</strong> (you): Can edit template, branding, colors, contact details, AND everything admins can do.</li>
              <li><strong className="text-foreground">Admin</strong>: Can manage exams, institutions, mock questions, ads, chatbot KB and application dates — but NOT the template.</li>
              <li><strong className="text-foreground">Institute</strong>: Can submit advertising requests only.</li>
              <li><strong className="text-foreground">Student</strong>: Can browse, take mock tests, save exams, track applications.</li>
            </ul>
            <p className="mt-2 text-amber-300/90">
              Note: in this demo build the permission check is client-side. Wire a real NextAuth session check
              on the server (especially for any write API) before going live.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
