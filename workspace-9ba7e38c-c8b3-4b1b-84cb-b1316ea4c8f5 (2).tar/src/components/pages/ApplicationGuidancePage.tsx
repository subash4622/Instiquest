"use client";

import { useState } from "react";
import { useRouter, type Route } from "@/lib/router";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  SectionHeading, UnverifiedBadge, AIBadge,
} from "@/components/common/ui-bits";
import {
  ListChecks, FileText, IndianRupee, ExternalLink, ArrowRight, BookOpen,
  Building2, Trophy, ClipboardCheck, ShieldAlert, Compass, Calendar,
  Upload, CreditCard, Ticket, Lightbulb, GraduationCap, AlertTriangle,
} from "lucide-react";

interface GuidanceStep {
  num: number;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  tip: string;
  cta: { label: string; route: Route };
}

const STEPS: GuidanceStep[] = [
  {
    num: 1,
    icon: Compass,
    title: "Choose your exam & course",
    description:
      "Browse the INSTIQUEST exam directory by category — Engineering, Medical, Management, Law, Design, Architecture and more. Read the official eligibility, conducting authority and course description for each exam before deciding.",
    tip: "Save 2-3 candidate exams to your student dashboard so you can compare them side-by-side.",
    cta: { label: "Browse exam directory", route: "exams" },
  },
  {
    num: 2,
    icon: Calendar,
    title: "Check eligibility & important dates",
    description:
      "Cross-check age limit, educational qualification, category and nationality requirements on the official conducting-authority portal. The notification PDF always carries the authoritative timeline.",
    tip: "INSTIQUEST does not publish application-window dates unless broadly verified. Always confirm on the official portal.",
    cta: { label: "Read announcements", route: "home" },
  },
  {
    num: 3,
    icon: BookOpen,
    title: "Register on the official portal",
    description:
      "Create an account on the official exam portal with a personal email ID and mobile number. Use an email you check regularly — most portals send the application confirmation and admit card link by email.",
    tip: "Keep a single notebook or spreadsheet of your registration IDs and passwords for every exam.",
    cta: { label: "Explore institutions", route: "institutions" },
  },
  {
    num: 4,
    icon: Upload,
    title: "Fill application & upload documents",
    description:
      "Complete the application form section by section. Upload scanned documents in the exact format and dimensions specified — most rejections happen because of a wrong file size or DPI.",
    tip: "Use the document checklist on this page to gather all scans before you start filling the form.",
    cta: { label: "Open checklist below", route: "guidance" },
  },
  {
    num: 5,
    icon: CreditCard,
    title: "Pay application fee",
    description:
      "Pay the application fee through the official payment gateway on the exam portal. Fees vary by exam and category — never trust third-party fee numbers; always confirm on the official portal before paying.",
    tip: "Save the fee payment receipt and transaction reference number — you may need it during counselling.",
    cta: { label: "See fee note below", route: "guidance" },
  },
  {
    num: 6,
    icon: Ticket,
    title: "Download admit card & appear for exam",
    description:
      "The admit card is usually released 1-2 weeks before the exam. Verify your name, photo, exam centre and reporting time. On exam day, carry the admit card and a valid photo ID.",
    tip: "Take INSTIQUEST mock tests in the same pattern as the real exam to build exam-day stamina.",
    cta: { label: "Take mock tests", route: "mock-tests" },
  },
];

const ELIGIBILITY_ITEMS = [
  "I meet the educational qualification (e.g., Class 12 pass for UG, Bachelor's degree for PG).",
  "I meet the age criteria as specified in the official notification (upper / lower age limit).",
  "I meet the nationality / citizenship requirement (Indian citizen / OCI / NRI as applicable).",
  "I belong to an eligible category (General / OBC / SC / ST / EWS / PwD) and have a valid certificate.",
  "I have studied the mandatory subjects required for the exam (e.g., PCM for JEE, PCB for NEET).",
  "I meet the minimum marks requirement in qualifying subjects (if any) as per the official notification.",
  "I have a valid photo ID proof (Aadhaar / PAN / Passport / Voter ID).",
  "I have a working personal email ID and mobile number for registration.",
  "I have checked the number of allowed attempts (where applicable).",
  "I have read the official information bulletin end-to-end.",
];

const DOCUMENT_ITEMS = [
  { label: "Class 10 marksheet / passing certificate", note: "Proof of date of birth" },
  { label: "Class 12 marksheet / passing certificate", note: "For UG admission" },
  { label: "Graduation marksheet / degree certificate", note: "For PG admission" },
  { label: "Category certificate (SC / ST / OBC-NCL / EWS)", note: "Issued by competent authority" },
  { label: "PwD certificate (if applicable)", note: "Issued by a notified medical board" },
  { label: "Recent passport-size photograph", note: "Usually 10-200 KB, JPG/JPEG format" },
  { label: "Scanned signature", note: "Usually 10-50 KB, JPG/JPEG format" },
  { label: "Valid photo ID proof (Aadhaar / PAN / Passport)", note: "For identity verification at exam centre" },
  { label: "Category / income certificate (for fee relaxation, if applicable)", note: "Issued by Tahsildar / competent authority" },
  { label: "Application fee payment receipt", note: "Transaction reference number" },
];

export function ApplicationGuidancePage() {
  const { navigate } = useRouter();
  const [eligibility, setEligibility] = useState<boolean[]>(
    () => Array(ELIGIBILITY_ITEMS.length).fill(false)
  );
  const [documents, setDocuments] = useState<boolean[]>(
    () => Array(DOCUMENT_ITEMS.length).fill(false)
  );

  const toggleElig = (i: number) =>
    setEligibility((p) => p.map((v, idx) => (idx === i ? !v : v)));
  const toggleDoc = (i: number) =>
    setDocuments((p) => p.map((v, idx) => (idx === i ? !v : v)));

  const eligDone = eligibility.filter(Boolean).length;
  const docDone = documents.filter(Boolean).length;

  return (
    <div className="px-4 lg:px-10 py-8 max-w-6xl mx-auto animate-in-fade">
      {/* Hero */}
      <Card className="glass-card p-0 overflow-hidden mb-8 relative">
        <div className="absolute inset-0 bg-aurora opacity-60 pointer-events-none" />
        <div className="absolute inset-0 bg-grid opacity-30 pointer-events-none" />
        <div className="relative p-8 md:p-10">
          <div className="flex items-center gap-2 mb-3">
            <Badge className="bg-electric/15 text-electric border border-electric/40 text-[10px] gap-1">
              <Compass className="h-3 w-3" /> Step-by-step
            </Badge>
            <AIBadge label="AI-augmented guidance" />
          </div>
          <h1 className="text-3xl md:text-5xl font-bold text-gradient-electric leading-tight mb-3">
            Step-by-step application guidance
          </h1>
          <p className="text-sm md:text-base text-muted-foreground max-w-2xl">
            A generic, exam-agnostic walkthrough of the entrance-exam application lifecycle.
            Use this as a checklist framework — then verify every date, fee and document
            requirement on the official conducting-authority portal.
          </p>
          <div className="mt-5 flex items-center gap-3 flex-wrap">
            <Button onClick={() => navigate("exams")} className="glow-button gap-2">
              <BookOpen className="h-4 w-4" /> Browse exams
            </Button>
            <Button onClick={() => navigate("institutions")} variant="outline" className="gap-2">
              <Building2 className="h-4 w-4" /> Browse institutions
            </Button>
            <Button onClick={() => navigate("mock-tests")} variant="outline" className="gap-2">
              <Trophy className="h-4 w-4" /> Take mock tests
            </Button>
          </div>
        </div>
      </Card>

      {/* Vertical stepper */}
      <SectionHeading
        eyebrow="The lifecycle"
        title="Six-step application walkthrough"
        description="A generic, end-to-end view of the entrance-exam application process. Each step has a practical tip and a deep-link to a relevant INSTIQUEST resource."
      />

      <div className="relative pl-8 md:pl-10 mb-12">
        {/* Vertical line */}
        <div className="absolute left-[14px] md:left-[18px] top-2 bottom-2 w-px bg-gradient-to-b from-electric via-cyan-glow to-purple-sub opacity-50" />
        <ol className="space-y-6">
          {STEPS.map((s, idx) => {
            const Icon = s.icon;
            return (
              <li key={s.num} className={`relative animate-in-up stagger-${Math.min(idx + 1, 6)}`}>
                {/* Node */}
                <div className="absolute -left-8 md:-left-10 top-0">
                  <div className="w-7 h-7 md:w-9 md:h-9 rounded-full bg-navy-mid border-2 border-electric flex items-center justify-center shadow-[0_0_15px_-3px_oklch(0.72_0.18_230_/_0.7)]">
                    <Icon className="h-3.5 w-3.5 md:h-4 md:w-4 text-electric" />
                  </div>
                </div>
                <Card className="glass-card glass-card-hover">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-[10px] border-electric/40 text-electric">Step {s.num}</Badge>
                      <CardTitle className="text-base md:text-lg">{s.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground leading-relaxed">{s.description}</p>
                    {/* Tip callout */}
                    <div className="mt-4 p-3 rounded-lg bg-cyan-glow/10 border border-cyan-glow/30 flex items-start gap-2">
                      <Lightbulb className="h-4 w-4 text-cyan-glow shrink-0 mt-0.5" />
                      <p className="text-xs text-cyan-glow/90 leading-relaxed">
                        <span className="font-semibold">Tip:</span> {s.tip}
                      </p>
                    </div>
                    <div className="mt-4">
                      <Button size="sm" variant="outline" onClick={() => navigate(s.cta.route)} className="gap-1">
                        {s.cta.label} <ArrowRight className="h-3 w-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </li>
            );
          })}
        </ol>
      </div>

      {/* Eligibility + Document checklists */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
        <Card className="glass-card animate-in-up">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <ClipboardCheck className="h-4 w-4 text-electric" /> Eligibility checklist
            </CardTitle>
            <CardDescription>Generic items — verify each one against the official notification of your chosen exam.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4 flex items-center justify-between">
              <span className="text-xs text-muted-foreground">
                {eligDone} / {ELIGIBILITY_ITEMS.length} confirmed
              </span>
              <Badge variant="outline" className={`text-[10px] ${eligDone === ELIGIBILITY_ITEMS.length ? "border-emerald-500/40 text-emerald-300" : "border-border/60 text-muted-foreground"}`}>
                {eligDone === ELIGIBILITY_ITEMS.length ? "All confirmed" : "In progress"}
              </Badge>
            </div>
            <ul className="space-y-2.5">
              {ELIGIBILITY_ITEMS.map((it, i) => (
                <li key={i}>
                  <label className="flex items-start gap-3 p-2 rounded-md hover:bg-muted/30 cursor-pointer transition-colors">
                    <Checkbox checked={eligibility[i]} onCheckedChange={() => toggleElig(i)} className="mt-0.5" />
                    <span className={`text-sm ${eligibility[i] ? "text-muted-foreground line-through" : ""}`}>{it}</span>
                  </label>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card className="glass-card animate-in-up stagger-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <FileText className="h-4 w-4 text-cyan-glow" /> Document checklist
            </CardTitle>
            <CardDescription>Keep these scanned and ready before you start filling any application form.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4 flex items-center justify-between">
              <span className="text-xs text-muted-foreground">
                {docDone} / {DOCUMENT_ITEMS.length} ready
              </span>
              <Badge variant="outline" className={`text-[10px] ${docDone === DOCUMENT_ITEMS.length ? "border-emerald-500/40 text-emerald-300" : "border-border/60 text-muted-foreground"}`}>
                {docDone === DOCUMENT_ITEMS.length ? "All ready" : "In progress"}
              </Badge>
            </div>
            <ul className="space-y-2.5">
              {DOCUMENT_ITEMS.map((d, i) => (
                <li key={i}>
                  <label className="flex items-start gap-3 p-2 rounded-md hover:bg-muted/30 cursor-pointer transition-colors">
                    <Checkbox checked={documents[i]} onCheckedChange={() => toggleDoc(i)} className="mt-0.5" />
                    <div className="min-w-0">
                      <p className={`text-sm ${documents[i] ? "text-muted-foreground line-through" : ""}`}>{d.label}</p>
                      <p className="text-[10px] text-muted-foreground/70">{d.note}</p>
                    </div>
                  </label>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Fee structure note */}
      <Card className="glass-card mb-12 animate-in-up">
        <CardHeader>
          <div className="flex items-center gap-2 flex-wrap">
            <IndianRupee className="h-4 w-4 text-purple-sub" />
            <CardTitle className="text-lg">Fee structure note</CardTitle>
            <UnverifiedBadge label="Fees unverified — check official portal" />
          </div>
          <CardDescription>Why we don&apos;t publish fee numbers here.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/40 flex items-start gap-3 mb-4">
            <ShieldAlert className="h-5 w-5 text-amber-300 shrink-0 mt-0.5" />
            <div className="text-sm text-amber-200/90 leading-relaxed">
              <p className="font-semibold mb-1">Application fees vary by exam, category and gender.</p>
              <p>
                INSTIQUEST does not record fee amounts unless they are explicitly verified by the
                editorial team. Fee structures change every cycle, and category-based relaxations
                (General / OBC-NCL / SC / ST / PwD / Female candidates) differ across conducting
                authorities. Always confirm the exact fee on the official conducting-authority
                portal before initiating payment.
              </p>
            </div>
          </div>
          <ul className="text-xs text-muted-foreground space-y-1.5 list-disc list-inside">
            <li>Fees for the same exam often differ for General, OBC-NCL, SC, ST, EWS, PwD and Female candidates.</li>
            <li>Some exams charge a separate fee per paper (e.g., JEE Main Paper 1 vs Paper 2).</li>
            <li>Late-fee windows may apply if you submit after the regular deadline.</li>
            <li>Refund policies vary — most fees are non-refundable once submitted.</li>
            <li>Pay only through the official payment gateway linked from the conducting authority&apos;s website.</li>
          </ul>
        </CardContent>
      </Card>

      {/* Official portals CTA */}
      <SectionHeading
        eyebrow="Verify on official portals"
        title="Don&apos;t trust third-party dates"
        description="INSTIQUEST is a discovery layer — for the actual application, you must visit the official conducting-authority portal."
      />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="glass-card glass-card-hover animate-in-up">
          <CardContent className="pt-6">
            <div className="w-11 h-11 rounded-lg bg-electric/15 flex items-center justify-center mb-3">
              <BookOpen className="h-5 w-5 text-electric" />
            </div>
            <h3 className="text-sm font-semibold mb-1">Exam directory</h3>
            <p className="text-xs text-muted-foreground mb-4">
              Each exam card carries the official website link and verified eligibility details.
            </p>
            <Button onClick={() => navigate("exams")} variant="outline" size="sm" className="gap-1 w-full">
              Open exams <ExternalLink className="h-3 w-3" />
            </Button>
          </CardContent>
        </Card>
        <Card className="glass-card glass-card-hover animate-in-up stagger-1">
          <CardContent className="pt-6">
            <div className="w-11 h-11 rounded-lg bg-cyan-glow/15 flex items-center justify-center mb-3">
              <Building2 className="h-5 w-5 text-cyan-glow" />
            </div>
            <h3 className="text-sm font-semibold mb-1">Institution directory</h3>
            <p className="text-xs text-muted-foreground mb-4">
              Real official websites for IITs, NITs, IIMs, central, state and private universities.
            </p>
            <Button onClick={() => navigate("institutions")} variant="outline" size="sm" className="gap-1 w-full">
              Open institutions <ExternalLink className="h-3 w-3" />
            </Button>
          </CardContent>
        </Card>
        <Card className="glass-card glass-card-hover animate-in-up stagger-2">
          <CardContent className="pt-6">
            <div className="w-11 h-11 rounded-lg bg-purple-sub/15 flex items-center justify-center mb-3">
              <GraduationCap className="h-5 w-5 text-purple-sub" />
            </div>
            <h3 className="text-sm font-semibold mb-1">AI admission assistant</h3>
            <p className="text-xs text-muted-foreground mb-4">
              Ask the AI assistant for guidance — clearly labelled AI-generated, separate from verified info.
            </p>
            <Button onClick={() => navigate("chatbot")} variant="outline" size="sm" className="gap-1 w-full">
              Open assistant <ExternalLink className="h-3 w-3" />
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Disclaimer footer */}
      <div className="mt-10 p-4 rounded-lg bg-muted/20 border border-border/40 flex items-start gap-3">
        <AlertTriangle className="h-4 w-4 text-amber-300 shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground leading-relaxed">
          <span className="font-semibold text-amber-200">Disclaimer:</span>{" "}
          This guidance page is a generic framework for the entrance-exam application lifecycle
          and does not capture exam-specific eligibility, dates, fees or documents. Always refer
          to the official information bulletin published by the conducting authority for the
          authoritative version of every requirement.
        </p>
      </div>
    </div>
  );
}
