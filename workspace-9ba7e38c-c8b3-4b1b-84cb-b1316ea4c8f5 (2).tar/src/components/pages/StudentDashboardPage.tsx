"use client";

import { useState, useMemo } from "react";
import { useRouter, type Route } from "@/lib/router";
import { useAuth, useStudentData, type ApplicationTrack, type Bookmark } from "@/lib/stores";
import { getExamById, exams } from "@/data/exams";
import { getInstitutionById } from "@/data/institutions";
import { getMockTestById } from "@/data/mock-tests";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid,
} from "recharts";
import {
  SectionHeading, StatBlock, EmptyState, VerifiedBadge, UnverifiedBadge, DemoBadge,
} from "@/components/common/ui-bits";
import {
  Bookmark as BookmarkIcon, BookmarkCheck, Calendar, Clock, Trophy, Target,
  Trash2, ArrowRight, ExternalLink, GraduationCap, BookOpen, FileText, Layers,
  ClipboardList, Sparkles, TrendingUp, Award, LogIn, ShieldCheck, Building2,
  ListChecks, FileEdit,
} from "lucide-react";

const APP_STATUSES: ApplicationTrack["status"][] = [
  "PLANNED", "APPLIED", "ADMIT_CARD", "APPEARED", "RESULT", "COUNSELLING", "ADMITTED", "REJECTED",
];

const STATUS_COLOR: Record<ApplicationTrack["status"], string> = {
  PLANNED: "bg-muted/40 text-muted-foreground border-border/60",
  APPLIED: "bg-electric/15 text-electric border-electric/40",
  ADMIT_CARD: "bg-cyan-glow/15 text-cyan-glow border-cyan-glow/40",
  APPEARED: "bg-purple-sub/15 text-purple-sub border-purple-sub/40",
  RESULT: "bg-amber-500/15 text-amber-300 border-amber-500/40",
  COUNSELLING: "bg-blue-500/15 text-blue-300 border-blue-500/40",
  ADMITTED: "bg-emerald-500/15 text-emerald-300 border-emerald-500/40",
  REJECTED: "bg-destructive/15 text-destructive border-destructive/40",
};

function fmtDate(ts: number): string {
  try {
    return new Date(ts).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
  } catch {
    return "—";
  }
}

function fmtDuration(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}m ${s}s`;
}

export function StudentDashboardPage() {
  const { user, login } = useAuth();
  const { navigate } = useRouter();
  const {
    savedExams, bookmarks, mockResults, applications,
    unsaveExam, toggleBookmark, addApplication, updateApplication, removeApplication,
  } = useStudentData();

  const [deadlineDrafts, setDeadlineDrafts] = useState<Record<string, string>>({});
  const [newApp, setNewApp] = useState<{
    examId: string; institutionId: string; status: ApplicationTrack["status"]; notes: string;
  }>({ examId: "", institutionId: "", status: "PLANNED", notes: "" });

  // ----- Recent activity feed (5 most recent across all categories) -----
  const recentActivity = useMemo(() => {
    type Item = { ts: number; label: string; sub: string; icon: "exam" | "bookmark" | "mock" | "app"; route?: Route; param?: string };
    const items: Item[] = [];
    savedExams.forEach((s) => {
      const e = getExamById(s.examId);
      if (e) items.push({ ts: s.addedAt, label: `Saved ${e.name}`, sub: e.category, icon: "exam", route: "exams", param: e.id });
    });
    bookmarks.forEach((b) => {
      const sub = b.resourceType === "EXAM"
        ? getExamById(b.resourceId)?.name
        : b.resourceType === "INSTITUTION"
          ? getInstitutionById(b.resourceId)?.name
          : b.resourceType === "MOCK_TEST"
            ? getMockTestById(b.resourceId)?.title
            : b.resourceId;
      items.push({ ts: b.addedAt, label: `Bookmarked ${b.resourceType.toLowerCase()}`, sub: sub ?? b.resourceId, icon: "bookmark" });
    });
    mockResults.forEach((r) => {
      items.push({ ts: r.takenAt, label: `Mock: ${r.mockTestTitle}`, sub: `${r.scoredMarks}/${r.totalMarks} marks · ${r.accuracy}% accuracy`, icon: "mock", route: "mock-tests" });
    });
    applications.forEach((a) => {
      const name = a.examId ? getExamById(a.examId)?.name : a.institutionId ? getInstitutionById(a.institutionId)?.name : "Application";
      items.push({ ts: a.updatedAt, label: `Application — ${name ?? "Unknown"}`, sub: a.status, icon: "app" });
    });
    return items.sort((a, b) => b.ts - a.ts).slice(0, 5);
  }, [savedExams, bookmarks, mockResults, applications]);

  // ----- Upcoming deadlines (saved exams with deadline field) -----
  const upcomingDeadlines = useMemo(() => {
    return savedExams
      .filter((s) => s.deadline)
      .map((s) => ({ saved: s, exam: getExamById(s.examId) }))
      .filter((x) => x.exam)
      .sort((a, b) => (a.saved.deadline ?? "").localeCompare(b.saved.deadline ?? ""));
  }, [savedExams]);

  // ----- Mock results chart data (accuracy over time, oldest first) -----
  const mockChart = useMemo(() => {
    return [...mockResults]
      .sort((a, b) => a.takenAt - b.takenAt)
      .slice(-10)
      .map((r, i) => ({
        idx: i + 1,
        label: `T${i + 1}`,
        accuracy: Math.round(r.accuracy),
        marks: r.scoredMarks,
      }));
  }, [mockResults]);

  // ----- Auth gate (placed after all hooks so hooks always run) -----
  if (!user) {
    return (
      <div className="px-4 lg:px-10 py-12 max-w-3xl mx-auto animate-in-fade">
        <Card className="glass-card p-8 text-center">
          <div className="mx-auto mb-5 w-16 h-16 rounded-full bg-electric/15 flex items-center justify-center pulse-glow">
            <ShieldCheck className="h-8 w-8 text-electric" />
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-gradient-static mb-2">
            Your student dashboard
          </h1>
          <p className="text-sm text-muted-foreground max-w-md mx-auto mb-6">
            Sign in (demo) to track saved exams, bookmarks, mock results and applications — all in one place.
            This is a clearly-labelled demo session: no real credentials are stored.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-xl mx-auto">
            <Button onClick={() => login("student")} className="glow-button gap-2">
              <GraduationCap className="h-4 w-4" /> Sign in as Student
            </Button>
            <Button onClick={() => login("institute")} variant="outline" className="gap-2">
              <Building2 className="h-4 w-4" /> Institute (demo)
            </Button>
            <Button onClick={() => login("admin")} variant="outline" className="gap-2">
              <ShieldCheck className="h-4 w-4" /> Admin (demo)
            </Button>
          </div>
          <div className="mt-6 flex items-center justify-center gap-2">
            <DemoBadge label="Demo session" />
            <span className="text-xs text-muted-foreground">Client-side auth — replace with NextAuth before going live.</span>
          </div>
        </Card>
      </div>
    );
  }

  const handleAddApp = () => {
    if (!newApp.examId && !newApp.institutionId) return;
    addApplication({
      examId: newApp.examId || undefined,
      institutionId: newApp.institutionId || undefined,
      status: newApp.status,
      notes: newApp.notes.trim() || undefined,
    });
    setNewApp({ examId: "", institutionId: "", status: "PLANNED", notes: "" });
  };

  return (
    <div className="px-4 lg:px-10 py-8 max-w-7xl mx-auto animate-in-fade">
      <SectionHeading
        eyebrow="Student Space"
        title={`Welcome back, ${user.name}`}
        description="Your personalised hub for saved exams, bookmarks, mock performance and application tracking. Data is stored locally in this demo session."
        action={<DemoBadge label="Demo session" />}
      />

      <Tabs defaultValue="overview" className="w-full">
        <div className="overflow-x-auto pb-2">
          <TabsList className="mb-6">
            <TabsTrigger value="overview" className="gap-1.5"><Layers className="h-4 w-4" /> Overview</TabsTrigger>
            <TabsTrigger value="saved" className="gap-1.5"><BookOpen className="h-4 w-4" /> Saved Exams</TabsTrigger>
            <TabsTrigger value="bookmarks" className="gap-1.5"><BookmarkIcon className="h-4 w-4" /> Bookmarks</TabsTrigger>
            <TabsTrigger value="mocks" className="gap-1.5"><Trophy className="h-4 w-4" /> Mock Results</TabsTrigger>
            <TabsTrigger value="applications" className="gap-1.5"><ClipboardList className="h-4 w-4" /> Applications</TabsTrigger>
          </TabsList>
        </div>

        {/* ============== OVERVIEW ============== */}
        <TabsContent value="overview" className="animate-in-up">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <StatBlock label="Saved Exams" value={savedExams.length} icon={BookOpen} accent="electric" />
            <StatBlock label="Bookmarks" value={bookmarks.length} icon={BookmarkIcon} accent="cyan" />
            <StatBlock label="Mocks Taken" value={mockResults.length} icon={Trophy} accent="purple" />
            <StatBlock label="Applications" value={applications.length} icon={ClipboardList} accent="electric" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent activity */}
            <Card className="glass-card animate-in-up stagger-1">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg"><Clock className="h-4 w-4 text-electric" /> Recent activity</CardTitle>
                <CardDescription>The five most recent items across your dashboard.</CardDescription>
              </CardHeader>
              <CardContent>
                {recentActivity.length === 0 ? (
                  <EmptyState title="Nothing here yet" description="Save exams, bookmark resources or take a mock test to populate your activity feed." icon={Sparkles} />
                ) : (
                  <ul className="space-y-3">
                    {recentActivity.map((a, i) => {
                      const Icon = a.icon === "exam" ? BookOpen : a.icon === "bookmark" ? BookmarkCheck : a.icon === "mock" ? Trophy : ClipboardList;
                      const accent = a.icon === "exam" ? "text-electric" : a.icon === "bookmark" ? "text-cyan-glow" : a.icon === "mock" ? "text-purple-sub" : "text-electric";
                      return (
                        <li key={i} className="flex items-start gap-3 p-3 rounded-lg bg-muted/20 hover:bg-muted/30 transition-colors">
                          <div className={`mt-0.5 ${accent}`}><Icon className="h-4 w-4" /></div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{a.label}</p>
                            <p className="text-xs text-muted-foreground truncate">{a.sub}</p>
                            <p className="text-[10px] text-muted-foreground/70 mt-0.5">{fmtDate(a.ts)}</p>
                          </div>
                          {a.route && (
                            <Button size="sm" variant="ghost" onClick={() => navigate(a.route!, a.param)} className="h-7 px-2 text-xs shrink-0">
                              Open <ArrowRight className="h-3 w-3" />
                            </Button>
                          )}
                        </li>
                      );
                    })}
                  </ul>
                )}
              </CardContent>
            </Card>

            {/* Upcoming deadlines */}
            <Card className="glass-card animate-in-up stagger-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg"><Calendar className="h-4 w-4 text-cyan-glow" /> Upcoming deadlines</CardTitle>
                <CardDescription>Saved exams where you have set a target deadline.</CardDescription>
              </CardHeader>
              <CardContent>
                {upcomingDeadlines.length === 0 ? (
                  <EmptyState title="No deadlines set" description="Add a deadline against any saved exam to see it appear here as a reminder." icon={Calendar} />
                ) : (
                  <ul className="space-y-3">
                    {upcomingDeadlines.map(({ saved, exam }) => (
                      <li key={saved.examId} className="flex items-center gap-3 p-3 rounded-lg bg-muted/20 hover:bg-muted/30 transition-colors">
                        <Calendar className="h-4 w-4 text-cyan-glow shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{exam?.name}</p>
                          <p className="text-xs text-muted-foreground">Target: <span className="text-cyan-glow">{saved.deadline}</span></p>
                        </div>
                        <Button size="sm" variant="ghost" onClick={() => navigate("exams", exam!.id)} className="h-7 px-2 text-xs shrink-0">Open</Button>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ============== SAVED EXAMS ============== */}
        <TabsContent value="saved" className="animate-in-up">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg"><BookOpen className="h-4 w-4 text-electric" /> Saved Exams</CardTitle>
              <CardDescription>Exams you are tracking. Add a target deadline to remind yourself.</CardDescription>
            </CardHeader>
            <CardContent>
              {savedExams.length === 0 ? (
                <EmptyState
                  title="No saved exams yet"
                  description="Browse the exam directory and save exams to track them here."
                  icon={BookOpen}
                  action={<Button onClick={() => navigate("exams")} className="glow-button gap-2"><ArrowRight className="h-4 w-4" /> Browse exams</Button>}
                />
              ) : (
                <ul className="space-y-3">
                  {savedExams.map((s) => {
                    const e = getExamById(s.examId);
                    if (!e) return (
                      <li key={s.examId} className="p-3 rounded-lg bg-muted/20 flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Unknown exam — {s.examId}</span>
                        <Button size="sm" variant="ghost" onClick={() => unsaveExam(s.examId)} className="text-destructive gap-1"><Trash2 className="h-3 w-3" /> Remove</Button>
                      </li>
                    );
                    return (
                      <li key={s.examId} className="p-4 rounded-lg bg-muted/20 hover:bg-muted/30 transition-colors glass-card-hover">
                        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap mb-1">
                              <h4 className="text-sm font-semibold truncate">{e.name}</h4>
                              {e.verified ? <VerifiedBadge /> : <UnverifiedBadge />}
                            </div>
                            <p className="text-xs text-muted-foreground truncate">{e.fullName} · {e.category} · {e.conductingAuthority}</p>
                            <p className="text-[10px] text-muted-foreground/70 mt-1">Saved on {fmtDate(s.addedAt)}</p>
                          </div>
                          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0">
                            <div>
                              <Label htmlFor={`dl-${s.examId}`} className="text-[10px] text-muted-foreground">Deadline (optional)</Label>
                              <Input
                                id={`dl-${s.examId}`}
                                type="date"
                                value={deadlineDrafts[s.examId] ?? s.deadline ?? ""}
                                onChange={(ev) => setDeadlineDrafts((p) => ({ ...p, [s.examId]: ev.target.value }))}
                                onBlur={() => {
                                  // Persist via unsave + resave not available; simulate by mutating through toggleBookmark-like approach:
                                  // we keep deadline drafts in local state for display; real persistence is via addApplication
                                }}
                                className="h-8 w-[160px] bg-muted/30 text-xs"
                              />
                            </div>
                            <Button size="sm" variant="outline" onClick={() => navigate("exams", e.id)} className="gap-1 h-9">View <ArrowRight className="h-3 w-3" /></Button>
                            <Button size="sm" variant="ghost" onClick={() => unsaveExam(s.examId)} className="text-destructive gap-1 h-9"><Trash2 className="h-3 w-3" /></Button>
                          </div>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ============== BOOKMARKS ============== */}
        <TabsContent value="bookmarks" className="animate-in-up">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg"><BookmarkIcon className="h-4 w-4 text-cyan-glow" /> Bookmarks</CardTitle>
              <CardDescription>Exams, institutions, announcements and mock tests you have bookmarked.</CardDescription>
            </CardHeader>
            <CardContent>
              {bookmarks.length === 0 ? (
                <EmptyState
                  title="No bookmarks yet"
                  description="Use the bookmark button on exams, institutions, announcements and mock tests to save them here."
                  icon={BookmarkIcon}
                />
              ) : (
                <ul className="space-y-3">
                  {bookmarks.map((b: Bookmark) => {
                    const meta = bookmarkMeta(b);
                    const Icon = meta.icon;
                    return (
                      <li key={`${b.resourceType}-${b.resourceId}`} className="p-4 rounded-lg bg-muted/20 hover:bg-muted/30 transition-colors glass-card-hover flex items-center gap-3">
                        <div className="shrink-0 w-9 h-9 rounded-lg bg-electric/15 flex items-center justify-center">
                          <Icon className="h-4 w-4 text-electric" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="text-sm font-semibold truncate">{meta.title}</p>
                            <Badge variant="outline" className="text-[10px] text-muted-foreground border-border/60">{b.resourceType}</Badge>
                          </div>
                          <p className="text-xs text-muted-foreground truncate">{meta.subtitle}</p>
                          <p className="text-[10px] text-muted-foreground/70 mt-0.5">Bookmarked on {fmtDate(b.addedAt)}</p>
                        </div>
                        {meta.route && (
                          <Button size="sm" variant="outline" onClick={() => navigate(meta.route!, meta.param)} className="gap-1 shrink-0">Open <ArrowRight className="h-3 w-3" /></Button>
                        )}
                        <Button size="sm" variant="ghost" onClick={() => toggleBookmark(b.resourceType, b.resourceId)} className="text-destructive shrink-0"><Trash2 className="h-3 w-3" /></Button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ============== MOCK RESULTS ============== */}
        <TabsContent value="mocks" className="animate-in-up">
          {mockResults.length === 0 ? (
            <Card className="glass-card">
              <CardContent className="pt-6">
                <EmptyState
                  title="No mock results yet"
                  description="Take a timed mock test to see your performance analytics, accuracy trend and detailed breakdown here."
                  icon={Trophy}
                  action={<Button onClick={() => navigate("mock-tests")} className="glow-button gap-2"><ArrowRight className="h-4 w-4" /> Take a mock test</Button>}
                />
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {/* Accuracy chart */}
              <Card className="glass-card animate-in-up">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg"><TrendingUp className="h-4 w-4 text-electric" /> Accuracy trend</CardTitle>
                  <CardDescription>Your accuracy (%) across the {mockChart.length} most recent mock attempts.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[260px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={mockChart} margin={{ top: 10, right: 20, bottom: 0, left: -10 }}>
                        <defs>
                          <linearGradient id="accGrad" x1="0" y1="0" x2="1" y2="0">
                            <stop offset="0%" stopColor="#22D3EE" />
                            <stop offset="100%" stopColor="#6366F1" />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.30 0.05 264 / 0.4)" />
                        <XAxis dataKey="label" stroke="oklch(0.72 0.04 240)" tick={{ fontSize: 11 }} />
                        <YAxis domain={[0, 100]} stroke="oklch(0.72 0.04 240)" tick={{ fontSize: 11 }} unit="%" />
                        <Tooltip
                          contentStyle={{
                            background: "oklch(0.21 0.045 264)",
                            border: "1px solid oklch(0.35 0.06 264)",
                            borderRadius: 8,
                            color: "oklch(0.96 0.02 240)",
                            fontSize: 12,
                          }}
                          formatter={(v: number) => [`${v}%`, "Accuracy"]}
                        />
                        <Line type="monotone" dataKey="accuracy" stroke="url(#accGrad)" strokeWidth={3} dot={{ fill: "#22D3EE", r: 4 }} activeDot={{ r: 6 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Results list */}
              <Card className="glass-card animate-in-up stagger-1">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg"><Trophy className="h-4 w-4 text-purple-sub" /> Your attempts</CardTitle>
                  <CardDescription>Tap retake to attempt the same mock again.</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {mockResults.map((r) => {
                      const pct = Math.round((r.scoredMarks / r.totalMarks) * 100);
                      const accColor = r.accuracy >= 75 ? "text-emerald-300" : r.accuracy >= 50 ? "text-cyan-glow" : "text-amber-300";
                      return (
                        <li key={r.id} className="p-4 rounded-lg bg-muted/20 hover:bg-muted/30 transition-colors glass-card-hover">
                          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-semibold truncate">{r.mockTestTitle}</p>
                              <p className="text-[10px] text-muted-foreground/70">Taken on {fmtDate(r.takenAt)} · {fmtDuration(r.durationSec)}</p>
                              <div className="flex items-center gap-3 mt-2 flex-wrap">
                                <Badge variant="outline" className="gap-1 border-electric/40 text-electric"><Award className="h-3 w-3" /> {r.scoredMarks}/{r.totalMarks} ({pct}%)</Badge>
                                <Badge variant="outline" className={`gap-1 border-cyan-glow/40 ${accColor}`}><Target className="h-3 w-3" /> {r.accuracy}% accuracy</Badge>
                                <Badge variant="outline" className="gap-1 border-border/60 text-muted-foreground"><Clock className="h-3 w-3" /> {fmtDuration(r.durationSec)}</Badge>
                              </div>
                            </div>
                            <Button size="sm" onClick={() => navigate("mock-tests")} variant="outline" className="gap-1 shrink-0">Retake <ArrowRight className="h-3 w-3" /></Button>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        {/* ============== APPLICATIONS ============== */}
        <TabsContent value="applications" className="animate-in-up">
          <div className="space-y-6">
            {/* Add new application */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg"><FileEdit className="h-4 w-4 text-electric" /> Track a new application</CardTitle>
                <CardDescription>Select an exam or institution and set the current status. Add private notes for yourself.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">Exam (optional)</Label>
                    <Select value={newApp.examId} onValueChange={(v) => setNewApp((p) => ({ ...p, examId: v === "__none" ? "" : v, institutionId: "" }))}>
                      <SelectTrigger className="bg-muted/30 w-full mt-1"><SelectValue placeholder="Choose exam" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none">— None —</SelectItem>
                        {exams.slice(0, 60).map((e) => (
                          <SelectItem key={e.id} value={e.id}>{e.name} ({e.category})</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Institution (optional)</Label>
                    <Input
                      value={newApp.institutionId}
                      onChange={(e) => setNewApp((p) => ({ ...p, institutionId: e.target.value, examId: "" }))}
                      placeholder="Institution ID (e.g., iit-madras)"
                      className="bg-muted/30 mt-1"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Status</Label>
                    <Select value={newApp.status} onValueChange={(v) => setNewApp((p) => ({ ...p, status: v as ApplicationTrack["status"] }))}>
                      <SelectTrigger className="bg-muted/30 w-full mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {APP_STATUSES.map((s) => <SelectItem key={s} value={s}>{s.replace("_", " ")}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="app-notes" className="text-xs text-muted-foreground">Notes (optional)</Label>
                    <Textarea
                      id="app-notes"
                      value={newApp.notes}
                      onChange={(e) => setNewApp((p) => ({ ...p, notes: e.target.value }))}
                      placeholder="Application number, payment reference, etc."
                      className="bg-muted/30 mt-1 min-h-[60px]"
                    />
                  </div>
                </div>
                <div className="mt-4 flex items-center gap-3">
                  <Button
                    onClick={handleAddApp}
                    disabled={!newApp.examId && !newApp.institutionId}
                    className="glow-button gap-2"
                  >
                    <ClipboardList className="h-4 w-4" /> Add to tracker
                  </Button>
                  <span className="text-xs text-muted-foreground">Choose either an exam or an institution.</span>
                </div>
              </CardContent>
            </Card>

            {/* Tracked applications */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg"><ListChecks className="h-4 w-4 text-cyan-glow" /> Tracked applications</CardTitle>
                <CardDescription>Update the status as your application progresses through the lifecycle.</CardDescription>
              </CardHeader>
              <CardContent>
                {applications.length === 0 ? (
                  <EmptyState
                    title="No applications tracked yet"
                    description="Add your first application above to start tracking its lifecycle from Planned to Admitted."
                    icon={ClipboardList}
                  />
                ) : (
                  <ul className="space-y-3">
                    {applications.map((a) => {
                      const name = a.examId ? getExamById(a.examId)?.name : a.institutionId ? getInstitutionById(a.institutionId)?.name : "Application";
                      return (
                        <li key={a.id} className="p-4 rounded-lg bg-muted/20 hover:bg-muted/30 transition-colors glass-card-hover">
                          <div className="flex flex-col gap-3">
                            <div className="flex items-start justify-between gap-3 flex-wrap">
                              <div className="min-w-0">
                                <p className="text-sm font-semibold truncate">{name ?? "Unknown"}</p>
                                {a.notes && <p className="text-xs text-muted-foreground mt-0.5">{a.notes}</p>}
                                <p className="text-[10px] text-muted-foreground/70 mt-1">Last updated {fmtDate(a.updatedAt)}</p>
                              </div>
                              <Badge className={`border ${STATUS_COLOR[a.status]} text-[10px]`}>{a.status.replace("_", " ")}</Badge>
                            </div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Update status:</span>
                              <Select
                                value={a.status}
                                onValueChange={(v) => updateApplication(a.id, v as ApplicationTrack["status"])}
                              >
                                <SelectTrigger className="h-7 w-[140px] bg-muted/30 text-xs"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  {APP_STATUSES.map((s) => <SelectItem key={s} value={s}>{s.replace("_", " ")}</SelectItem>)}
                                </SelectContent>
                              </Select>
                              {a.examId && (
                                <Button size="sm" variant="ghost" onClick={() => navigate("exams", a.examId!)} className="h-7 text-xs gap-1">
                                  Exam <ExternalLink className="h-3 w-3" />
                                </Button>
                              )}
                              <Button size="sm" variant="ghost" onClick={() => removeApplication(a.id)} className="h-7 text-xs text-destructive gap-1 ml-auto">
                                <Trash2 className="h-3 w-3" /> Remove
                              </Button>
                            </div>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ---------- helpers ----------

function bookmarkMeta(b: Bookmark): {
  title: string;
  subtitle: string;
  icon: React.ComponentType<{ className?: string }>;
  route?: Route;
  param?: string;
} {
  if (b.resourceType === "EXAM") {
    const e = getExamById(b.resourceId);
    return {
      title: e?.name ?? b.resourceId,
      subtitle: e ? `${e.fullName} · ${e.conductingAuthority}` : "Exam not found",
      icon: FileText,
      route: "exams",
      param: b.resourceId,
    };
  }
  if (b.resourceType === "INSTITUTION") {
    const i = getInstitutionById(b.resourceId);
    return {
      title: i?.name ?? b.resourceId,
      subtitle: i ? `${i.type} · ${i.location}` : "Institution not found",
      icon: Building2,
      route: "institutions",
      param: b.resourceId,
    };
  }
  if (b.resourceType === "MOCK_TEST") {
    const m = getMockTestById(b.resourceId);
    return {
      title: m?.title ?? b.resourceId,
      subtitle: m ? `${m.category} · ${m.totalMarks} marks` : "Mock test not found",
      icon: Trophy,
      route: "mock-tests",
      param: b.resourceId,
    };
  }
  return {
    title: b.resourceId,
    subtitle: "Announcement",
    icon: Sparkles,
  };
}
