"use client";

import { useRouter } from "@/lib/router";
import { getMockTestById } from "@/data/mock-tests";
import { useMockSession } from "@/lib/stores";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EmptyState, StatBlock } from "@/components/common/ui-bits";
import {
  Trophy, Target, CheckCircle2, XCircle, Circle, Clock,
  ArrowLeft, ArrowRight, RotateCcw, Eye, Award,
} from "lucide-react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid,
  PieChart, Pie, Cell, Legend, LineChart, Line,
} from "recharts";
import { cn } from "@/lib/utils";

export function MockTestResultPage() {
  const { navigate } = useRouter();
  const { lastResult } = useMockSession();
  const session = useMockSession();

  if (!lastResult) {
    return (
      <div className="px-4 lg:px-10 py-12 max-w-3xl mx-auto">
        <EmptyState
          title="No result to display"
          description="Take a mock test first to see your performance analytics here."
          icon={Trophy}
          action={<Button onClick={() => navigate("mock-tests")} className="glow-button">Browse mock tests</Button>}
        />
      </div>
    );
  }

  const test = getMockTestById(lastResult.mockTestId);
  const percentage = (lastResult.scoredMarks / lastResult.totalMarks) * 100;
  const fmtDur = (s: number) => `${Math.floor(s / 60)}m ${s % 60}s`;

  const sectionData = lastResult.perSection.map((s) => ({
    name: s.name,
    Scored: Math.max(0, s.scored),
    Total: s.total,
    Accuracy: s.correct + s.wrong > 0 ? Math.round((s.correct / (s.correct + s.wrong)) * 100) : 0,
  }));

  const pieData = [
    { name: "Correct", value: lastResult.correct, color: "#22D3EE" },
    { name: "Wrong", value: lastResult.wrong, color: "#EF4444" },
    { name: "Unattempted", value: lastResult.unattempted, color: "#6B7280" },
  ];

  const questionLogData = lastResult.perQuestion.map((q, i) => ({
    q: i + 1,
    scored: q.scored,
    time: q.timeSpentSec,
  }));

  const reset = () => {
    session.reset();
    navigate("mock-tests");
  };

  return (
    <div className="px-4 lg:px-10 py-8 max-w-6xl mx-auto animate-in-fade">
      <Button variant="ghost" size="sm" onClick={() => navigate("mock-tests")} className="mb-4 gap-1">
        <ArrowLeft className="h-4 w-4" /> Back to mock tests
      </Button>

      {/* Hero result card */}
      <Card className="glass-card glass-card-hover p-6 lg:p-8 mb-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 h-40 w-40 rounded-full bg-electric/20 blur-3xl" />
        <div className="grid lg:grid-cols-3 gap-6 items-center">
          <div className="lg:col-span-2 space-y-3">
            <Badge variant="outline" className="border-electric/40 text-electric">{test?.category ?? ""}</Badge>
            <h1 className="text-3xl font-bold text-gradient-static">{test?.title ?? "Mock Test"}</h1>
            <p className="text-sm text-muted-foreground">{test?.description}</p>
            <div className="flex flex-wrap items-baseline gap-3 mt-2">
              <p className="text-5xl font-extrabold text-gradient-electric">{lastResult.scoredMarks.toFixed(1)}</p>
              <p className="text-xl text-muted-foreground">/ {lastResult.totalMarks}</p>
              <Badge variant="outline" className={cn("text-sm font-bold", percentage >= 60 ? "border-emerald-400 text-emerald-300" : percentage >= 35 ? "border-amber-400 text-amber-300" : "border-destructive text-destructive")}>
                {percentage.toFixed(1)}%
              </Badge>
            </div>
          </div>
          <div className="flex justify-center">
            <div className="relative h-32 w-32">
              <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
                <circle cx="50" cy="50" r="42" stroke="currentColor" strokeWidth="6" fill="none" className="text-muted/30" />
                <circle
                  cx="50" cy="50" r="42"
                  stroke="url(#scoreGrad)" strokeWidth="6" fill="none"
                  strokeDasharray={`${(percentage / 100) * 264} 264`}
                  strokeLinecap="round"
                />
                <defs>
                  <linearGradient id="scoreGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#22D3EE" />
                    <stop offset="100%" stopColor="#A855F7" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <Award className="h-5 w-5 text-cyan-glow mb-1" />
                <span className="text-2xl font-bold">{percentage.toFixed(0)}%</span>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Quick stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatBlock label="Correct" value={lastResult.correct} icon={CheckCircle2} accent="cyan" />
        <StatBlock label="Wrong" value={lastResult.wrong} icon={XCircle} accent="electric" />
        <StatBlock label="Unattempted" value={lastResult.unattempted} icon={Circle} accent="purple" />
        <StatBlock label="Time taken" value={fmtDur(lastResult.durationSec)} icon={Clock} accent="electric" />
      </div>

      {/* Accuracy + Pie */}
      <div className="grid lg:grid-cols-2 gap-6 mb-6">
        <Card className="glass-card p-5">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-electric mb-3">Question distribution</h3>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={pieData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90} paddingAngle={2}>
                {pieData.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Legend />
              <Tooltip contentStyle={{ background: "#0a0e27", border: "1px solid #1e3a8a", borderRadius: 8 }} />
            </PieChart>
          </ResponsiveContainer>
        </Card>
        <Card className="glass-card p-5">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-electric mb-3">Section performance</h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={sectionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e3a8a" opacity={0.3} />
              <XAxis dataKey="name" stroke="#6b7280" fontSize={11} />
              <YAxis stroke="#6b7280" fontSize={11} />
              <Tooltip contentStyle={{ background: "#0a0e27", border: "1px solid #1e3a8a", borderRadius: 8 }} />
              <Legend />
              <Bar dataKey="Scored" fill="#22D3EE" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Total" fill="#1e3a8a" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Per-question time chart */}
      <Card className="glass-card p-5 mb-6">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-electric mb-3">Time spent per question (seconds)</h3>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={questionLogData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e3a8a" opacity={0.3} />
            <XAxis dataKey="q" stroke="#6b7280" fontSize={11} label={{ value: "Q#", position: "insideBottom", offset: -2, fill: "#6b7280", fontSize: 11 }} />
            <YAxis stroke="#6b7280" fontSize={11} />
            <Tooltip contentStyle={{ background: "#0a0e27", border: "1px solid #1e3a8a", borderRadius: 8 }} />
            <Line type="monotone" dataKey="time" stroke="#22D3EE" strokeWidth={2} dot={{ r: 3, fill: "#22D3EE" }} />
          </LineChart>
        </ResponsiveContainer>
      </Card>

      {/* Tabs: Review + Explanations */}
      <Tabs defaultValue="review" className="space-y-4">
        <TabsList className="bg-muted/30">
          <TabsTrigger value="review">Question review</TabsTrigger>
          <TabsTrigger value="explanations">Explanations</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="review" className="space-y-3">
          {test?.questions.map((q, idx) => {
            const ans = lastResult.perQuestion.find((p) => p.questionId === q.id)!;
            return (
              <Card key={q.id} className={cn("p-4 border-l-2",
                ans.unattempted ? "border-l-muted-foreground/40" : ans.correct ? "border-l-emerald-500" : "border-l-destructive")}>
                <div className="flex items-start gap-3">
                  <div className={cn("h-6 w-6 shrink-0 rounded-full flex items-center justify-center text-xs font-bold",
                    ans.unattempted ? "bg-muted/40 text-muted-foreground" : ans.correct ? "bg-emerald-500/20 text-emerald-300" : "bg-destructive/20 text-destructive")}>
                    {ans.unattempted ? "—" : ans.correct ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <Badge variant="outline" className="text-[10px]">Q{idx + 1}</Badge>
                      <Badge variant="outline" className="text-[10px]">{q.topic}</Badge>
                      <span className="text-[11px] text-muted-foreground">{ans.timeSpentSec}s</span>
                      <span className={cn("text-[11px] font-semibold ml-auto", ans.correct ? "text-emerald-300" : ans.unattempted ? "text-muted-foreground" : "text-destructive")}>
                        {ans.scored >= 0 ? `+${ans.scored}` : ans.scored} marks
                      </span>
                    </div>
                    <p className="text-sm mb-2">{q.question}</p>
                    <div className="space-y-1 text-xs">
                      {q.options.map((opt, oi) => {
                        const isChosen = ans.chosen.includes(oi);
                        const isCorrect = q.correct.includes(oi);
                        return (
                          <div key={oi} className={cn("px-2 py-1 rounded flex items-center gap-2",
                            isCorrect ? "bg-emerald-500/15 text-emerald-200" : isChosen ? "bg-destructive/15 text-destructive" : "text-muted-foreground")}>
                            <span className="font-bold">{String.fromCharCode(65 + oi)}.</span>
                            <span>{opt}</span>
                            {isCorrect && <CheckCircle2 className="h-3 w-3 ml-auto" />}
                            {isChosen && !isCorrect && <XCircle className="h-3 w-3 ml-auto" />}
                            {isChosen && isCorrect && <span className="text-[10px] ml-auto">your choice</span>}
                          </div>
                        );
                      })}
                      {q.type === "numerical" && (
                        <div className="text-xs">
                          Your answer: <span className="font-semibold">{ans.chosen.length === 0 ? "—" : "(numerical)"}</span> · Correct: <span className="text-emerald-300 font-semibold">{q.numericalAnswer}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </TabsContent>

        <TabsContent value="explanations" className="space-y-3">
          {test?.questions.map((q, idx) => (
            <Card key={q.id} className="p-4">
              <p className="text-sm font-medium mb-1">Q{idx + 1}. {q.question}</p>
              <p className="text-xs text-muted-foreground leading-relaxed">{q.explanation}</p>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {lastResult.perSection.map((s) => (
              <Card key={s.sectionId} className="glass-card p-4">
                <p className="text-sm font-semibold mb-1">{s.name}</p>
                <div className="space-y-1 text-xs text-muted-foreground">
                  <p>Score: <span className="text-foreground font-semibold">{Math.max(0, s.scored).toFixed(1)} / {s.total}</span></p>
                  <p>Correct: <span className="text-emerald-300">{s.correct}</span> · Wrong: <span className="text-destructive">{s.wrong}</span> · Unattempted: <span className="text-muted-foreground">{s.unattempted}</span></p>
                  <Progress value={(s.correct / (s.correct + s.wrong + s.unattempted)) * 100} className="h-1 mt-1" />
                </div>
              </Card>
            ))}
          </div>
          <Card className="glass-card p-5">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-electric mb-2">Recommendations</h3>
            <ul className="text-xs text-muted-foreground space-y-1.5 list-disc pl-4">
              {lastResult.perSection.filter((s) => s.wrong > s.correct).map((s) => (
                <li key={s.sectionId}>Revise fundamentals in <strong className="text-foreground">{s.name}</strong> — wrong answers exceeded correct ones.</li>
              ))}
              {lastResult.unattempted > lastResult.correct + lastResult.wrong / 2 && (
                <li>Time management needs work — {lastResult.unattempted} questions went unattempted. Practice pacing.</li>
              )}
              {lastResult.accuracy >= 80 && (
                <li>Strong accuracy ({lastResult.accuracy}%) — attempt more questions next time to maximise score.</li>
              )}
              <li>Re-attempt this test in 5–7 days to measure improvement.</li>
            </ul>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex flex-wrap items-center justify-between gap-3 mt-6">
        <Button variant="outline" onClick={() => navigate("student-dashboard")}>View dashboard <ArrowRight className="h-4 w-4 ml-1" /></Button>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={reset}><RotateCcw className="h-4 w-4 mr-1" /> Take another test</Button>
          <Button className="glow-button" onClick={() => navigate("chatbot")}>Ask AI for guidance <ArrowRight className="h-4 w-4 ml-1" /></Button>
        </div>
      </div>
    </div>
  );
}
