/**
 * INSTIQUEST Frequently Asked Questions
 * -------------------------------------------------------------
 * Original, generic FAQs about the portal and Indian admissions.
 * No copyrighted content.
 */

export interface FAQItem {
  id: string;
  category: "General" | "Exams" | "Mock Tests" | "AI Assistant" | "Advertising" | "Account";
  question: string;
  answer: string;
}

export const faqCategories = ["General", "Exams", "Mock Tests", "AI Assistant", "Advertising", "Account"] as const;

export const faqs: FAQItem[] = [
  // General
  {
    id: "faq-what-is",
    category: "General",
    question: "What is INSTIQUEST?",
    answer:
      "INSTIQUEST is a futuristic educational admission portal that aggregates 120+ entrance exams, 100+ institutions, hard-level mock tests, an AI admission assistant and an institute advertising gateway. Verified directory information is clearly distinguished from AI-generated guidance, and unverified items are flagged for review.",
  },
  {
    id: "faq-who-owns",
    category: "General",
    question: "Who owns INSTIQUEST?",
    answer:
      "INSTIQUEST is owned by S. Subash (placeholder until approved for publication). The brand is INSTIQUEST and the subtitle is WEB CREATORS. Update ownership details in src/data/site-config.ts before launch.",
  },
  {
    id: "faq-free",
    category: "General",
    question: "Is INSTIQUEST free to use?",
    answer:
      "Browsing the directory, taking mock tests, using the AI assistant and tracking applications are free for students in this demo build. Institute advertising submissions are subject to admin moderation; payment integration is a clearly-labelled demo placeholder.",
  },
  {
    id: "faq-verified",
    category: "General",
    question: "How do I know if the information is verified?",
    answer:
      "Every directory entry carries either a green 'Verified' badge or an amber 'Unverified — pending review' badge. Verified entries have their conducting authority, course, eligibility and official website confirmed. Unverified items must be cross-checked on the official portal.",
  },
  {
    id: "faq-mobile",
    category: "General",
    question: "Does INSTIQUEST work on mobile?",
    answer:
      "Yes. The layout is mobile-first responsive. On small screens the sidebar collapses into a slide-in sheet accessible via the menu icon. Touch targets are at least 44px.",
  },

  // Exams
  {
    id: "faq-exam-dates",
    category: "Exams",
    question: "Does INSTIQUEST publish exam dates and application windows?",
    answer:
      "No. Exam dates, application windows, fee structures and specific eligibility percentages change every cycle and across categories. INSTIQUEST links to the official portal for every exam but does not publish time-sensitive dates as confirmed facts. Always check the official notification.",
  },
  {
    id: "faq-exam-categories",
    category: "Exams",
    question: "Which exam categories are covered?",
    answer:
      "Engineering, Medical, Management, Law, Design, Architecture, Science, Humanities, Maritime, Defence and Other. 120+ exams are listed across these 11 categories, including JEE Main, JEE Advanced, NEET UG, CAT, CLAT, CUET UG/PG, GATE and many state-level exams.",
  },
  {
    id: "faq-exam-apply",
    category: "Exams",
    question: "Can I apply to exams through INSTIQUEST?",
    answer:
      "No. INSTIQUEST is an information aggregator. To apply, click the 'Visit official website' link on any exam detail page and complete the application on the official portal. The Application Guidance page walks you through the standard 6-step process.",
  },

  // Mock Tests
  {
    id: "faq-mock-original",
    category: "Mock Tests",
    question: "Are mock test questions copied from real exam papers?",
    answer:
      "No. All mock test questions are originally authored by the INSTIQUEST team. They are not copied from any copyrighted exam paper. They mirror the style and difficulty of competitive exams to help you practise under timed conditions.",
  },
  {
    id: "faq-mock-negative",
    category: "Mock Tests",
    question: "Do mock tests have negative marking?",
    answer:
      "Yes. Each mock test has a configurable marking scheme. The default is +4 for correct and -1 for wrong in Engineering/Medical/Law mocks, and +3 / -1 in Management mocks (CAT-style 1/3 negative). Exact marks and negative marking are shown on each test card.",
  },
  {
    id: "faq-mock-types",
    category: "Mock Tests",
    question: "What question types are supported?",
    answer:
      "Four types: single-correct (one right option), multiple-correct (all applicable options), numerical (type a number with tolerance), and assertion-reason (choose the correct A/R relationship). Each test mixes these types across sections.",
  },
  {
    id: "faq-mock-results",
    category: "Mock Tests",
    question: "Are my mock results saved?",
    answer:
      "Yes. Results are saved to your student dashboard (in localStorage for the demo build, server-side when wired with a real backend). You can review per-question explanations and see accuracy trends over time.",
  },

  // AI Assistant
  {
    id: "faq-ai-vs-verified",
    category: "AI Assistant",
    question: "How is AI guidance different from verified information?",
    answer:
      "AI chatbot responses carry a purple 'AI Guidance' badge and a disclaimer line. Verified facts pulled from the INSTIQUEST knowledge base carry a blue 'Verified' badge. The two are never mixed. Always verify AI suggestions on official portals before acting on them.",
  },
  {
    id: "faq-ai-keys",
    category: "AI Assistant",
    question: "Are AI API keys exposed in the frontend?",
    answer:
      "No. The chatbot calls a server-side endpoint (/api/chat) that proxies to the AI provider. API keys are read from server environment variables and never appear in client-side code or network responses.",
  },
  {
    id: "faq-ai-fallback",
    category: "AI Assistant",
    question: "What happens if the AI provider is unavailable?",
    answer:
      "The /api/chat endpoint falls back to the verified knowledge base. If your query matches a KB entry, you get a verified response. If no match is found, the assistant tells you explicitly that no verified answer is available and suggests refining the query.",
  },

  // Advertising
  {
    id: "faq-ad-approval",
    category: "Advertising",
    question: "How long does ad approval take?",
    answer:
      "All submissions enter a PENDING queue. An admin must explicitly approve each submission before it is published. No advertisement is published automatically. In the demo build, approval is done via the admin dashboard's Advertisements tab.",
  },
  {
    id: "faq-ad-payment",
    category: "Advertising",
    question: "Is payment integration live?",
    answer:
      "No. Payment integration is a clearly-labelled demo placeholder. No real checkout happens. The /api/payments/checkout endpoint is documented but not enabled.",
  },
  {
    id: "faq-ad-reject",
    category: "Advertising",
    question: "Can my ad be rejected?",
    answer:
      "Yes. INSTIQUEST reserves the right to reject, edit or remove any advertisement at its sole discretion. Approval does not constitute an endorsement. Common reasons for rejection include misleading claims, unsupported eligibility statements or inappropriate content.",
  },

  // Account
  {
    id: "faq-account-demo",
    category: "Account",
    question: "Is the sign-in real?",
    answer:
      "No. Authentication in this build is a clearly-labelled demo using localStorage. No real credentials are stored. Replace useAuth in src/lib/stores.ts with NextAuth.js credentials/email provider before going live.",
  },
  {
    id: "faq-account-owner",
    category: "Account",
    question: "How do I (the owner) edit the website's template?",
    answer:
      "Only the owner can access the Template Editor page. Sign in with the owner key (configurable in src/data/site-config.ts → owner.ownerKeyPlaceholder). The default placeholder key is shown on the Template Editor login screen for the demo build.",
  },
  {
    id: "faq-account-data",
    category: "Account",
    question: "Where is my data stored?",
    answer:
      "In the demo build: localStorage in your browser (saved exams, bookmarks, mock results, applications, chat thread, visit counts). Clearing browser storage removes all INSTIQUEST data. When you wire a real backend (Prisma + PostgreSQL), data persists server-side.",
  },
];

export function getFaqsByCategory(c: string): FAQItem[] {
  return faqs.filter((f) => f.category === c);
}
