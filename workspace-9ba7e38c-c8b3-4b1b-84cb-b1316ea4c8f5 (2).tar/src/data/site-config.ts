/**
 * INSTIQUEST site configuration
 * -------------------------------------------------------------
 * Central place for brand, ownership and contact details.
 * Every value that is not yet approved for publication is a
 * clearly-labelled placeholder. Update these values here
 * (and only here) before going live.
 *
 * Ownership:  S. Subash  (placeholder until approved)
 * Brand:      INSTIQUEST
 * Subtitle:   WEB CREATORS
 */

export interface SiteConfig {
  brand: string;
  subtitle: string;
  /** Marketing tagline shown with the logo (matches the official PNG logo). */
  tagline: string;
  owner: {
    name: string;
    /** Marked as placeholder until approved for publication. */
    approvedForPublication: boolean;
    /**
     * Owner login key placeholder.
     * Only the owner (using this key) can edit the website's template
     * via the Template Editor page. Replace this with a real hashed
     * credential check via NextAuth before going live.
     */
    ownerKeyPlaceholder: string;
  };
  contact: {
    /** Dedicated business contact email — placeholder. */
    businessEmail: string;
    /** General support email — placeholder. */
    supportEmail: string;
    /** Display phone — placeholder, do not call. */
    phoneDisplay: string;
    /** Postal address — placeholder. */
    address: string;
  };
  social: {
    twitter: string;
    linkedin: string;
    youtube: string;
    instagram: string;
  };
  /** AI chatbot — server-side integration placeholder. */
  chatbot: {
    /** Endpoint that proxies to a server-side AI provider. */
    apiEndpoint: string;
    /** Provider name shown in the UI. */
    providerLabel: string;
    /** Whether the live AI provider is configured. */
    enabled: boolean;
  };
  /** Optional advertising payment integration placeholders. */
  payments: {
    providerLabel: string;
    enabled: boolean;
    /** Server-side endpoint that would create a checkout session. */
    apiEndpoint: string;
  };
  /** Demo feature flags. */
  features: {
    authEnabled: boolean;
    adminEnabled: boolean;
    liveChat: boolean;
  };
  version: string;
  year: number;
}

export const siteConfig: SiteConfig = {
  brand: "INSTIQUEST",
  subtitle: "WEB CREATORS",
  tagline: "EXPLORE • PREPARE • EXCEL",
  owner: {
    name: "S. Subash",
    approvedForPublication: false,
    /**
     * Owner key — REPLACE THIS before going live. Set it to a strong,
     * unguessable string (min 16 chars). Store the real credential
     * server-side (hashed with bcrypt) via NextAuth in production.
     */
    ownerKeyPlaceholder: "SUBASH-OWNER-2026",
  },
  contact: {
    businessEmail: "business@instiquest.example",
    supportEmail: "support@instiquest.example",
    phoneDisplay: "+91-00000-00000",
    address: "Plot 000, Tech Park Avenue, City, India — 000000",
  },
  social: {
    twitter: "https://twitter.com/instiquest",
    linkedin: "https://linkedin.com/company/instiquest",
    youtube: "https://youtube.com/@instiquest",
    instagram: "https://instagram.com/instiquest",
  },
  chatbot: {
    apiEndpoint: "/api/chat",
    providerLabel: "INSTIQUEST AI Assistant",
    enabled: true,
  },
  payments: {
    providerLabel: "Payment Gateway (Demo)",
    enabled: false,
    apiEndpoint: "/api/payments/checkout",
  },
  features: {
    authEnabled: true,
    adminEnabled: true,
    liveChat: false,
  },
  version: "1.0.0",
  year: new Date().getFullYear(),
};

/** Helper: clearly-labelled placeholder for any unverified value. */
export const PLACEHOLDER_REVIEW = "Unverified — pending review";
