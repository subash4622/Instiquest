/**
 * INSTIQUEST Previous Year Question Papers directory.
 * -------------------------------------------------------------
 * INSTIQUEST does NOT host or link to copyrighted question papers.
 * Instead, this directory links to the OFFICIAL portals where exam
 * authorities publish previous year papers / sample papers /
 * question bank entries themselves.
 *
 * Every entry is verified to be an official source. If the official
 * source for a given exam is not known, it is marked "Unverified —
 * pending review" and the entry links only to the exam's homepage.
 */

export const REVIEW = "Unverified — pending review";

export interface PreviousPaperSource {
  id: string;
  examId: string;          // links to exams.ts
  examName: string;
  /** What the official source hosts (sample paper, previous year paper, question bank, etc.) */
  paperType: "Previous Year Paper" | "Sample Paper" | "Question Bank" | "Practice Set" | "Syllabus & Pattern";
  /** How many years/papers are typically available from the official source. */
  availability: string;
  /** The official URL where papers can be downloaded/viewed. */
  officialUrl: string;
  /** Whether the URL was independently verified. */
  verified: boolean;
  notes?: string;
}

export const previousPaperSources: PreviousPaperSource[] = [
  {
    id: "pyq-jee-main",
    examId: "jee-main",
    examName: "JEE Main",
    paperType: "Previous Year Paper",
    availability: "Multiple sessions per year (typically 2024 onwards on the official NTA portal)",
    officialUrl: "https://jeemain.nta.ac.in",
    verified: true,
    notes: "NTA publishes official previous year papers and mock tests on the candidate portal after each session.",
  },
  {
    id: "pyq-jee-advanced",
    examId: "jee-advanced",
    examName: "JEE Advanced",
    paperType: "Previous Year Paper",
    availability: "Papers from 2010 onwards available on the official JEE Advanced portal",
    officialUrl: "https://jeeadv.ac.in/archive.html",
    verified: true,
    notes: "The organising IIT publishes full question papers, answer keys and detailed solutions for past years.",
  },
  {
    id: "pyq-neet-ug",
    examId: "neet-ug",
    examName: "NEET UG",
    paperType: "Previous Year Paper",
    availability: "Available on the official NEET NTA portal post each exam cycle",
    officialUrl: "https://neet.nta.nic.in",
    verified: true,
    notes: "NTA publishes the question paper, answer key and OMR response sheet for each candidate.",
  },
  {
    id: "pyq-cat",
    examId: "cat",
    examName: "CAT",
    paperType: "Previous Year Paper",
    availability: "Last few years (typically 2017 onwards) on the official CAT portal",
    officialUrl: "https://catiim.in",
    verified: true,
    notes: "IIM CAT convening institute releases official previous year papers on catiim.in.",
  },
  {
    id: "pyq-clat",
    examId: "clat",
    examName: "CLAT",
    paperType: "Previous Year Paper",
    availability: "Past years on the Consortium of NLUs portal",
    officialUrl: "https://consortiumofnlus.ac.in/clat-2024/index.html",
    verified: true,
    notes: "The Consortium publishes previous year question papers and sample papers in the 'Previous Year Question Papers' section.",
  },
  {
    id: "pyq-cuet-ug",
    examId: "cuet-ug",
    examName: "CUET UG",
    paperType: "Sample Paper",
    availability: "Official mock tests and sample papers on the NTA CUET portal",
    officialUrl: "https://exams.nta.ac.in/CUET-UG/",
    verified: true,
    notes: "NTA provides official mock tests accessible to registered candidates before the exam.",
  },
  {
    id: "pyq-gate",
    examId: "gate",
    examName: "GATE",
    paperType: "Previous Year Paper",
    availability: "Papers from 2007 onwards on the official GATE portal",
    officialUrl: "https://gate.iitk.ac.in",
    verified: true,
    notes: "The organising IIT publishes full question papers and answer keys for all past years.",
  },
  {
    id: "pyq-bitsat",
    examId: "bitsat",
    examName: "BITSAT",
    paperType: "Sample Paper",
    availability: "Official sample test on the BITS admission portal",
    officialUrl: "https://www.bitsadmission.com",
    verified: true,
    notes: "BITS provides a sample test that mirrors the BITSAT interface for registered candidates.",
  },
  {
    id: "pyq-nata",
    examId: "nata",
    examName: "NATA",
    paperType: "Previous Year Paper",
    availability: "Sample questions and previous year papers on the official NATA portal",
    officialUrl: "https://www.nata.in",
    verified: true,
    notes: "The Council of Architecture publishes sample questions and past papers on its portal.",
  },
  {
    id: "pyq-uceed",
    examId: "uceed",
    examName: "UCEED",
    paperType: "Previous Year Paper",
    availability: "Papers from 2015 onwards on the official UCEED portal",
    officialUrl: "https://uceed.iitb.ac.in",
    verified: true,
    notes: "IIT Bombay publishes previous year question papers and answer keys.",
  },
  {
    id: "pyq-ceed",
    examId: "ceed",
    examName: "CEED",
    paperType: "Previous Year Paper",
    availability: "Papers from past years on the official CEED portal",
    officialUrl: "https://ceed.iitb.ac.in",
    verified: true,
    notes: "IIT Bombay publishes previous year CEED papers and answer keys.",
  },
  {
    id: "pyq-nda",
    examId: "nda",
    examName: "NDA",
    paperType: "Previous Year Paper",
    availability: "Papers on the UPSC portal under Previous Year Question Papers",
    officialUrl: "https://upsc.gov.in/examinations/previous-question-papers",
    verified: true,
    notes: "UPSC publishes previous year NDA question papers in the 'Previous Year Question Papers' section of upsc.gov.in.",
  },
  {
    id: "pyq-cds",
    examId: "cds",
    examName: "CDS",
    paperType: "Previous Year Paper",
    availability: "Papers on the UPSC portal",
    officialUrl: "https://upsc.gov.in/examinations/previous-question-papers",
    verified: true,
    notes: "UPSC publishes CDS previous year papers alongside other UPSC examinations.",
  },
  {
    id: "pyq-ugc-net",
    examId: "ugc-net",
    examName: "UGC NET",
    paperType: "Previous Year Paper",
    availability: "Available on the NTA UGC NET portal",
    officialUrl: "https://ugcnet.nta.nic.in",
    verified: true,
    notes: "NTA publishes previous year UGC NET question papers and answer keys.",
  },
];

export function getPreviousPaperByExam(examId: string): PreviousPaperSource | undefined {
  return previousPaperSources.find((p) => p.examId === examId);
}
