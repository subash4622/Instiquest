/**
 * INSTIQUEST — Entrance Examinations Master Data
 * -------------------------------------------------------------
 * A curated catalogue of Indian and international entrance
 * examinations grouped by domain. Every value that is not
 * widely known and verified is replaced with the `REVIEW`
 * placeholder so it can be flagged for editorial review.
 *
 * NOTE on dates: per editorial policy, NO specific dates,
 * application windows or percentage thresholds are recorded
 * unless broadly well-established. Eligibility is kept
 * general and factual.
 */

export const REVIEW = "Unverified — pending review";

export type ExamCategory =
  | "Engineering"
  | "Medical"
  | "Management"
  | "Law"
  | "Design"
  | "Architecture"
  | "Science"
  | "Humanities"
  | "Maritime"
  | "Defence"
  | "Other";

export interface Exam {
  id: string;
  name: string;
  fullName: string;
  category: ExamCategory;
  conductingAuthority: string;
  course: string;
  level: "National" | "State" | "Institutional" | "International";
  eligibility: string;
  officialWebsite: string;
  applicationInfo: string;
  verified: boolean;
  featured?: boolean;
  description: string;
}

export const examCategories: ExamCategory[] = [
  "Engineering",
  "Medical",
  "Management",
  "Law",
  "Design",
  "Architecture",
  "Science",
  "Humanities",
  "Maritime",
  "Defence",
  "Other",
];

export const exams: Exam[] = [
  // ============================================================
  // ENGINEERING
  // ============================================================
  {
    id: "jee-main",
    name: "JEE Main",
    fullName: "Joint Entrance Examination (Main)",
    category: "Engineering",
    conductingAuthority: "National Testing Agency (NTA)",
    course: "B.E./B.Tech, B.Arch and B.Planning in NITs, IIITs, CFTIs and other participating institutes",
    level: "National",
    eligibility:
      "Class 12 / equivalent with Physics and Mathematics as compulsory subjects; Chemistry/Biotechnology/Biology/Technical Vocational as one optional. No specific minimum marks threshold required for appearing.",
    officialWebsite: "https://jeemain.nta.ac.in/",
    applicationInfo:
      "Online application via the NTA JEE(Main) portal; registration typically opens in two sessions per year (January and April cycles historically).",
    verified: true,
    featured: true,
    description:
      "The flagship undergraduate engineering entrance for admission to NITs, IIITs and CFTIs; also serves as the qualifier for JEE (Advanced).",
  },
  {
    id: "jee-advanced",
    name: "JEE Advanced",
    fullName: "Joint Entrance Examination (Advanced)",
    category: "Engineering",
    conductingAuthority:
      "One of the IITs (rotating) on behalf of the Joint Admission Board (JAB)",
    course: "B.Tech/B.S. programmes in the Indian Institutes of Technology (IITs)",
    level: "National",
    eligibility:
      "Top rank-holders of JEE (Main); additionally Class 12 / equivalent with Physics, Chemistry and Mathematics. Specific category-wise cut-off ranks applied.",
    officialWebsite: "https://jeeadv.ac.in/",
    applicationInfo:
      "Online registration through the official JEE (Advanced) portal of the conducting IIT; opens only after JEE (Main) results are declared.",
    verified: true,
    featured: true,
    description:
      "The gateway examination for admission to the B.Tech programmes of the IITs; open only to top JEE (Main) qualifiers.",
  },
  {
    id: "bitsat",
    name: "BITSAT",
    fullName: "Birla Institute of Technology and Science Admission Test",
    category: "Engineering",
    conductingAuthority: "BITS Pilani (Birla Institute of Technology & Science)",
    course: "Integrated First Degree programmes (B.E. Hons., B.Pharm Hons., M.Sc. Hons.) at BITS Pilani, Goa and Hyderabad campuses",
    level: "Institutional",
    eligibility:
      "Class 12 / equivalent with Physics, Chemistry and Mathematics (and English proficiency). Candidates should have adequate proficiency in English.",
    officialWebsite: "https://www.bitsadmission.com/",
    applicationInfo:
      "Online application via the BITS admission portal; typically conducted as a computer-based test in multiple sessions.",
    verified: true,
    description:
      "Computer-based online test for admission to integrated first-degree programmes at the BITS Pilani campuses.",
  },
  {
    id: "viteee",
    name: "VITEEE",
    fullName: "VIT Engineering Entrance Examination",
    category: "Engineering",
    conductingAuthority: "VIT University (Vellore Institute of Technology)",
    course: "B.Tech programmes at VIT Vellore, Chennai, Bhopal and AP campuses",
    level: "Institutional",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics (and English).",
    officialWebsite: "https://viteee.vit.ac.in/",
    applicationInfo:
      "Online application via the VITEEE portal; computer-based test held across multiple cities in India and select centres abroad.",
    verified: true,
    description:
      "Institute-level engineering entrance test for B.Tech admission at the VIT University campuses.",
  },
  {
    id: "srmjeee",
    name: "SRMJEEE",
    fullName: "SRM Joint Engineering Entrance Examination",
    category: "Engineering",
    conductingAuthority: "SRM Institute of Science and Technology (SRMIST)",
    course: "B.Tech programmes at SRMIST campuses (Kattankulathur, Ramapuram, Vadapalani, AP and Haryana)",
    level: "Institutional",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics.",
    officialWebsite: "https://srmist.edu.in/",
    applicationInfo:
      "Online application via the SRM admissions portal; computer-based test conducted in multiple phases.",
    verified: true,
    description:
      "Institute-level engineering entrance for B.Tech admission across SRM Institute campuses.",
  },
  {
    id: "comedk-uget",
    name: "COMEDK UGET",
    fullName: "Consortium of Medical, Engineering and Dental Colleges of Karnataka Under Graduate Entrance Test",
    category: "Engineering",
    conductingAuthority: "COMEDK (Consortium of Medical, Engineering and Dental Colleges of Karnataka)",
    course: "B.E./B.Tech (and B.Arch) seats in private member engineering colleges of Karnataka",
    level: "State",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics.",
    officialWebsite: "https://www.comedk.org/",
    applicationInfo:
      "Online application via the COMEDK portal; computer-based test conducted once a year for admission to private engineering colleges in Karnataka.",
    verified: true,
    description:
      "State-level entrance for admission to private engineering colleges in Karnataka that are part of the COMEDK consortium.",
  },
  {
    id: "met-manipal",
    name: "MET",
    fullName: "Manipal Entrance Test (MAHE MET)",
    category: "Engineering",
    conductingAuthority: "Manipal Academy of Higher Education (MAHE)",
    course: "B.Tech and other UG programmes across MAHE Manipal and sister campuses",
    level: "Institutional",
    eligibility: "Class 12 / equivalent with Physics, Mathematics and one of Chemistry/Biotechnology/Biology/Technical Vocational.",
    officialWebsite: "https://manipal.edu/mu/admission/entrance-test.html",
    applicationInfo:
      "Online application via the MAHE admissions portal; multiple-phase computer-based test.",
    verified: true,
    description:
      "Online entrance test conducted by MAHE for admission to its undergraduate programmes.",
  },
  {
    id: "wbjee",
    name: "WBJEE",
    fullName: "West Bengal Joint Entrance Examination",
    category: "Engineering",
    conductingAuthority: "West Bengal Joint Entrance Examinations Board (WBJEEB)",
    course: "B.E./B.Tech, B.Pharm and B.Arch in participating institutes of West Bengal",
    level: "State",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics.",
    officialWebsite: "https://wbjeeb.in/",
    applicationInfo:
      "Online application via the WBJEEB portal; OMR-based offline test conducted once a year.",
    verified: true,
    description:
      "State-level engineering (and pharmacy) entrance for admission to participating institutes in West Bengal.",
  },
  {
    id: "kcet",
    name: "KCET",
    fullName: "Karnataka Common Entrance Test",
    category: "Engineering",
    conductingAuthority: "Karnataka Examinations Authority (KEA)",
    course: "B.E./B.Tech, B.Pharm, B.Agriculture and other professional UG courses in Karnataka government and private colleges",
    level: "State",
    eligibility: "Class 12 / equivalent with relevant subjects (PCM for engineering).",
    officialWebsite: "https://cetonline.karnataka.gov.in/kea/",
    applicationInfo:
      "Online application via the KEA portal; offline OMR-based examination conducted once a year.",
    verified: true,
    description:
      "Karnataka state entrance for engineering, pharmacy, agriculture and other professional UG courses.",
  },
  {
    id: "mht-cet",
    name: "MHT CET",
    fullName: "Maharashtra Health and Technical Common Entrance Test",
    category: "Engineering",
    conductingAuthority: "State Common Entrance Test Cell, Government of Maharashtra",
    course: "B.E./B.Tech, B.Pharm and Agriculture/Horticulture courses in Maharashtra",
    level: "State",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics/Biology.",
    officialWebsite: "https://cetcell.mahacet.org/",
    applicationInfo:
      "Online application via the Maharashtra CET Cell portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "Maharashtra state-level entrance for engineering, pharmacy and agriculture UG programmes.",
  },
  {
    id: "gujcet",
    name: "GUJCET",
    fullName: "Gujarat Common Entrance Test",
    category: "Engineering",
    conductingAuthority: "Gujarat Secondary and Higher Secondary Education Board (GSEB)",
    course: "B.E./B.Tech and B.Pharm admission in participating institutes of Gujarat",
    level: "State",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics/Biology.",
    officialWebsite: "https://gseb.org/",
    applicationInfo:
      "Online application via the GSEB GUJCET portal; offline OMR-based test conducted once a year.",
    verified: true,
    description:
      "Gujarat state-level entrance for engineering and pharmacy UG admission.",
  },
  {
    id: "ap-eapcet",
    name: "AP EAPCET",
    fullName: "Andhra Pradesh Engineering, Agriculture and Pharmacy Common Entrance Test",
    category: "Engineering",
    conductingAuthority:
      "Andhra Pradesh State Council of Higher Education (APSCHE) — conducted by JNTU Kakinada",
    course: "B.E./B.Tech, B.Pharm and B.Sc Agriculture/Horticulture courses in Andhra Pradesh",
    level: "State",
    eligibility: "Class 12 / equivalent with relevant subjects (PCM for engineering).",
    officialWebsite: "https://cets.apsche.ap.gov.in/",
    applicationInfo:
      "Online application via the APSCHE EAPCET portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "Andhra Pradesh state entrance for engineering, agriculture and pharmacy UG courses.",
  },
  {
    id: "ts-eamcet",
    name: "TS EAMCET",
    fullName: "Telangana State Engineering, Agriculture and Medical Common Entrance Test",
    category: "Engineering",
    conductingAuthority:
      "Telangana State Council of Higher Education (TSCHE) — conducted by JNTU Hyderabad",
    course: "B.E./B.Tech, B.Pharm and Agriculture courses in Telangana",
    level: "State",
    eligibility: "Class 12 / equivalent with relevant subjects (PCM for engineering).",
    officialWebsite: "https://eamcet.tsche.ac.in/",
    applicationInfo:
      "Online application via the TSCHE EAMCET portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "Telangana state entrance for engineering, agriculture and pharmacy UG courses.",
  },
  {
    id: "gate",
    name: "GATE",
    fullName: "Graduate Aptitude Test in Engineering",
    category: "Engineering",
    conductingAuthority:
      "Indian Institute of Science (IISc) and the IITs on behalf of the National Coordination Board — GATE, MoE",
    course: "M.Tech/M.E./M.S.(Research) and direct Ph.D admission; also used by PSUs for recruitment",
    level: "National",
    eligibility:
      "Bachelor's degree in Engineering/Technology or Master's in relevant Science subject; final-year students may also appear.",
    officialWebsite: "https://gate.iitk.ac.in/",
    applicationInfo:
      "Online application via the official GATE portal of the conducting institute (rotates among IISc/IITs); computer-based test conducted once a year.",
    verified: true,
    featured: true,
    description:
      "National-level postgraduate engineering entrance jointly conducted by IISc and IITs; scores also used by several PSUs for recruitment.",
  },
  {
    id: "aeee-amrita",
    name: "AEEE",
    fullName: "Amrita Entrance Examination — Engineering",
    category: "Engineering",
    conductingAuthority: "Amrita Vishwa Vidyapeetham",
    course: "B.Tech programmes at Amrita School of Engineering campuses (Coimbatore, Bengaluru, Amritapuri, Chennai, Amaravati)",
    level: "Institutional",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics (and English).",
    officialWebsite: "https://www.amrita.edu/admissions/aeee",
    applicationInfo:
      "Online application via the Amrita admissions portal; computer-based test conducted in multiple phases.",
    verified: true,
    description:
      "Institute-level engineering entrance test for B.Tech admission at Amrita Vishwa Vidyapeetham.",
  },
  {
    id: "siteee",
    name: "SITEEE",
    fullName: "Symbiosis Institute of Technology Engineering Entrance Examination",
    category: "Engineering",
    conductingAuthority: "Symbiosis International (Deemed University)",
    course: "B.Tech programmes at Symbiosis Institute of Technology (SIT), Pune",
    level: "Institutional",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics.",
    officialWebsite: "https://www.set-test.org/",
    applicationInfo:
      "Online application via the Symbiosis SET portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "Symbiosis entrance test for B.Tech admission at the Symbiosis Institute of Technology, Pune.",
  },
  {
    id: "kiitee",
    name: "KIITEE",
    fullName: "Kalinga Institute of Industrial Technology Entrance Examination",
    category: "Engineering",
    conductingAuthority: "KIIT (Kalinga Institute of Industrial Technology) University",
    course: "B.Tech and other UG programmes across KIIT University schools",
    level: "Institutional",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics.",
    officialWebsite: "https://kiitee.kiit.ac.in/",
    applicationInfo:
      "Online application via the KIITEE portal; computer-based test conducted in multiple phases.",
    verified: true,
    description:
      "KIIT university entrance test for admission to B.Tech and several other UG programmes.",
  },
  {
    id: "lpu-nest",
    name: "LPU NEST",
    fullName: "Lovely Professional University National Entrance Scholarship Test",
    category: "Engineering",
    conductingAuthority: "Lovely Professional University (LPU)",
    course: "B.Tech and other UG programmes at LPU; also serves as a scholarship test",
    level: "Institutional",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics/Biology as relevant.",
    officialWebsite: "https://nest.lpu.in/",
    applicationInfo:
      "Online application via the LPU NEST portal; computer-based test conducted in multiple slots.",
    verified: true,
    description:
      "LPU national entrance and scholarship test for admission to B.Tech and other UG programmes.",
  },
  {
    id: "nest",
    name: "NEST",
    fullName: "National Entrance Screening Test",
    category: "Science",
    conductingAuthority:
      "National Institute of Science Education and Research (NISER) Bhubaneswar and UM-DAE Centre for Excellence in Basic Sciences, Mumbai — on behalf of Department of Atomic Energy",
    course: "5-year Integrated M.Sc programmes at NISER Bhubaneswar and UM-DAE CEBS, Mumbai",
    level: "National",
    eligibility:
      "Class 12 / equivalent with Physics, Chemistry, Mathematics and Biology as subjects.",
    officialWebsite: "https://www.nestexam.in/",
    applicationInfo:
      "Online application via the NEST portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "National entrance for the 5-year integrated M.Sc programmes at NISER Bhubaneswar and UM-DAE CEBS Mumbai.",
  },
  {
    id: "isi-admission-test",
    name: "ISI Admission Test",
    fullName: "Indian Statistical Institute Admission Test",
    category: "Science",
    conductingAuthority: "Indian Statistical Institute (ISI)",
    course: "B.Stat, B.Math, M.Stat, M.Math and other UG/PG programmes at ISI",
    level: "Institutional",
    eligibility: "Class 12 / equivalent with Mathematics for UG; relevant Bachelor's/Master's for PG.",
    officialWebsite: "https://www.isical.ac.in/~admission/",
    applicationInfo:
      "Online application via the ISI admissions portal; written test followed by interview for shortlisted candidates.",
    verified: true,
    description:
      "Institute entrance test for B.Stat, B.Math and various PG programmes of the Indian Statistical Institute.",
  },
  {
    id: "ipu-cet-b-tech",
    name: "IPU CET (B.Tech)",
    fullName: "Indraprastha University Common Entrance Test — B.Tech",
    category: "Engineering",
    conductingAuthority:
      "Guru Gobind Singh Indraprastha University (GGSIPU), Delhi",
    course: "B.Tech programmes in GGSIPU-affiliated institutes in Delhi NCR",
    level: "State",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics.",
    officialWebsite: "https://ipu.ac.in/",
    applicationInfo:
      "Online application via the IPU admissions portal; admission to most B.Tech programmes is now based on JEE (Main) scores, with CET used for select programmes.",
    verified: true,
    description:
      "Guru Gobind Singh Indraprastha University entrance test for select UG programmes; B.Tech admission primarily via JEE (Main).",
  },
  {
    id: "saat-engineering",
    name: "SAAT (B.Tech)",
    fullName: "Siksha 'O' Anusandhan Admission Test — Engineering",
    category: "Engineering",
    conductingAuthority: "Siksha 'O' Anusandhan (SOA) Deemed to be University, Bhubaneswar",
    course: "B.Tech programmes across SOA University institutes",
    level: "Institutional",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics.",
    officialWebsite: "https://soa.ac.in/saat",
    applicationInfo:
      "Online application via the SOA SAAT portal; computer-based test conducted in multiple phases.",
    verified: true,
    description:
      "SOA University entrance test for admission to B.Tech and other UG/PG programmes.",
  },
  {
    id: "amu-b-tech",
    name: "AMU B.Tech",
    fullName: "Aligarh Muslim University Engineering Entrance Examination",
    category: "Engineering",
    conductingAuthority: "Aligarh Muslim University (AMU)",
    course: "B.Tech programmes at the Zakir Husain College of Engineering & Technology, AMU",
    level: "Institutional",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics.",
    officialWebsite: "https://www.amucontrollerexams.com/",
    applicationInfo:
      "Online application via the AMU Controller of Examinations portal; written test conducted once a year.",
    verified: true,
    description:
      "AMU's institute-level entrance for admission to B.Tech programmes at Aligarh Muslim University.",
  },
  {
    id: "jmi-b-tech",
    name: "JMI B.Tech",
    fullName: "Jamia Millia Islamia Engineering Entrance Test",
    category: "Engineering",
    conductingAuthority: "Jamia Millia Islamia (JMI), New Delhi",
    course: "B.Tech programmes at the Faculty of Engineering & Technology, JMI",
    level: "Institutional",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics.",
    officialWebsite: "https://jmicoe.in/",
    applicationInfo:
      "Online application via the JMI Controller of Examinations portal; admission primarily via JEE (Main) score followed by counselling.",
    verified: true,
    description:
      "Jamia Millia Islamia's B.Tech admission is based on JEE (Main) scores through institute counselling.",
  },

  // ============================================================
  // MEDICAL
  // ============================================================
  {
    id: "neet-ug",
    name: "NEET UG",
    fullName: "National Eligibility cum Entrance Test (Undergraduate)",
    category: "Medical",
    conductingAuthority: "National Testing Agency (NTA)",
    course:
      "MBBS, BDS, BAMS, BHMS, BUMS and other medical/dental/AYUSH UG programmes across India",
    level: "National",
    eligibility:
      "Class 12 / equivalent with Physics, Chemistry, Biology/Biotechnology and English.",
    officialWebsite: "https://neet.nta.nic.in/",
    applicationInfo:
      "Online application via the NTA NEET portal; pen-and-paper (OMR) based test conducted once a year.",
    verified: true,
    featured: true,
    description:
      "The single national entrance for MBBS, BDS and AYUSH UG programmes in India, including AIIMS and JIPMER.",
  },
  {
    id: "neet-pg",
    name: "NEET PG",
    fullName: "National Eligibility cum Entrance Test (Postgraduate)",
    category: "Medical",
    conductingAuthority: "National Board of Examinations in Medical Sciences (NBEMS)",
    course: "MD, MS and Postgraduate Diploma seats in medical colleges across India",
    level: "National",
    eligibility: "MBBS degree (with completed/provisional internship as per prevailing norms).",
    officialWebsite: "https://nbe.edu.in/",
    applicationInfo:
      "Online application via the NBEMS portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "The single national entrance for MD, MS and PG Diploma admissions in medical colleges across India.",
  },
  {
    id: "aiims-mbbs-via-neet",
    name: "AIIMS MBBS (via NEET)",
    fullName: "AIIMS MBBS Admission (through NEET-UG)",
    category: "Medical",
    conductingAuthority: "All India Institute of Medical Sciences (AIIMS), New Delhi",
    course: "MBBS at AIIMS New Delhi and other AIIMS institutes across India",
    level: "National",
    eligibility:
      "Same as NEET-UG: Class 12 / equivalent with Physics, Chemistry, Biology/Biotechnology and English.",
    officialWebsite: "https://www.aiimsexams.ac.in/",
    applicationInfo:
      "No separate exam; admission through NEET-UG scores via the AIIMS institutional counselling.",
    verified: true,
    description:
      "AIIMS New Delhi admits MBBS students through NEET-UG scores; the earlier separate AIIMS MBBS entrance has been discontinued.",
  },
  {
    id: "jipmer-mbbs-via-neet",
    name: "JIPMER MBBS (via NEET)",
    fullName: "JIPMER MBBS Admission (through NEET-UG)",
    category: "Medical",
    conductingAuthority:
      "Jawaharlal Institute of Postgraduate Medical Education & Research (JIPMER), Puducherry",
    course: "MBBS at JIPMER Puducherry and Karaikal campuses",
    level: "National",
    eligibility:
      "Same as NEET-UG: Class 12 / equivalent with Physics, Chemistry, Biology/Biotechnology and English.",
    officialWebsite: "https://www.jipmer.edu.in/",
    applicationInfo:
      "No separate exam; admission through NEET-UG scores via JIPMER counselling.",
    verified: true,
    description:
      "JIPMER admits MBBS students through NEET-UG scores; the earlier separate JIPMER MBBS entrance has been discontinued.",
  },
  {
    id: "ini-cet",
    name: "INI CET",
    fullName: "Institute of National Importance Combined Entrance Test",
    category: "Medical",
    conductingAuthority: "All India Institute of Medical Sciences (AIIMS), New Delhi",
    course: "MD/MS/MDS/DM/M.Ch (6 yrs) at AIIMS, JIPMER, PGIMER, NIMHANS and SCTIMST",
    level: "National",
    eligibility: "MBBS/BDS degree (with internship as per prevailing norms) for MD/MS seats.",
    officialWebsite: "https://www.aiimsexams.ac.in/",
    applicationInfo:
      "Online application via the AIIMS INI-CET portal; computer-based test conducted twice a year (January and July sessions).",
    verified: true,
    description:
      "Combined PG medical entrance for admission to Institute of National Importance medical institutes (AIIMS, JIPMER, PGIMER, NIMHANS, SCTIMST).",
  },
  {
    id: "fmge",
    name: "FMGE",
    fullName: "Foreign Medical Graduates Examination",
    category: "Medical",
    conductingAuthority: "National Board of Examinations in Medical Sciences (NBEMS)",
    course: "Screening test for Indian citizens with foreign medical degrees to obtain MCI/NMC registration",
    level: "National",
    eligibility:
      "Indian citizen / Overseas Citizen of India with a primary medical degree from outside India, recognised by the concerned authority.",
    officialWebsite: "https://natboard.edu.in/",
    applicationInfo:
      "Online application via the NBEMS portal; computer-based test conducted twice a year.",
    verified: true,
    description:
      "Mandatory screening test for Indian citizens holding foreign medical qualifications to practise medicine in India.",
  },
  {
    id: "neet-ss",
    name: "NEET SS",
    fullName: "National Eligibility cum Entrance Test (Super Specialty)",
    category: "Medical",
    conductingAuthority: "National Board of Examinations in Medical Sciences (NBEMS)",
    course: "DM and M.Ch super-specialty courses in medical colleges across India",
    level: "National",
    eligibility: "Postgraduate medical degree (MD/MS/DNB) in the relevant feeder subject.",
    officialWebsite: "https://nbe.edu.in/",
    applicationInfo:
      "Online application via the NBEMS portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "The national super-specialty entrance for DM and M.Ch admission in medical colleges across India.",
  },
  {
    id: "aiapget",
    name: "AIAPGET",
    fullName: "All India AYUSH Post Graduate Entrance Test",
    category: "Medical",
    conductingAuthority: "National Board of Examinations in Medical Sciences (NBEMS)",
    course: "MD/MS in AYUSH systems (Ayurveda, Unani, Siddha and Homoeopathy)",
    level: "National",
    eligibility:
      "Relevant AYUSH UG degree (BAMS/BUMS/BHMS/BSMS) with internship as per prevailing norms.",
    officialWebsite: "https://natboard.edu.in/",
    applicationInfo:
      "Online application via the NBEMS portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "National entrance for AYUSH postgraduate (MD/MS) admission in Ayurveda, Unani, Siddha and Homoeopathy.",
  },
  {
    id: "afmc-mbbs-via-neet",
    name: "AFMC MBBS (via NEET)",
    fullName: "Armed Forces Medical College MBBS Admission (through NEET-UG)",
    category: "Medical",
    conductingAuthority: "Armed Forces Medical Services (AFMS), Ministry of Defence",
    course: "MBBS at Armed Forces Medical College (AFMC), Pune",
    level: "National",
    eligibility:
      "Same as NEET-UG plus additional AFMC-specific eligibility (marital status, physical and medical standards as per AFMS).",
    officialWebsite: "https://www.afmc.nic.in/",
    applicationInfo:
      "Admission through NEET-UG score followed by AFMC screening (ToELR, interview, medical exam).",
    verified: true,
    description:
      "AFMC Pune admits MBBS students through NEET-UG scores, followed by AFMS-specific screening including interview and medical examination.",
  },
  {
    id: "kcet-medical",
    name: "KCET Medical (legacy)",
    fullName: "Karnataka CET Medical (now via NEET-UG)",
    category: "Medical",
    conductingAuthority: "Karnataka Examinations Authority (KEA)",
    course: "Medical/dental seat allocation in Karnataka (now through NEET-UG)",
    level: "State",
    eligibility:
      "Same as NEET-UG: Class 12 / equivalent with Physics, Chemistry, Biology/Biotechnology and English.",
    officialWebsite: "https://cetonline.karnataka.gov.in/kea/",
    applicationInfo:
      "Medical/dental seat allocation in Karnataka is conducted via NEET-UG scores through KEA counselling; the separate KCET medical stream was discontinued after NEET became mandatory.",
    verified: true,
    description:
      "Karnataka medical/dental counselling is now based on NEET-UG scores through KEA; KCET itself continues for engineering and other streams.",
  },
  {
    id: "keam-medical",
    name: "KEAM Medical (via NEET)",
    fullName: "Kerala Engineering, Architecture and Medical — Medical stream",
    category: "Medical",
    conductingAuthority: "Commissioner for Entrance Examinations (CEE), Government of Kerala",
    course: "MBBS/BDS/AYUSH seat allocation in Kerala (through NEET-UG)",
    level: "State",
    eligibility:
      "Same as NEET-UG: Class 12 / equivalent with Physics, Chemistry, Biology/Biotechnology and English.",
    officialWebsite: "https://www.cee.kerala.gov.in/",
    applicationInfo:
      "Medical seat allocation in Kerala is based on NEET-UG scores via CEE counselling; KEAM itself is conducted for engineering/architecture streams.",
    verified: true,
    description:
      "Kerala medical/dental admission is conducted via NEET-UG scores through CEE; KEAM remains the entrance for engineering and architecture.",
  },
  {
    id: "cpnet",
    name: "CPNET",
    fullName: "Combined Paramedical, Nursing and Faculty Training Entrance Test",
    category: "Medical",
    conductingAuthority: "Uttar Pradesh State Medical Faculty (UPSMF)",
    course: "Paramedical, nursing and allied health UG/PG courses in Uttar Pradesh",
    level: "State",
    eligibility: "Class 12 / equivalent with relevant science subjects; course-specific requirements.",
    officialWebsite: "https://upsmfac.org/",
    applicationInfo:
      "Online application via the UPSMF portal; computer-based or OMR-based test as notified by the conducting body.",
    verified: true,
    description:
      "Uttar Pradesh state-level entrance for paramedical and nursing programmes under the State Medical Faculty.",
  },
  {
    id: "bvp-cet-medical",
    name: "BVP CET Medical",
    fullName: "Bharati Vidyapeeth Common Entrance Test — Medical",
    category: "Medical",
    conductingAuthority: "Bharati Vidyapeeth (Deemed to be University), Pune",
    course: "MBBS and other UG medical/paramedical programmes at Bharati Vidyapeeth campuses (medical admission now via NEET-UG)",
    level: "Institutional",
    eligibility:
      "Class 12 / equivalent with Physics, Chemistry, Biology/Biotechnology and English.",
    officialWebsite: "https://bvuniversity.edu.in/",
    applicationInfo:
      "MBBS admission is now through NEET-UG; BVP CET continues for select paramedical and allied programmes.",
    verified: true,
    description:
      "Bharati Vidyapeeth entrance test; MBBS admission is via NEET-UG while select paramedical courses continue to use BVP CET.",
  },
  {
    id: "manipal-met-medical",
    name: "MET — Allied Health",
    fullName: "Manipal Entrance Test — Medical & Allied Health",
    category: "Medical",
    conductingAuthority: "Manipal Academy of Higher Education (MAHE)",
    course:
      "Allied health, pharmacy, nursing and other non-MBBS UG medical programmes at MAHE",
    level: "Institutional",
    eligibility:
      "Class 12 / equivalent with Physics, Chemistry and Biology/related subjects.",
    officialWebsite: "https://manipal.edu/mu/admission/entrance-test.html",
    applicationInfo:
      "Online application via the MAHE admissions portal; MBBS admission is through NEET-UG; MET is used for allied health, pharmacy and other programmes.",
    verified: true,
    description:
      "Manipal entrance test for allied health, pharmacy and nursing UG programmes; MBBS admission is via NEET-UG.",
  },

  // ============================================================
  // MANAGEMENT
  // ============================================================
  {
    id: "cat",
    name: "CAT",
    fullName: "Common Admission Test",
    category: "Management",
    conductingAuthority: "Indian Institutes of Management (IIMs) — on a rotating basis",
    course: "Postgraduate management programmes (MBA/PGDM) at the IIMs and 1,200+ participating B-schools",
    level: "National",
    eligibility:
      "Bachelor's degree with at least 50% marks (45% for reserved categories) or equivalent CGPA; final-year students may also apply.",
    officialWebsite: "https://catiim.in/",
    applicationInfo:
      "Online application via the official CAT portal (hosted by the conducting IIM); computer-based test conducted once a year.",
    verified: true,
    featured: true,
    description:
      "The flagship management entrance for the IIMs and over a thousand participating B-schools in India.",
  },
  {
    id: "xat",
    name: "XAT",
    fullName: "Xavier Aptitude Test",
    category: "Management",
    conductingAuthority: "XLRI Jamshedpur (Xavier School of Management) on behalf of XAMI",
    course: "MBA/PGDM at XLRI and 160+ XAMI-associated and other participating B-schools",
    level: "National",
    eligibility:
      "Bachelor's degree in any discipline; final-year students may also apply.",
    officialWebsite: "https://xatonline.in/",
    applicationInfo:
      "Online application via the XAT online portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "National-level management entrance conducted by XLRI for admission to XLRI and 160+ participating institutes.",
  },
  {
    id: "mat",
    name: "MAT",
    fullName: "Management Aptitude Test",
    category: "Management",
    conductingAuthority: "All India Management Association (AIMA)",
    course: "MBA/PGDM at 600+ AICTE-approved participating B-schools",
    level: "National",
    eligibility: "Bachelor's degree in any discipline; final-year students may also apply.",
    officialWebsite: "https://mat.aima.in/",
    applicationInfo:
      "Online application via the AIMA MAT portal; conducted multiple times a year in PBT, CBT and IBT modes.",
    verified: true,
    description:
      "AIMA's standardised management aptitude test accepted by 600+ B-schools; conducted multiple times a year in flexible modes.",
  },
  {
    id: "cmat",
    name: "CMAT",
    fullName: "Common Management Admission Test",
    category: "Management",
    conductingAuthority: "National Testing Agency (NTA)",
    course: "MBA/PGDM at AICTE-approved participating institutions across India",
    level: "National",
    eligibility: "Bachelor's degree in any discipline; final-year students may also apply.",
    officialWebsite: "https://cmat.nta.nic.in/",
    applicationInfo:
      "Online application via the NTA CMAT portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "NTA-conducted national entrance for AICTE-approved MBA/PGDM programmes across India.",
  },
  {
    id: "gmat",
    name: "GMAT",
    fullName: "Graduate Management Admission Test",
    category: "Management",
    conductingAuthority: "Graduate Management Admission Council (GMAC)",
    course: "MBA/PGDM and other management programmes globally (including Indian B-schools accepting GMAT)",
    level: "International",
    eligibility: "Bachelor's degree in any discipline; work experience preferred at many schools.",
    officialWebsite: "https://www.mba.com/",
    applicationInfo:
      "Online application via mba.com; computer-adaptive test available year-round at designated test centres and online.",
    verified: true,
    description:
      "Internationally recognised computer-adaptive management admission test used by business schools worldwide.",
  },
  {
    id: "nmat",
    name: "NMAT by GMAC",
    fullName: "NMAT by GMAC",
    category: "Management",
    conductingAuthority: "Graduate Management Admission Council (GMAC)",
    course: "MBA/PGDM at NMIMS and 40+ participating B-schools in India and abroad",
    level: "National",
    eligibility: "Bachelor's degree in any discipline; final-year students may also apply.",
    officialWebsite: "https://www.nmat.org/",
    applicationInfo:
      "Online application via the NMAT portal; computer-based test conducted over a window with retake option (subject to policy).",
    verified: true,
    description:
      "GMAC-administered management entrance accepted by NMIMS and several Indian and global B-schools.",
  },
  {
    id: "snap",
    name: "SNAP",
    fullName: "Symbiosis National Aptitude Test",
    category: "Management",
    conductingAuthority: "Symbiosis International (Deemed University)",
    course: "MBA/PGDM at the 16 Symbiosis institutes under Symbiosis International University",
    level: "Institutional",
    eligibility: "Bachelor's degree with at least 50% marks (45% for SC/ST); final-year students may apply.",
    officialWebsite: "https://snaptest.org/",
    applicationInfo:
      "Online application via the SNAP portal; computer-based test conducted in multiple sessions with the best score considered.",
    verified: true,
    description:
      "Symbiosis national aptitude test for MBA/PGDM admission across the 16 Symbiosis institutes in India.",
  },
  {
    id: "iift-mba",
    name: "IIFT MBA",
    fullName: "IIFT MBA (IB) Admission",
    category: "Management",
    conductingAuthority: "Indian Institute of Foreign Trade (IIFT), Ministry of Commerce",
    course: "MBA in International Business (MBA-IB) at IIFT Delhi/Kolkata/Kakinada",
    level: "National",
    eligibility:
      "Bachelor's degree with at least 50% marks (45% for reserved); final-year students may apply.",
    officialWebsite: "https://www.iift.ac.in/",
    applicationInfo:
      "Admission to MBA (IB) at IIFT is now based on CAT score, followed by written ability, group discussion and interview; the earlier separate IIFT entrance exam has been discontinued.",
    verified: true,
    description:
      "IIFT MBA (International Business) admission is now through CAT scores; the standalone IIFT entrance test has been discontinued.",
  },
  {
    id: "tissnet-mba",
    name: "TISSNET (legacy)",
    fullName: "TISS National Entrance Test — MA Programmes",
    category: "Management",
    conductingAuthority: "Tata Institute of Social Sciences (TISS)",
    course: "MA programmes across TISS campuses (including MA HRM&LR and other social sciences)",
    level: "Institutional",
    eligibility: "Bachelor's degree in any discipline; final-year students may apply.",
    officialWebsite: "https://admissions.tiss.edu/",
    applicationInfo:
      "The standalone TISSNET has been discontinued; admission to MA programmes including HRM is now through CUET (PG) followed by TISS-specific assessment.",
    verified: true,
    description:
      "TISS's standalone entrance test has been discontinued; admission to its MA programmes is now via CUET (PG) scores.",
  },
  {
    id: "ibsat",
    name: "IBSAT",
    fullName: "ICFAI Business School Aptitude Test",
    category: "Management",
    conductingAuthority: "ICFAI Foundation for Higher Education (ICFAI Business School — IBS)",
    course: "MBA/PGPM at the nine IBS campuses (Hyderabad, Mumbai, Bengaluru, etc.)",
    level: "Institutional",
    eligibility: "Bachelor's degree in any discipline with adequate English proficiency; final-year students may apply.",
    officialWebsite: "https://www.ibsindia.org/",
    applicationInfo:
      "Online application via the IBS admissions portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "ICFAI Business School's institute-level entrance for MBA/PGPM admission across its nine IBS campuses.",
  },
  {
    id: "atma",
    name: "ATMA",
    fullName: "AIMS Test for Management Admissions",
    category: "Management",
    conductingAuthority: "Association of Indian Management Schools (AIMS)",
    course: "MBA/PGDM at 200+ AIMS member institutions",
    level: "National",
    eligibility: "Bachelor's degree in any discipline; final-year students may apply.",
    officialWebsite: "https://atmaaims.in/",
    applicationInfo:
      "Online application via the ATMA portal; computer-based test conducted multiple times a year.",
    verified: true,
    description:
      "AIMS-conducted national management entrance accepted by 200+ AIMS member B-schools.",
  },
  {
    id: "micat",
    name: "MICAT",
    fullName: "MICA Admission Test",
    category: "Management",
    conductingAuthority: "Mudra Institute of Communications, Ahmedabad (MICA)",
    course: "PGDM (Communications) at MICA, Ahmedabad",
    level: "Institutional",
    eligibility: "Bachelor's degree in any discipline (with adequate English proficiency).",
    officialWebsite: "https://www.mica.ac.in/",
    applicationInfo:
      "Online application via the MICA admissions portal; MICAT is conducted in two phases; selection also considers CAT/XAT/GMAT scores.",
    verified: true,
    description:
      "MICA's institute-level admission test for the PGDM (Communications) programme, combined with CAT/XAT/GMAT scores.",
  },
  {
    id: "mh-cet-mba",
    name: "MAH CET MBA",
    fullName: "Maharashtra MBA Common Entrance Test",
    category: "Management",
    conductingAuthority: "State Common Entrance Test Cell, Government of Maharashtra",
    course: "MBA/MMS in participating management institutes of Maharashtra (JBIMS, SIMSREE, PUMBA and others)",
    level: "State",
    eligibility: "Bachelor's degree with at least 50% marks (45% for reserved); final-year students may apply.",
    officialWebsite: "https://cetcell.mahacet.org/",
    applicationInfo:
      "Online application via the Maharashtra CET Cell portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "Maharashtra state-level entrance for MBA/MMS admission to participating management institutes including JBIMS and SIMSREE.",
  },
  {
    id: "ipu-cet-mba",
    name: "IPU CET (MBA)",
    fullName: "Indraprastha University Common Entrance Test — MBA",
    category: "Management",
    conductingAuthority: "Guru Gobind Singh Indraprastha University (GGSIPU), Delhi",
    course: "MBA at University School of Management Studies and affiliated institutes of GGSIPU",
    level: "State",
    eligibility: "Bachelor's degree with required marks as per university norms.",
    officialWebsite: "https://ipu.ac.in/",
    applicationInfo:
      "Online application via the IPU admissions portal; admission to MBA programmes also accepts CAT scores for USMS.",
    verified: true,
    description:
      "Guru Gobind Singh Indraprastha University entrance for MBA admission to its University School of Management Studies and affiliated institutes.",
  },
  {
    id: "kmat",
    name: "KMAT",
    fullName: "Karnataka Management Aptitude Test",
    category: "Management",
    conductingAuthority: "Karnataka Private Post Graduate Colleges Association (KPPGCA)",
    course: "MBA/PGDM in over 169 member B-schools across Karnataka",
    level: "State",
    eligibility: "Bachelor's degree with at least 50% marks (45% for reserved); final-year students may apply.",
    officialWebsite: "https://kmatindia.com/",
    applicationInfo:
      "Online application via the KMAT India portal; computer-based (or home-proctored) test conducted once a year.",
    verified: true,
    description:
      "Karnataka state-level management entrance conducted by the KPPGCA for member B-schools.",
  },
  {
    id: "nmims-npat",
    name: "NPAT",
    fullName: "NMIMS Programs After Twelfth",
    category: "Management",
    conductingAuthority: "Narsee Monjee Institute of Management Studies (NMIMS Deemed to be University)",
    course: "BBA, B.Com (Hons), B.Sc Economics and other UG programmes across NMIMS campuses",
    level: "Institutional",
    eligibility: "Class 12 / equivalent with relevant subjects and minimum percentage per programme.",
    officialWebsite: "https://nmims.npat.in/",
    applicationInfo:
      "Online application via the NPAT portal; computer-based test conducted in multiple phases.",
    verified: true,
    description:
      "NMIMS entrance for admission to undergraduate programmes (BBA, B.Com, B.Sc Economics, etc.) across NMIMS campuses.",
  },

  // ============================================================
  // LAW
  // ============================================================
  {
    id: "clat",
    name: "CLAT",
    fullName: "Common Law Admission Test",
    category: "Law",
    conductingAuthority: "Consortium of National Law Universities (NLUs)",
    course:
      "5-year integrated LL.B (BA LL.B, BBA LL.B, B.Com LL.B, B.Sc LL.B, BSW LL.B) at the 24 NLUs; also CLAT-PG for LL.M",
    level: "National",
    eligibility:
      "For UG: Class 12 / equivalent with at least 45% marks (40% for SC/ST/PwD). For PG: LL.B degree with the required percentage.",
    officialWebsite: "https://consortiumofnlus.ac.in/",
    applicationInfo:
      "Online application via the Consortium of NLUs portal; offline (pen-and-paper) test conducted once a year.",
    verified: true,
    featured: true,
    description:
      "The national law entrance for admission to the 24 National Law Universities in India for both UG (integrated LL.B) and PG (LL.M) programmes.",
  },
  {
    id: "ailet",
    name: "AILET",
    fullName: "All India Law Entrance Test",
    category: "Law",
    conductingAuthority: "National Law University, Delhi (NLU Delhi)",
    course: "B.A. LL.B (Hons), LL.M and Ph.D at NLU Delhi",
    level: "Institutional",
    eligibility:
      "For UG: Class 12 / equivalent with at least 45% marks (40% for SC/ST/PwD). For PG: LL.B degree with the required percentage.",
    officialWebsite: "https://nludelhi.ac.in/",
    applicationInfo:
      "Online application via the NLU Delhi admissions portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "NLU Delhi's institute-level entrance for its B.A. LL.B (Hons), LL.M and Ph.D programmes.",
  },
  {
    id: "lsat-india",
    name: "LSAT India",
    fullName: "Law School Admission Test — India",
    category: "Law",
    conductingAuthority: "Law School Admission Council (LSAC) — administered in India by Pearson VUE",
    course: "5-year integrated LL.B, 3-year LL.B and LL.M at 80+ associated Indian law schools",
    level: "National",
    eligibility: "Class 12 / equivalent for UG; Bachelor's degree (with LL.B for LL.M).",
    officialWebsite: "https://www.lsatindia.in/",
    applicationInfo:
      "Online application via the LSAT India portal; computer-based test conducted in multiple sessions per year.",
    verified: true,
    description:
      "LSAC's India-specific law admission test accepted by 80+ associated law schools across India.",
  },
  {
    id: "mh-cet-law",
    name: "MH CET Law",
    fullName: "Maharashtra Common Entrance Test — Law",
    category: "Law",
    conductingAuthority: "State Common Entrance Test Cell, Government of Maharashtra",
    course: "3-year LL.B and 5-year integrated LL.B in participating law colleges of Maharashtra",
    level: "State",
    eligibility:
      "For 3-year LL.B: Bachelor's degree in any discipline with at least 45% (40% for reserved). For 5-year: Class 12 / equivalent with at least 45% (40% for reserved).",
    officialWebsite: "https://cetcell.mahacet.org/",
    applicationInfo:
      "Online application via the Maharashtra CET Cell portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "Maharashtra state-level entrance for both 3-year and 5-year LL.B programmes in participating law colleges.",
  },
  {
    id: "ap-lawcet",
    name: "AP LAWCET",
    fullName: "Andhra Pradesh Law Common Entrance Test",
    category: "Law",
    conductingAuthority:
      "Sri Krishnadevaraya University, Tirupati on behalf of APSCHE",
    course: "3-year LL.B and 5-year integrated LL.B in participating law colleges of Andhra Pradesh",
    level: "State",
    eligibility:
      "For 3-year LL.B: Bachelor's degree with required marks. For 5-year: Class 12 / equivalent with required marks.",
    officialWebsite: "https://cets.apsche.ap.gov.in/",
    applicationInfo:
      "Online application via the APSCHE LAWCET portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "Andhra Pradesh state-level entrance for 3-year and 5-year LL.B programmes in participating law colleges.",
  },
  {
    id: "ts-lawcet",
    name: "TS LAWCET",
    fullName: "Telangana State Law Common Entrance Test",
    category: "Law",
    conductingAuthority: "Kakatiya University, Warangal on behalf of TSCHE",
    course: "3-year LL.B and 5-year integrated LL.B in participating law colleges of Telangana",
    level: "State",
    eligibility:
      "For 3-year LL.B: Bachelor's degree with required marks. For 5-year: Class 12 / equivalent with required marks.",
    officialWebsite: "https://lawcet.tsche.ac.in/",
    applicationInfo:
      "Online application via the TSCHE LAWCET portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "Telangana state-level entrance for 3-year and 5-year LL.B programmes in participating law colleges.",
  },
  {
    id: "klee",
    name: "KLEE",
    fullName: "Kerala Law Entrance Examination",
    category: "Law",
    conductingAuthority: "Commissioner for Entrance Examinations (CEE), Government of Kerala",
    course: "3-year LL.B, 5-year integrated LL.B and LL.M in participating Kerala law colleges",
    level: "State",
    eligibility:
      "For UG: Class 12 / equivalent (5-year) or Bachelor's (3-year) with required marks. For LL.M: LL.B degree.",
    officialWebsite: "https://www.cee.kerala.gov.in/",
    applicationInfo:
      "Online application via the CEE Kerala portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "Kerala state-level law entrance for 3-year LL.B, 5-year integrated LL.B and LL.M in participating law colleges.",
  },
  {
    id: "du-llb",
    name: "DU LL.B (via CUET-PG)",
    fullName: "Delhi University LL.B Admission (through CUET-PG)",
    category: "Law",
    conductingAuthority: "Faculty of Law, University of Delhi",
    course: "3-year LL.B and LL.M at the Campus Law Centre, Law Centre-I and Law Centre-II, DU",
    level: "Institutional",
    eligibility: "Graduation in any discipline with the required marks as per university norms.",
    officialWebsite: "https://lawfaculty.du.ac.in/",
    applicationInfo:
      "Admission to DU LL.B and LL.M is now based on CUET (PG) scores via Delhi University counselling; the earlier separate DU LL.B entrance has been discontinued.",
    verified: true,
    description:
      "Delhi University LL.B admission is now through CUET (PG) scores; the standalone DU LL.B entrance test has been discontinued.",
  },
  {
    id: "slat",
    name: "SLAT",
    fullName: "Symbiosis Law Admission Test",
    category: "Law",
    conductingAuthority: "Symbiosis International (Deemed University)",
    course: "B.A. LL.B and B.B.A. LL.B at Symbiosis Law School (Pune & Noida)",
    level: "Institutional",
    eligibility: "Class 12 / equivalent with at least 45% marks (40% for SC/ST).",
    officialWebsite: "https://www.set-test.org/",
    applicationInfo:
      "Online application via the Symbiosis SET portal; computer-based test followed by PI-WAT for shortlisted candidates.",
    verified: true,
    description:
      "Symbiosis entrance test for the 5-year integrated LL.B programmes at Symbiosis Law School (Pune and Noida).",
  },
  {
    id: "aibe",
    name: "AIBE",
    fullName: "All India Bar Examination",
    category: "Law",
    conductingAuthority: "Bar Council of India (BCI)",
    course: "Certification exam to practise law in India (Certificate of Practice)",
    level: "National",
    eligibility: "LL.B degree from a BCI-recognised institution; enrolled as an advocate with a State Bar Council.",
    officialWebsite: "https://www.allindiabarexamination.com/",
    applicationInfo:
      "Online application via the AIBE portal; open-book examination conducted periodically.",
    verified: true,
    description:
      "Mandatory certification exam by the Bar Council of India required for advocates to practise in Indian courts.",
  },
  {
    id: "pu-llb",
    name: "PU LL.B Entrance",
    fullName: "Panjab University LL.B Entrance Test",
    category: "Law",
    conductingAuthority: "Panjab University, Chandigarh",
    course: "3-year LL.B and 5-year integrated B.A./B.Com LL.B at PU and affiliated institutes",
    level: "Institutional",
    eligibility:
      "For 3-year: Bachelor's degree with required marks. For 5-year: Class 12 / equivalent with required marks.",
    officialWebsite: "https://puchd.ac.in/",
    applicationInfo:
      "Online application via the Panjab University admission portal; offline/computer-based test conducted once a year.",
    verified: true,
    description:
      "Panjab University entrance for admission to its 3-year LL.B and 5-year integrated LL.B programmes.",
  },
  {
    id: "bhu-llb-via-cuet",
    name: "BHU LL.B (via CUET-PG)",
    fullName: "Banaras Hindu University LL.B Admission (through CUET-PG)",
    category: "Law",
    conductingAuthority: "Banaras Hindu University (BHU)",
    course: "3-year LL.B at the Faculty of Law, BHU",
    level: "Institutional",
    eligibility: "Graduation in any discipline with the required marks as per university norms.",
    officialWebsite: "https://www.bhu.ac.in/",
    applicationInfo:
      "Admission to BHU LL.B is now based on CUET (PG) scores through BHU counselling; the earlier separate BHU LL.B entrance has been discontinued.",
    verified: true,
    description:
      "Banaras Hindu University LL.B admission is now through CUET (PG) scores via BHU counselling.",
  },

  // ============================================================
  // DESIGN
  // ============================================================
  {
    id: "uceed",
    name: "UCEED",
    fullName: "Undergraduate Common Entrance Examination for Design",
    category: "Design",
    conductingAuthority: "IIT Bombay (Industrial Design Centre) on behalf of MoE",
    course: "B.Des at IIT Bombay, IIT Delhi, IIT Guwahati, IIT Hyderabad, IIITDM Jabalpur and other participating institutes",
    level: "National",
    eligibility:
      "Class 12 / equivalent in any stream; specific age and attempt limits as per prevailing norms.",
    officialWebsite: "https://www.uceed.iitb.ac.in/",
    applicationInfo:
      "Online application via the UCEED portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "National-level UG design entrance for B.Des admission to IIT Bombay, IIT Delhi, IIT Guwahati, IIT Hyderabad and other participating institutes.",
  },
  {
    id: "ceed",
    name: "CEED",
    fullName: "Common Entrance Examination for Design",
    category: "Design",
    conductingAuthority: "IIT Bombay (Industrial Design Centre) on behalf of MoE",
    course: "M.Des at IIT Bombay, IIT Delhi, IIT Guwahati, IIT Hyderabad, IIT Kanpur, IISc Bangalore and other participating institutes",
    level: "National",
    eligibility: "Bachelor's degree / diploma in design, engineering, architecture or equivalent; specific degree streams per institute.",
    officialWebsite: "https://www.ceed.iitb.ac.in/",
    applicationInfo:
      "Online application via the CEED portal; two-part test (Part A computer-based, Part B offline/drawing) conducted once a year.",
    verified: true,
    description:
      "National-level PG design entrance for M.Des admission to the IITs, IISc and other participating institutes.",
  },
  {
    id: "nid-dat",
    name: "NID DAT",
    fullName: "National Institute of Design Design Aptitude Test",
    category: "Design",
    conductingAuthority: "National Institute of Design (NID)",
    course: "B.Des (GDPD) at NID Ahmedabad and M.Des across NID campuses",
    level: "Institutional",
    eligibility: "For UG: Class 12 / equivalent. For PG: Bachelor's degree in any discipline as per programme-specific norms.",
    officialWebsite: "https://admissions.nid.edu/",
    applicationInfo:
      "Online application via the NID admissions portal; two-stage test (DAT Prelims, DAT Mains) conducted once a year.",
    verified: true,
    description:
      "NID's institute-level design aptitude test for B.Des and M.Des programmes across NID Ahmedabad and other campuses.",
  },
  {
    id: "nift-entrance",
    name: "NIFT Entrance",
    fullName: "NIFT Entrance Examination",
    category: "Design",
    conductingAuthority: "National Institute of Fashion Technology (NIFT)",
    course: "B.Des, B.FTech, M.Des, M.FTech and M.FM at NIFT campuses across India",
    level: "Institutional",
    eligibility:
      "For UG: Class 12 / equivalent. For PG: relevant Bachelor's degree as per programme norms.",
    officialWebsite: "https://www.nift.ac.in/",
    applicationInfo:
      "Online application via the NIFT admissions portal; written test (CBT) followed by Situation Test / Group Discussion / Personal Interview as per programme.",
    verified: true,
    description:
      "NIFT entrance for admission to its B.Des, B.FTech and PG design, fashion technology and fashion management programmes.",
  },
  {
    id: "pearl-academy",
    name: "Pearl Academy Entrance",
    fullName: "Pearl Academy Entrance Examination",
    category: "Design",
    conductingAuthority: "Pearl Academy (Pearl Academy of Fashion)",
    course: "UG and PG design, fashion, media and business programmes at Pearl Academy campuses",
    level: "Institutional",
    eligibility: "Class 12 / equivalent for UG; Bachelor's for PG; portfolio/interview as per programme.",
    officialWebsite: "https://pearlacademy.com/",
    applicationInfo:
      "Online application via the Pearl Academy admissions portal; written test (Pearl Academy Entrance Exam) followed by Personal Interview.",
    verified: true,
    description:
      "Pearl Academy's entrance test for admission to its UG and PG programmes in design, fashion, media and creative business.",
  },
  {
    id: "seed-srishti",
    name: "SEED",
    fullName: "Srishti Entrance Examination for Design",
    category: "Design",
    conductingAuthority: "Srishti Manipal Institute of Art, Design and Technology (a constituent unit of MAHE)",
    course: "B.Des (and related UG design programmes) at Srishti, Bengaluru",
    level: "Institutional",
    eligibility: "Class 12 / equivalent in any stream.",
    officialWebsite: "https://srishtimanipalinst.edu.in/",
    applicationInfo:
      "Online application via the Srishti admissions portal; SEED test followed by portfolio review and interview.",
    verified: true,
    description:
      "Srishti Manipal Institute's entrance test (SEED) for admission to its undergraduate design programmes.",
  },
  {
    id: "aieed",
    name: "AIEED",
    fullName: "All India Entrance Examination for Design",
    category: "Design",
    conductingAuthority: "ARCH College of Design & Business, Jaipur",
    course: "UG and PG design programmes at ARCH College and select associated institutes",
    level: "Institutional",
    eligibility: "Class 12 / equivalent for UG; Bachelor's degree for PG (relevant background preferred).",
    officialWebsite: "https://www.aieed.com/",
    applicationInfo:
      "Online application via the AIEED portal; online test conducted in multiple stages with interview/portfolio review.",
    verified: true,
    description:
      "ARCH College of Design's entrance test for admission to its UG and PG design programmes.",
  },

  // ============================================================
  // ARCHITECTURE
  // ============================================================
  {
    id: "jee-main-paper-2",
    name: "JEE Main Paper 2",
    fullName: "JEE (Main) — Paper 2 (B.Arch / B.Planning)",
    category: "Architecture",
    conductingAuthority: "National Testing Agency (NTA)",
    course: "B.Arch and B.Planning in NITs, IIITs, CFTIs and other participating institutes",
    level: "National",
    eligibility: "Class 12 / equivalent with Physics, Chemistry and Mathematics.",
    officialWebsite: "https://jeemain.nta.ac.in/",
    applicationInfo:
      "Online application via the NTA JEE (Main) portal; Paper 2 (B.Arch/B.Planning) conducted as part of the JEE (Main) cycle.",
    verified: true,
    description:
      "JEE (Main) Paper 2 for admission to B.Arch and B.Planning programmes at participating government and private institutes.",
  },
  {
    id: "nata",
    name: "NATA",
    fullName: "National Aptitude Test in Architecture",
    category: "Architecture",
    conductingAuthority: "Council of Architecture (CoA)",
    course: "B.Arch in any CoA-recognised institute in India",
    level: "National",
    eligibility: "Class 12 / equivalent with Mathematics as a subject; meet CoA norms.",
    officialWebsite: "https://www.nata.in/",
    applicationInfo:
      "Online application via the CoA NATA portal; computer-based aptitude test conducted in multiple phases per year.",
    verified: true,
    description:
      "Council of Architecture's national aptitude test for admission to the 5-year B.Arch programme in CoA-recognised institutes.",
  },
  {
    id: "jee-advanced-aat",
    name: "JEE Advanced AAT",
    fullName: "Architecture Aptitude Test (AAT) — JEE (Advanced)",
    category: "Architecture",
    conductingAuthority: "One of the IITs (rotating) on behalf of the Joint Admission Board (JAB)",
    course: "B.Arch at IIT Kharagpur and IIT Roorkee",
    level: "National",
    eligibility:
      "Must have qualified JEE (Advanced) and be among the rank-holders as notified for the AAT cycle.",
    officialWebsite: "https://jeeadv.ac.in/",
    applicationInfo:
      "Online registration via the JEE (Advanced) portal; AAT conducted for shortlisted candidates who have qualified JEE (Advanced).",
    verified: true,
    description:
      "Architecture Aptitude Test for B.Arch admission at IIT Kharagpur and IIT Roorkee; only JEE (Advanced) qualifiers may appear.",
  },
  {
    id: "gate-architecture",
    name: "GATE (Architecture)",
    fullName: "GATE — Architecture and Planning (AR)",
    category: "Architecture",
    conductingAuthority:
      "Indian Institute of Science (IISc) and the IITs on behalf of the National Coordination Board — GATE, MoE",
    course: "M.Plan, M.Arch and M.Urban Planning at IITs, NITs, SPAs and other institutes",
    level: "National",
    eligibility: "Bachelor's degree in Architecture/Planning or equivalent; final-year students may appear.",
    officialWebsite: "https://gate.iitk.ac.in/",
    applicationInfo:
      "Online application via the official GATE portal of the conducting institute; computer-based test conducted once a year.",
    verified: true,
    description:
      "GATE paper for Architecture and Planning (AR); used for M.Arch/M.Plan admission at IITs, NITs, SPAs and other institutes.",
  },
  {
    id: "cept-entrance",
    name: "CEPT Entrance",
    fullName: "CEPT University Entrance Test",
    category: "Architecture",
    conductingAuthority: "CEPT University, Ahmedabad",
    course: "B.Arch, B.Plan, B.Des (Interior) and PG programmes at CEPT University",
    level: "Institutional",
    eligibility: "Class 12 / equivalent with Mathematics for B.Arch; relevant degree for PG.",
    officialWebsite: "https://cept.ac.in/",
    applicationInfo:
      "Online application via the CEPT admissions portal; admission to B.Arch at CEPT is also based on NATA / JEE (Main) Paper 2 scores as per university norms.",
    verified: true,
    description:
      "CEPT University's entrance test for admission to its architecture, planning, design and other UG/PG programmes.",
  },
  {
    id: "dasa-architecture",
    name: "DASA (Architecture)",
    fullName: "Direct Admission of Students Abroad — Architecture",
    category: "Architecture",
    conductingAuthority: "Ministry of Education, Government of India — administered by a coordinating NIT",
    course: "B.Arch / B.Planning in NITs, IIITs and other centrally funded institutes for foreign/NRI/PIO/OCI students",
    level: "International",
    eligibility:
      "Foreign nationals / Persons of Indian Origin / Overseas Citizens of India / NRI students with relevant Class 12 / equivalent qualification and valid SAT / JEE (Main) score as per scheme.",
    officialWebsite: "https://dasanit.org/",
    applicationInfo:
      "Online application via the DASA portal; admission based on SAT Subject / JEE (Main) scores as per prevailing scheme.",
    verified: true,
    description:
      "MoE scheme for direct admission of foreign/NRI/PIO/OCI students to UG architecture and engineering programmes in centrally funded institutes.",
  },

  // ============================================================
  // SCIENCE
  // ============================================================
  {
    id: "iit-jam",
    name: "IIT JAM",
    fullName: "Joint Admission Test for M.Sc",
    category: "Science",
    conductingAuthority:
      "Indian Institute of Science (IISc) and the IITs on behalf of MoE (rotating conducting IIT)",
    course: "M.Sc, M.Sc-Ph.D dual degree and other post-B.Sc programmes at IITs and IISc",
    level: "National",
    eligibility: "Bachelor's degree with relevant science subjects; specific minimum CGPA / subject prerequisites per programme.",
    officialWebsite: "https://jam.iitm.ac.in/",
    applicationInfo:
      "Online application via the official IIT JAM portal of the conducting institute; computer-based test conducted once a year.",
    verified: true,
    description:
      "National-level M.Sc entrance for admission to IITs and IISc; covers chemistry, physics, mathematics, biotechnology and other science papers.",
  },
  {
    id: "csir-net",
    name: "CSIR NET",
    fullName: "Council of Scientific and Industrial Research — National Eligibility Test (Joint CSIR-UGC NET)",
    category: "Science",
    conductingAuthority: "National Testing Agency (NTA) on behalf of CSIR",
    course: "Junior Research Fellowship (JRF) and Lectureship/Assistant Professorship in science subjects",
    level: "National",
    eligibility:
      "M.Sc or equivalent in relevant science subject (or final-year students); age limits apply for JRF.",
    officialWebsite: "https://csirnet.nta.ac.in/",
    applicationInfo:
      "Online application via the NTA CSIR NET portal; computer-based test conducted twice or thrice a year.",
    verified: true,
    description:
      "Joint CSIR-UGC NET for Junior Research Fellowship and eligibility for lectureship in science subjects at Indian universities.",
  },
  {
    id: "gate-xl",
    name: "GATE (Life Sciences — XL)",
    fullName: "GATE — Life Sciences (XL) paper",
    category: "Science",
    conductingAuthority:
      "Indian Institute of Science (IISc) and the IITs on behalf of the National Coordination Board — GATE, MoE",
    course: "M.Tech / M.S. / direct Ph.D in life sciences and allied interdisciplinary programmes",
    level: "National",
    eligibility: "Bachelor's or Master's in relevant Life Sciences / allied subjects; final-year students may appear.",
    officialWebsite: "https://gate.iitk.ac.in/",
    applicationInfo:
      "Online application via the official GATE portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "GATE Life Sciences (XL) paper used for postgraduate engineering/research admissions in life-sciences-related disciplines.",
  },
  {
    id: "kvpy",
    name: "KVPY (legacy)",
    fullName: "Kishore Vaigyanik Protsahan Yojana",
    category: "Science",
    conductingAuthority:
      "Indian Institute of Science (IISc) on behalf of the Department of Science & Technology (DST)",
    course: "Fellowship for B.Sc / B.S. / integrated M.Sc / M.S. students in basic sciences",
    level: "National",
    eligibility:
      "Class 11 / 12 / 1st-year UG students in basic sciences meeting stipulated academic criteria (historically).",
    officialWebsite: "https://kvpy.iisc.ernet.in/",
    applicationInfo:
      "The standalone KVPY aptitude test has been discontinued and subsumed into the INSPIRE scheme; existing KVPY fellows continue to be supported under DST norms.",
    verified: true,
    description:
      "KVPY — the DST fellowship scheme for science students; the standalone aptitude test is discontinued and merged with INSPIRE.",
  },
  {
    id: "ntse",
    name: "NTSE (legacy)",
    fullName: "National Talent Search Examination",
    category: "Science",
    conductingAuthority: "National Council of Educational Research and Training (NCERT)",
    course: "Scholarship for Class 10 students through to PhD level (historical scheme)",
    level: "National",
    eligibility: "Class 10 students of recognised schools (historical).",
    officialWebsite: "https://ncert.nic.in/",
    applicationInfo:
      "The standalone NTSE has been discontinued by NCERT; the scheme has been subsumed under the National Scheme for ATP / PM-YAS as per the latest notification.",
    verified: true,
    description:
      "NCERT's National Talent Search Examination — historically a two-stage scholarship exam for Class 10 students; now discontinued.",
  },
  {
    id: "inspire-she",
    name: "INSPIRE SHE",
    fullName: "Innovation in Science Pursuit for Inspired Research — Scholarship for Higher Education",
    category: "Science",
    conductingAuthority: "Department of Science & Technology (DST), Government of India",
    course: "Scholarship for B.Sc / integrated M.Sc students in natural and basic sciences",
    level: "National",
    eligibility:
      "Top 1% performers in Class 12 board exams (or JEE Main / NEET / JEE Advanced rank-holders) pursuing UG in basic sciences.",
    officialWebsite: "https://online-inspire.gov.in/",
    applicationInfo:
      "Online application via the INSPIRE Online portal; selection based on Class 12 board performance or specified national exam ranks.",
    verified: true,
    description:
      "DST's INSPIRE-SHE scholarship for students pursuing B.Sc/integrated M.Sc in natural and basic sciences at recognised institutes.",
  },
  {
    id: "nbhm",
    name: "NBHM",
    fullName: "National Board for Higher Mathematics — Scholarship Test",
    category: "Science",
    conductingAuthority: "National Board for Higher Mathematics (NBHM), Department of Atomic Energy",
    course: "Master's / Ph.D scholarships and admission support in mathematics",
    level: "National",
    eligibility:
      "Students pursuing or planning to pursue M.Sc / integrated Ph.D in mathematics; specific eligibility per scheme.",
    officialWebsite: "https://www.nbhm.dae.gov.in/",
    applicationInfo:
      "Online application via the NBHM portal; written test conducted once a year, followed by interview for shortlisted candidates.",
    verified: true,
    description:
      "NBHM scholarship test for Master's and Ph.D level mathematics scholarships and admission support at recognised institutes.",
  },
  {
    id: "iiser-aptitude-test",
    name: "IISER Aptitude Test",
    fullName: "IISER Aptitude Test (IAT)",
    category: "Science",
    conductingAuthority: "Indian Institutes of Science Education and Research (IISERs)",
    course: "5-year BS-MS dual degree at the seven IISERs (also for admission to IIT Madras BS Medical Sciences & Engineering as per prevailing rules)",
    level: "National",
    eligibility: "Class 12 / equivalent with science stream; specific channel requirements (KVPY / SCB / JEE Advanced) historically apply.",
    officialWebsite: "https://iiseradmission.in/",
    applicationInfo:
      "Online application via the IISER admissions portal; computer-based aptitude test conducted once a year.",
    verified: true,
    description:
      "IISER aptitude test for admission to the 5-year BS-MS dual degree programme across the seven IISERs.",
  },

  // ============================================================
  // HUMANITIES
  // ============================================================
  {
    id: "cuet-ug",
    name: "CUET (UG)",
    fullName: "Common University Entrance Test (Undergraduate)",
    category: "Humanities",
    conductingAuthority: "National Testing Agency (NTA)",
    course: "UG admission (BA, B.Com, B.Sc, BBA, etc.) at 250+ central, state, deemed and private universities",
    level: "National",
    eligibility: "Class 12 / equivalent from a recognised board; subject requirements as per chosen UG programme.",
    officialWebsite: "https://exams.nta.ac.in/CUET-UG/",
    applicationInfo:
      "Online application via the NTA CUET (UG) portal; computer-based test conducted in multiple phases.",
    verified: true,
    featured: true,
    description:
      "Single national entrance for undergraduate admission to central, state, deemed and private universities including DU, JNU, BHU and others.",
  },
  {
    id: "cuet-pg",
    name: "CUET (PG)",
    fullName: "Common University Entrance Test (Postgraduate)",
    category: "Humanities",
    conductingAuthority: "National Testing Agency (NTA)",
    course: "PG admission (MA, M.Com, M.Sc, MBA, LL.B, etc.) at central, state, deemed and private universities",
    level: "National",
    eligibility: "Bachelor's degree (or appearing in final year) from a recognised university.",
    officialWebsite: "https://exams.nta.ac.in/CUET-PG/",
    applicationInfo:
      "Online application via the NTA CUET (PG) portal; computer-based test conducted once a year (multi-slot).",
    verified: true,
    description:
      "Single national entrance for postgraduate admission to central, state, deemed and private universities including JNU, BHU, DU and TISS.",
  },
  {
    id: "jnuee",
    name: "JNUEE (via CUET)",
    fullName: "Jawaharlal Nehru University Entrance Examination (through CUET)",
    category: "Humanities",
    conductingAuthority: "Jawaharlal Nehru University (JNU), New Delhi",
    course: "UG and PG programmes (BA Hons, MA, M.Sc, etc.) at JNU",
    level: "Institutional",
    eligibility: "Class 12 / equivalent for UG; Bachelor's for PG, as per programme norms.",
    officialWebsite: "https://www.jnu.ac.in/",
    applicationInfo:
      "Admission to JNU UG and PG programmes is now via CUET (UG) and CUET (PG) respectively; the earlier standalone JNUEE is discontinued.",
    verified: true,
    description:
      "JNU admission to its UG and PG programmes is now through CUET scores via JNU counselling.",
  },
  {
    id: "duet",
    name: "DUET (via CUET)",
    fullName: "Delhi University Entrance Test (through CUET)",
    category: "Humanities",
    conductingAuthority: "University of Delhi",
    course: "UG and PG admission across Delhi University colleges and departments",
    level: "Institutional",
    eligibility: "Class 12 / equivalent for UG; Bachelor's for PG, as per programme norms.",
    officialWebsite: "https://www.du.ac.in/",
    applicationInfo:
      "Admission to Delhi University UG and PG programmes is now via CUET (UG) and CUET (PG) respectively; the earlier standalone DUET is discontinued.",
    verified: true,
    description:
      "Delhi University admission is now through CUET scores for both UG and PG programmes via DU counselling.",
  },
  {
    id: "bhu-uet",
    name: "BHU UET (via CUET)",
    fullName: "Banaras Hindu University Undergraduate Entrance Test (through CUET)",
    category: "Humanities",
    conductingAuthority: "Banaras Hindu University (BHU), Varanasi",
    course: "UG admission (BA, B.Com, B.Sc, Shastri, etc.) at BHU",
    level: "Institutional",
    eligibility: "Class 12 / equivalent as per programme-specific norms.",
    officialWebsite: "https://www.bhu.ac.in/",
    applicationInfo:
      "Admission to BHU UG programmes is now via CUET (UG) scores through BHU counselling; the earlier standalone UET is discontinued.",
    verified: true,
    description:
      "Banaras Hindu University UG admission is now through CUET (UG) scores via BHU counselling.",
  },
  {
    id: "amu-entrance-humanities",
    name: "AMU Entrance (Humanities)",
    fullName: "Aligarh Muslim University Entrance Test — BA / Humanities",
    category: "Humanities",
    conductingAuthority: "Aligarh Muslim University (AMU)",
    course: "BA, BA LL.B, B.Com, B.Sc and other UG programmes at AMU",
    level: "Institutional",
    eligibility: "Class 12 / equivalent as per programme-specific norms.",
    officialWebsite: "https://www.amucontrollerexams.com/",
    applicationInfo:
      "Online application via the AMU Controller of Examinations portal; written test (CBT/OMR) conducted once a year for most UG programmes.",
    verified: true,
    description:
      "AMU's institute-level entrance for UG programmes in humanities, commerce, science and law streams.",
  },
  {
    id: "jmi-entrance",
    name: "JMI Entrance",
    fullName: "Jamia Millia Islamia Entrance Test",
    category: "Humanities",
    conductingAuthority: "Jamia Millia Islamia (JMI), New Delhi",
    course: "UG and PG programmes across JMI faculties (some UG admissions now via CUET)",
    level: "Institutional",
    eligibility: "Class 12 / equivalent for UG; Bachelor's for PG, as per programme norms.",
    officialWebsite: "https://jmicoe.in/",
    applicationInfo:
      "Online application via the JMI Controller of Examinations portal; admission to select UG programmes is via CUET, while most PG programmes continue to use JMI's own entrance test.",
    verified: true,
    description:
      "Jamia Millia Islamia entrance test for UG and PG programmes; select UG programmes also admit via CUET (UG).",
  },

  // ============================================================
  // MARITIME
  // ============================================================
  {
    id: "imu-cet",
    name: "IMU CET",
    fullName: "Indian Maritime University Common Entrance Test",
    category: "Maritime",
    conductingAuthority: "Indian Maritime University (IMU), Chennai",
    course: "B.Tech (Marine Engineering), B.Sc (Nautical Science), BBA (Maritime) and other UG maritime programmes at IMU and affiliated campuses",
    level: "National",
    eligibility:
      "Class 12 / equivalent with Physics, Chemistry and Mathematics (and English); medical/eyesight standards as per DGS norms.",
    officialWebsite: "https://www.imu.edu.in/",
    applicationInfo:
      "Online application via the IMU admissions portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "National-level entrance for admission to UG maritime programmes at Indian Maritime University and its affiliated campuses.",
  },
  {
    id: "tmisat",
    name: "TMISAT",
    fullName: "Tolani Maritime Institute Science Aptitude Test",
    category: "Maritime",
    conductingAuthority: "Tolani Maritime Institute (TMI), Pune",
    course: "B.Tech (Marine Engineering) and B.Sc (Nautical Science) at TMI",
    level: "Institutional",
    eligibility:
      "Class 12 / equivalent with Physics, Chemistry and Mathematics (and English); IMU-CET score also accepted; medical/eyesight standards apply.",
    officialWebsite: "https://www.tolani.edu/",
    applicationInfo:
      "Online application via the TMI admissions portal; online aptitude test followed by interview and medical examination.",
    verified: true,
    description:
      "Tolani Maritime Institute's aptitude test for admission to its B.Tech (Marine Engineering) and B.Sc (Nautical Science) programmes.",
  },
  {
    id: "meri-entrance",
    name: "MERI Entrance",
    fullName: "Maritime Education and Research Institute Entrance (via IMU CET)",
    category: "Maritime",
    conductingAuthority:
      "Marine Engineering & Research Institute (MERI) — administered through IMU CET",
    course: "B.Tech (Marine Engineering) at MERI Kolkata / Mumbai campuses",
    level: "Institutional",
    eligibility:
      "Class 12 / equivalent with Physics, Chemistry and Mathematics (and English); medical/eyesight standards per DGS norms.",
    officialWebsite: "https://www.imu.edu.in/",
    applicationInfo:
      "Admission to MERI campuses is now through the IMU CET counselling process; the standalone MERI entrance exam is discontinued.",
    verified: true,
    description:
      "MERI's B.Tech (Marine Engineering) admission is now through IMU CET counselling; the standalone MERI entrance has been discontinued.",
  },
  {
    id: "samet-entrance",
    name: "SAMET Entrance",
    fullName: REVIEW,
    category: "Maritime",
    conductingAuthority: REVIEW,
    course: REVIEW,
    level: "Institutional",
    eligibility: REVIEW,
    officialWebsite: REVIEW,
    applicationInfo: REVIEW,
    verified: false,
    description:
      "A maritime-sector entrance test referenced in older admission catalogues; the conducting body, course and current status require editorial verification.",
  },
  {
    id: "himt-entrance",
    name: "HIMT Entrance",
    fullName: "HIMT College of Maritime Studies Entrance / Screening",
    category: "Maritime",
    conductingAuthority: "HIMT College of Maritime Studies, Chennai",
    course: "B.Sc Nautical Science, B.Tech Marine Engineering and DGS-approved maritime pre-sea courses at HIMT",
    level: "Institutional",
    eligibility:
      "Class 12 / equivalent with Physics, Chemistry and Mathematics (and English); medical/eyesight standards per DGS norms.",
    officialWebsite: "https://himtcollege.com/",
    applicationInfo:
      "Online application via the HIMT admissions portal; admission primarily via IMU CET scores for degree programmes, supplemented by institute screening for DGS-approved courses.",
    verified: true,
    description:
      "HIMT College of Maritime Studies conducts institute-level screening for its degree and pre-sea maritime programmes.",
  },

  // ============================================================
  // DEFENCE
  // ============================================================
  {
    id: "nda",
    name: "NDA",
    fullName: "National Defence Academy Examination",
    category: "Defence",
    conductingAuthority: "Union Public Service Commission (UPSC)",
    course: "Admission to the Army, Navy and Air Force wings of the National Defence Academy and Naval Academy (10+2 Cadet Entry)",
    level: "National",
    eligibility:
      "Class 12 / equivalent (with Physics and Mathematics for Air Force / Naval wings and 10+2 Cadet Entry); age, marital status and physical standards per UPSC norms.",
    officialWebsite: "https://www.upsc.gov.in/",
    applicationInfo:
      "Online application via the UPSC portal; written exam conducted twice a year, followed by SSB interview.",
    verified: true,
    featured: true,
    description:
      "UPSC-conducted entrance for admission to the National Defence Academy and Naval Academy (10+2 Cadet Entry); followed by a 5-day SSB interview.",
  },
  {
    id: "cds",
    name: "CDS",
    fullName: "Combined Defence Services Examination",
    category: "Defence",
    conductingAuthority: "Union Public Service Commission (UPSC)",
    course: "Admission to Indian Military Academy (IMA), Indian Naval Academy (INA), Air Force Academy (AFA) and Officers' Training Academy (OTA)",
    level: "National",
    eligibility:
      "Bachelor's degree (Engineering for INA / AFA); specific degree and age criteria per academy; physical standards as notified.",
    officialWebsite: "https://www.upsc.gov.in/",
    applicationInfo:
      "Online application via the UPSC portal; written exam conducted twice a year, followed by SSB interview.",
    verified: true,
    description:
      "UPSC-conducted entrance for graduate entry into IMA, INA, AFA and OTA; followed by SSB interview and medicals.",
  },
  {
    id: "afcat",
    name: "AFCAT",
    fullName: "Air Force Common Admission Test",
    category: "Defence",
    conductingAuthority: "Indian Air Force (IAF)",
    course: "Short Service Commission (Flying / Ground Duty Technical / Ground Duty Non-Technical) branches",
    level: "National",
    eligibility:
      "Graduation (specific degree/branch requirements for Technical and Non-Technical branches); age and physical standards per IAF norms.",
    officialWebsite: "https://afcat.cdac.in/",
    applicationInfo:
      "Online application via the AFCAT portal; computer-based test conducted twice a year, followed by AFSB interview and medicals.",
    verified: true,
    description:
      "Indian Air Force common admission test for Short Service Commission in Flying and Ground Duty branches.",
  },
  {
    id: "tes",
    name: "TES",
    fullName: "Technical Entry Scheme",
    category: "Defence",
    conductingAuthority: "Indian Army (Directorate General of Recruiting)",
    course: "Permanent Commission in the Army after 10+2 (Technical) — B.Tech cadet entry",
    level: "National",
    eligibility:
      "Class 12 / equivalent with Physics, Chemistry and Mathematics with minimum aggregate as notified; age and physical standards per Army norms.",
    officialWebsite: "https://joinindianarmy.nic.in/",
    applicationInfo:
      "Online application via the Join Indian Army portal; shortlisting based on Class 12 marks followed by SSB interview and medicals.",
    verified: true,
    description:
      "Indian Army's 10+2 Technical Entry Scheme for Permanent Commission in engineering cadres; selection via SSB interview after Class 12 marks shortlisting.",
  },
  {
    id: "inet",
    name: "INET",
    fullName: "Indian Navy Entrance Test",
    category: "Defence",
    conductingAuthority: "Indian Navy",
    course: "Officer entry branches of the Indian Navy (Executive, Educational, Technical)",
    level: "National",
    eligibility:
      "Graduation (specific degree/branch requirements for Technical and Executive branches); age and physical standards per Navy norms.",
    officialWebsite: "https://www.joinindiannavy.gov.in/",
    applicationInfo:
      "Online application via the Join Indian Navy portal; computer-based test followed by SSB interview and medicals.",
    verified: true,
    description:
      "Indian Navy's officer-entry entrance test for Executive, Educational and Technical branches; followed by SSB interview.",
  },
  {
    id: "acc",
    name: "ACC",
    fullName: "Army Cadet College Entrance",
    category: "Defence",
    conductingAuthority: "Indian Army (Directorate General of Recruiting)",
    course: "Commission in the Indian Army for serving soldiers (ACC wing feeds IMA)",
    level: "National",
    eligibility:
      "Serving soldiers of the Indian Army meeting age, service and educational criteria as per Army norms.",
    officialWebsite: "https://joinindianarmy.nic.in/",
    applicationInfo:
      "Online application via the Join Indian Army portal; written test followed by SSB interview and medicals.",
    verified: true,
    description:
      "Army Cadet College entrance for serving soldiers to earn a Regular Commission through the Indian Military Academy.",
  },
  {
    id: "ssc-tech",
    name: "SSC Tech",
    fullName: "Short Service Commission (Technical) Entry",
    category: "Defence",
    conductingAuthority: "Indian Army (Directorate General of Recruiting)",
    course: "Short Service Commission in technical branches of the Indian Army (also a parallel entry for women)",
    level: "National",
    eligibility:
      "Engineering degree in notified streams; age and physical standards per Army norms.",
    officialWebsite: "https://joinindianarmy.nic.in/",
    applicationInfo:
      "Online application via the Join Indian Army portal; shortlisting based on engineering percentage followed by SSB interview and medicals.",
    verified: true,
    description:
      "Indian Army's Short Service Commission (Technical) entry for engineering graduates; selection via SSB interview after percentage-based shortlisting.",
  },

  // ============================================================
  // OTHER
  // ============================================================
  {
    id: "neet-mds",
    name: "NEET MDS",
    fullName: "National Eligibility cum Entrance Test for Masters of Dental Surgery",
    category: "Other",
    conductingAuthority: "National Board of Examinations in Medical Sciences (NBEMS)",
    course: "MDS in dental colleges across India",
    level: "National",
    eligibility: "BDS degree (with completed/provisional internship as per prevailing norms).",
    officialWebsite: "https://nbe.edu.in/",
    applicationInfo:
      "Online application via the NBEMS portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "The single national entrance for MDS admission in dental colleges across India; conducted by NBEMS.",
  },
  {
    id: "gpat",
    name: "GPAT",
    fullName: "Graduate Pharmacy Aptitude Test",
    category: "Other",
    conductingAuthority: "National Testing Agency (NTA)",
    course: "M.Pharm in AICTE-approved institutions across India",
    level: "National",
    eligibility: "Bachelor's degree in Pharmacy (B.Pharm); final-year B.Pharm students may also apply.",
    officialWebsite: "https://gpat.nta.nic.in/",
    applicationInfo:
      "Online application via the NTA GPAT portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "National-level entrance for M.Pharm admission in AICTE-approved pharmacy colleges across India.",
  },
  {
    id: "ugc-net",
    name: "UGC NET",
    fullName: "University Grants Commission National Eligibility Test (UGC-NET)",
    category: "Other",
    conductingAuthority: "National Testing Agency (NTA) on behalf of University Grants Commission",
    course: "Junior Research Fellowship (JRF) and Assistant Professor eligibility in Indian universities and colleges",
    level: "National",
    eligibility:
      "Master's degree (or equivalent) in the relevant subject with required marks; age limits apply for JRF.",
    officialWebsite: "https://ugcnet.nta.nic.in/",
    applicationInfo:
      "Online application via the NTA UGC NET portal; computer-based test conducted twice or thrice a year.",
    verified: true,
    description:
      "UGC-NET for determining eligibility for Junior Research Fellowship and Assistant Professorship in Indian universities.",
  },
  {
    id: "icar-aieea",
    name: "ICAR AIEEA",
    fullName: "Indian Council of Agricultural Research All India Entrance Examination for Admission",
    category: "Other",
    conductingAuthority:
      "National Testing Agency (NTA) on behalf of Indian Council of Agricultural Research (ICAR)",
    course: "UG and PG admission in agriculture and allied sciences at ICAR-deemed universities and SAUs (PG admission now via CUET-ICAR)",
    level: "National",
    eligibility:
      "Class 12 / equivalent with relevant subjects for UG; Bachelor's in agriculture/allied sciences for PG.",
    officialWebsite: "https://icar.nta.ac.in/",
    applicationInfo:
      "Online application via the NTA ICAR portal; computer-based test (PG admission now also through CUET-ICAR stream).",
    verified: true,
    description:
      "ICAR's national entrance for admission to agriculture and allied-science UG/PG programmes across ICAR institutes and State Agricultural Universities.",
  },
  {
    id: "aipmst",
    name: "AIPMST",
    fullName: "All India Pre-Medical Scholarship Test",
    category: "Other",
    conductingAuthority: "AIPMST (All India Pre-Medical Scholarship Test) Trust",
    course: "Scholarship for students pursuing medical, dental, pharmacy and allied health courses",
    level: "National",
    eligibility:
      "Class 12 / equivalent with Physics, Chemistry and Biology as per the scholarship norms.",
    officialWebsite: "https://aipmst.co.in/",
    applicationInfo:
      "Online application via the AIPMST portal; scholarship test conducted online in multiple phases.",
    verified: true,
    description:
      "A national-level scholarship test for students pursuing UG medical, dental, pharmacy and allied health programmes.",
  },
  {
    id: "pessat",
    name: "PESSAT",
    fullName: "PES Scholastic Aptitude Test",
    category: "Other",
    conductingAuthority: "PES University, Bengaluru",
    course: "B.Tech, BBA, BBA-LL.B, B.Des, MBA and other UG/PG programmes at PES University",
    level: "Institutional",
    eligibility:
      "Class 12 / equivalent for UG; Bachelor's for PG; specific subject requirements per programme.",
    officialWebsite: "https://www.pessat.com/",
    applicationInfo:
      "Online application via the PESSAT portal; computer-based test conducted in multiple phases.",
    verified: true,
    description:
      "PES University's scholastic aptitude test for admission to its UG and PG programmes across campuses.",
  },
  {
    id: "saat",
    name: "SAAT",
    fullName: "Siksha 'O' Anusandhan Admission Test",
    category: "Other",
    conductingAuthority: "Siksha 'O' Anusandhan (SOA) Deemed to be University, Bhubaneswar",
    course: "UG and PG programmes (engineering, medical, management, law, pharmacy, nursing, hospitality, etc.) across SOA institutes",
    level: "Institutional",
    eligibility: "Class 12 / equivalent for UG; Bachelor's for PG; medical admission primarily via NEET-UG.",
    officialWebsite: "https://soa.ac.in/saat",
    applicationInfo:
      "Online application via the SOA SAAT portal; computer-based test conducted in multiple phases.",
    verified: true,
    description:
      "SOA University's entrance test for admission to its UG and PG programmes across engineering, management, law, pharmacy, hospitality and other streams.",
  },
  {
    id: "eamcet-agriculture",
    name: "EAMCET Agriculture",
    fullName: "TS/AP EAMCET — Agriculture Stream",
    category: "Other",
    conductingAuthority:
      "TSCHE / APSCHE — conducted by JNTU Hyderabad (TS) and JNTU Kakinada (AP)",
    course: "B.Sc (Agriculture / Horticulture), B.V.Sc, B.F.Sc and other allied agriculture UG courses in Telangana and Andhra Pradesh",
    level: "State",
    eligibility: "Class 12 / equivalent with relevant science subjects (PCB / Agriculture stream).",
    officialWebsite: "https://eamcet.tsche.ac.in/",
    applicationInfo:
      "Online application via the TSCHE / APSCHE EAMCET portals; computer-based test conducted once a year.",
    verified: true,
    description:
      "Agriculture stream of TS/AP EAMCET for admission to UG agriculture, horticulture and allied courses in Telangana and Andhra Pradesh.",
  },
  {
    id: "aima-ugat",
    name: "AIMA UGAT",
    fullName: "Under Graduate Aptitude Test (AIMA UGAT)",
    category: "Other",
    conductingAuthority: "All India Management Association (AIMA)",
    course: "BBA, BHM, B.Com, BCA and other UG management / hospitality / IT programmes at participating institutes",
    level: "National",
    eligibility: "Class 12 / equivalent from a recognised board.",
    officialWebsite: "https://apps.aima.in/ugat2024/",
    applicationInfo:
      "Online application via the AIMA UGAT portal; computer-based / paper-based test conducted once a year.",
    verified: true,
    description:
      "AIMA's national aptitude test for admission to UG management, hospitality and IT programmes at participating institutes.",
  },
  {
    id: "nchmct-jee",
    name: "NCHMCT JEE",
    fullName: "National Council for Hotel Management and Catering Technology Joint Entrance Examination",
    category: "Other",
    conductingAuthority: "National Testing Agency (NTA) on behalf of NCHMCT",
    course: "B.Sc in Hospitality & Hotel Administration at affiliated institutes of NCHMCT",
    level: "National",
    eligibility: "Class 12 / equivalent with English as a subject; age as per NCHMCT norms.",
    officialWebsite: "https://exams.nta.ac.in/NCHM/",
    applicationInfo:
      "Online application via the NTA NCHM JEE portal; computer-based test conducted once a year.",
    verified: true,
    description:
      "NTA-conducted national entrance for B.Sc (Hospitality & Hotel Administration) at NCHMCT-affiliated institutes.",
  },
  {
    id: "dasa",
    name: "DASA",
    fullName: "Direct Admission of Students Abroad",
    category: "Other",
    conductingAuthority: "Ministry of Education, Government of India — administered by a coordinating NIT",
    course: "UG engineering / architecture / management / other UG programmes at NITs, IIITs, SPAs, CFTIs for foreign / NRI / PIO / OCI students",
    level: "International",
    eligibility:
      "Foreign nationals / Persons of Indian Origin / Overseas Citizens of India / NRI students with relevant Class 12 / equivalent qualification and valid SAT Subject / JEE (Main) score per prevailing scheme.",
    officialWebsite: "https://dasanit.org/",
    applicationInfo:
      "Online application via the DASA portal; admission based on SAT Subject / JEE (Main) scores as per the prevailing scheme.",
    verified: true,
    description:
      "MoE scheme for direct admission of foreign / NRI / PIO / OCI students to UG programmes in centrally funded technical institutes.",
  },
  {
    id: "ignou-openmat",
    name: "IGNOU OPENMAT (legacy)",
    fullName: "IGNOU Open Management Admission Test",
    category: "Other",
    conductingAuthority: "Indira Gandhi National Open University (IGNOU)",
    course: "MBA and other management programmes at IGNOU",
    level: "Institutional",
    eligibility: "Bachelor's degree with required years of managerial/supervisory experience as per IGNOU norms.",
    officialWebsite: "https://ignou.ac.in/",
    applicationInfo:
      "The standalone OPENMAT test has been discontinued; admission to IGNOU MBA is now based on merit / specified entrance scores as per university notification.",
    verified: true,
    description:
      "IGNOU's standalone management aptitude test (OPENMAT) — discontinued; MBA admission is now on the basis of merit / specified scores per IGNOU norms.",
  },
  {
    id: "icmai-cma-foundation",
    name: "CMA Foundation",
    fullName: "Institute of Cost Accountants of India — CMA Foundation Course",
    category: "Other",
    conductingAuthority: "Institute of Cost Accountants of India (ICMAI)",
    course: "CMA Foundation course (entry-level for the Cost & Management Accountancy qualification)",
    level: "National",
    eligibility: "Class 10 / Class 12 / equivalent as per ICMAI foundation registration norms.",
    officialWebsite: "https://icmai.in/",
    applicationInfo:
      "Online registration via the ICMAI portal; foundation examination conducted thrice a year (computer-based).",
    verified: true,
    description:
      "Entry-level foundation course examination for the Cost & Management Accountancy qualification by ICMAI.",
  },
  {
    id: "icai-ca-foundation",
    name: "CA Foundation",
    fullName: "Institute of Chartered Accountants of India — CA Foundation Course",
    category: "Other",
    conductingAuthority: "Institute of Chartered Accountants of India (ICAI)",
    course: "CA Foundation course (entry-level for the Chartered Accountancy qualification)",
    level: "National",
    eligibility: "Class 10 for registration; Class 12 / equivalent (or equivalent) for appearing in the foundation exam.",
    officialWebsite: "https://www.icai.org/",
    applicationInfo:
      "Online registration via the ICAI SSP portal; foundation examination conducted twice or thrice a year.",
    verified: true,
    description:
      "Entry-level foundation course examination for the Chartered Accountancy qualification by ICAI.",
  },
];

// ============================================================
// HELPERS
// ============================================================

/** Return all exams whose category matches the given category. */
export function getExamsByCategory(category: ExamCategory): Exam[] {
  return exams.filter((exam) => exam.category === category);
}

/** Return the flagship / featured exams marked for prominent display. */
export function getFeaturedExams(): Exam[] {
  return exams.filter((exam) => exam.featured === true);
}

/** Look up a single exam by its kebab-case id. */
export function getExamById(id: string): Exam | undefined {
  return exams.find((exam) => exam.id === id);
}
