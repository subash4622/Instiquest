/**
 * INSTIQUEST chatbot knowledge base — VERIFIED short facts only.
 * -------------------------------------------------------------
 * The chatbot uses this file as the verified-context source. AI
 * responses are clearly labelled as AI-generated guidance and must
 * NOT be merged with verified facts without explicit marking.
 *
 * Every entry here is short, factual and verifiable.
 */

export interface KBEntry {
  id: string;
  keywords: string[];
  category: "exam" | "institution" | "admission" | "policy" | "general";
  answer: string;
  verified: true;
}

export const verifiedKB: KBEntry[] = [
  {
    id: "kb-jee-main-route",
    keywords: ["jee main", "jee-main", "jee main admission route", "jee main counselling", "josaa"],
    category: "exam",
    answer:
      "Admission to NITs, IIITs and other GFTIs through JEE Main is via JoSAA (Joint Seat Allocation Authority) counselling. IITs require JEE Advanced.",
    verified: true,
  },
  {
    id: "kb-jee-advanced-route",
    keywords: ["jee advanced", "jee-advanced", "iit admission", "iit counselling"],
    category: "exam",
    answer:
      "Admission to IITs is through JEE Advanced followed by JoSAA counselling. Only the top JEE Main rank-holders are eligible to appear for JEE Advanced.",
    verified: true,
  },
  {
    id: "kb-neet-route",
    keywords: ["neet", "neet ug", "neet counselling", "mcc", "aiq"],
    category: "exam",
    answer:
      "NEET UG is the single entrance test for MBBS/BDS admission in India. All India Quota (15%) counselling is by MCC; state quota (85%) counselling is by respective state authorities.",
    verified: true,
  },
  {
    id: "kb-cat-route",
    keywords: ["cat", "iim admission", "cat counselling", "cap"],
    category: "exam",
    answer:
      "Admission to IIMs is through CAT followed by Written Ability Test (WAT) / Personal Interview (PI). The Common Admission Process (CAP) is used by several newer IIMs.",
    verified: true,
  },
  {
    id: "kb-clat-route",
    keywords: ["clat", "law admission", "nlus"],
    category: "exam",
    answer:
      "CLAT is the entrance test for admission to the National Law Universities (NLUs). The Consortium of NLUs conducts CLAT for both UG and PG law programmes.",
    verified: true,
  },
  {
    id: "kb-cuet-route",
    keywords: ["cuet", "cuet ug", "cuet pg", "central university admission"],
    category: "exam",
    answer:
      "CUET UG and CUET PG are conducted by NTA for admission to central universities and other participating institutes.",
    verified: true,
  },
  {
    id: "kb-gate-route",
    keywords: ["gate", "m.tech", "mtect admission", "iit mtech"],
    category: "exam",
    answer:
      "GATE is the entrance test for M.Tech / ME admission at IITs, NITs and several other institutes. GATE scores are also used by some PSUs for recruitment.",
    verified: true,
  },
  {
    id: "kb-mock-tests",
    keywords: ["mock test", "practice", "test series", "free mock"],
    category: "general",
    answer:
      "INSTIQUEST offers hard-level original mock tests for Engineering, Medical, Management and Law streams. Each test has timed sections, negative marking, explanations and performance analytics.",
    verified: true,
  },
  {
    id: "kb-ads-portal",
    keywords: ["advertising", "advertise", "institute ad", "banner", "promotion"],
    category: "general",
    answer:
      "Institutes can submit advertising requests via the Advertising Portal. All submissions go through admin moderation before being published. No advertisement is published automatically.",
    verified: true,
  },
  {
    id: "kb-data-verified",
    keywords: ["verified", "verified data", "is this verified", "authenticity"],
    category: "general",
    answer:
      "Directory entries show a verified badge when the conducting authority, course, eligibility and official website are all confirmed. Items marked 'Unverified — pending review' should be cross-checked on the official portal.",
    verified: true,
  },
];

export function searchKB(query: string): KBEntry[] {
  const q = query.toLowerCase();
  // Score each entry by counting keyword matches.
  const scored = verifiedKB
    .map((e) => {
      let score = 0;
      for (const k of e.keywords) {
        const kl = k.toLowerCase();
        if (q.includes(kl)) {
          score += kl.length > 6 ? 3 : 2; // longer keyword = stronger match
        } else {
          // Word-level fallback: split keyword into words and count matches
          const words = kl.split(/[\s-]+/).filter((w) => w.length >= 3);
          const matched = words.filter((w) => q.includes(w)).length;
          if (matched > 0 && matched >= Math.ceil(words.length / 2)) {
            score += 1;
          }
        }
      }
      return { entry: e, score };
    })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score);
  return scored.map((x) => x.entry);
}
