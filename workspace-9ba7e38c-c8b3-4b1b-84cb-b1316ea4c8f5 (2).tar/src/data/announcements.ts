/**
 * INSTIQUEST announcements feed
 * -------------------------------------------------------------
 * Generic factual announcements with NO invented dates.
 * Anything time-sensitive uses relative phrasing or is marked REVIEW.
 */

export const REVIEW = "Unverified — pending review";

export interface Announcement {
  id: string;
  title: string;
  category: "Exam Update" | "Admission" | "Institution" | "Policy" | "Feature" | "General";
  summary: string;
  body: string;
  date: string;            // ISO date — uses "pending review" string if unverified
  source?: string;
  verified: boolean;
  pinned?: boolean;
}

export const announcements: Announcement[] = [
  {
    id: "ann-001",
    title: "INSTIQUEST Mock Test Engine Launched",
    category: "Feature",
    summary:
      "Hard-level original mock tests for Engineering, Medical, Management and Law streams are now live with timed sections, marking scheme and analytics.",
    body:
      "INSTIQUEST now ships a hard-level mock test engine with four flagship original papers (Engineering, Medical, Management, Law). Each mock has timed sections, a configurable marking scheme with negative marking, full question navigation, explanations, an analytics dashboard and a question review panel. Results are saved to your student dashboard.",
    date: "2026-11-15",
    verified: true,
    pinned: true,
  },
  {
    id: "ann-002",
    title: "Directory of 120+ Entrance Exams Published",
    category: "Feature",
    summary:
      "Browse 120+ verified Indian and international entrance exams across 11 categories with conducting authority, eligibility and official websites.",
    body:
      "The INSTIQUEST exam directory now lists 120+ exams across Engineering, Medical, Management, Law, Design, Architecture, Science, Humanities, Maritime, Defence and Other categories. Each entry includes conducting authority, course, eligibility and a link to the official website. Entries whose eligibility or dates could not be verified are clearly flagged for review.",
    date: "2026-11-12",
    verified: true,
  },
  {
    id: "ann-003",
    title: "Institution Directory Expanded to 100+ Institutes",
    category: "Institution",
    summary:
      "IITs, NITs, IIITs, IIMs, central and state universities and private universities are now searchable with filters.",
    body:
      "The institution directory now covers more than 100 institutes across IITs, NITs, IIITs, IIMs, central universities, state universities and private/deemed universities. Filter by type, state or admission route. Each entry has the real official website and the standard admission route (e.g., JEE Advanced + JoSAA).",
    date: "2026-11-10",
    verified: true,
  },
  {
    id: "ann-004",
    title: "AI Admission Assistant Now Available",
    category: "Feature",
    summary:
      "An AI chatbot provides admission guidance. Verified information is clearly distinguished from AI-generated guidance.",
    body:
      "The INSTIQUEST AI Admission Assistant is a server-side proxy that connects to a secure AI provider. No API keys are exposed in frontend code. Every AI response is clearly labelled as AI-generated guidance, distinct from verified directory information.",
    date: "2026-11-08",
    verified: true,
  },
  {
    id: "ann-005",
    title: "Institute Advertising Portal Open for Submissions",
    category: "Admission",
    summary:
      "Institutes can now submit banners, profile details and campaign requests. All submissions go through admin moderation before publishing.",
    body:
      "The advertising portal accepts institute submissions including banner copy, profile details and campaign requests. Submissions enter a moderation queue and an admin must approve them before publication. No advertisement is published automatically. Payment integration is a clearly-labelled demo placeholder.",
    date: "2026-11-06",
    verified: true,
  },
  {
    id: "ann-006",
    title: "JEE Main Information Bulletin — Refer Official Portal",
    category: "Exam Update",
    summary:
      "Candidates are advised to refer to the official NTA JEE Main portal for the latest information bulletin and application window.",
    body:
      "INSTIQUEST aggregates JEE Main information for convenience, but the authoritative source for the information bulletin, eligibility and application window is the official NTA JEE Main portal. Candidates must verify all details on jeemain.nta.ac.in before applying.",
    date: REVIEW,
    source: "https://jeemain.nta.ac.in",
    verified: false,
  },
  {
    id: "ann-007",
    title: "NEET UG Counselling — Refer MCC Portal",
    category: "Admission",
    summary:
      "All India Quota NEET UG counselling is conducted by the Medical Counselling Committee. Refer to mcc.nic.in for the latest schedule.",
    body:
      "All India Quota (15%) NEET UG counselling is conducted by the Medical Counselling Committee (MCC) on mcc.nic.in. State quota counselling (85%) is conducted by respective state authorities. INSTIQUEST links to the official portals but does not schedule counselling dates.",
    date: REVIEW,
    source: "https://mcc.nic.in",
    verified: false,
  },
  {
    id: "ann-008",
    title: "CUET UG Window — Refer NTA",
    category: "Exam Update",
    summary:
      "The Common University Entrance Test (UG) is conducted by NTA. Refer to the official CUET UG portal for the latest notification.",
    body:
      "The Common University Entrance Test (UG) is conducted by the National Testing Agency for admission to central universities and other participating institutes. The official portal is exams.nta.ac.in/CUET-UG/. INSTIQUEST displays the official link and a general summary; do not rely on third-party timelines for application windows.",
    date: REVIEW,
    source: "https://exams.nta.ac.in/CUET-UG/",
    verified: false,
  },
];

export function getPinnedAnnouncements(): Announcement[] {
  return announcements.filter((a) => a.pinned);
}

export function getVerifiedAnnouncements(): Announcement[] {
  return announcements.filter((a) => a.verified);
}

export function getAnnouncementById(id: string): Announcement | undefined {
  return announcements.find((a) => a.id === id);
}
