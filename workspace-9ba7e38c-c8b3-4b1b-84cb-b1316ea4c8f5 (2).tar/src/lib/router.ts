/**
 * INSTIQUEST client-side router store (Zustand)
 * -------------------------------------------------------------
 * The INSTIQUEST SPA exposes a single visible route (`/`) per the
 * sandbox preview constraint, but inside the app we navigate between
 * many logical "pages" using hash-based routing so users can
 * deep-link, share URLs and use the browser back button.
 *
 * Routes are plain strings: `home`, `exams`, `exams/jee-main`, etc.
 */

"use client";

import { create } from "zustand";

export type Route =
  | "home"
  | "exams"
  | "institutions"
  | "mock-tests"
  | "mock-tests/active"
  | "mock-tests/result"
  | "guidance"
  | "chatbot"
  | "advertising"
  | "student-dashboard"
  | "admin"
  | "about"
  | "contact"
  | "privacy"
  | "terms"
  | "disclaimer"
  | "faq"
  | "previous-papers"
  | "template-editor";

interface RouterState {
  route: Route;
  param?: string; // sub-id like exam id, mock id, etc.
  query: Record<string, string>;
  navigate: (route: Route, param?: string, query?: Record<string, string>) => void;
  back: () => void;
  /** Read initial route from location.hash on first load. */
  hydrate: () => void;
}

const MULTI_SEGMENT_ROUTES = ["mock-tests/active", "mock-tests/result"];

function parseHash(): { route: Route; param?: string; query: Record<string, string> } {
  if (typeof window === "undefined") return { route: "home" };
  const h = window.location.hash.replace(/^#\/?/, "");
  if (!h) return { route: "home" };
  const [path, qStr] = h.split("?");
  const segs = path.split("/").filter(Boolean);

  // Check for multi-segment routes first (e.g. "mock-tests/active")
  let route: Route = "home";
  let param: string | undefined;
  if (segs.length >= 2) {
    const candidate = `${segs[0]}/${segs[1]}`;
    if (MULTI_SEGMENT_ROUTES.includes(candidate)) {
      route = candidate as Route;
      param = segs.slice(2).join("/") || undefined;
    }
  }
  if (route === "home" && segs.length >= 1) {
    route = (segs[0] as Route) || "home";
    param = segs.slice(1).join("/") || undefined;
  }

  const query: Record<string, string> = {};
  if (qStr) {
    new URLSearchParams(qStr).forEach((v, k) => (query[k] = v));
  }
  return { route, param, query };
}

function writeHash(route: Route, param?: string, query?: Record<string, string>) {
  if (typeof window === "undefined") return;
  const parts = [route];
  if (param) parts.push(param);
  let hash = `#/${parts.join("/")}`;
  if (query && Object.keys(query).length) {
    const qs = new URLSearchParams(query).toString();
    hash += `?${qs}`;
  }
  if (window.location.hash !== hash) {
    window.location.hash = hash;
  }
}

export const useRouter = create<RouterState>((set, get) => ({
  route: "home",
  param: undefined,
  query: {},
  navigate: (route, param, query) => {
    writeHash(route, param, query);
    set({ route, param, query: query ?? {} });
    if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  },
  back: () => {
    if (typeof window !== "undefined") window.history.back();
  },
  hydrate: () => {
    if (typeof window === "undefined") return;
    const { route, param, query } = parseHash();
    set({ route, param, query });
    window.addEventListener("hashchange", () => {
      const p = parseHash();
      set({ route: p.route, param: p.param, query: p.query });
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  },
}));

/** Build a hash-href for anchor tags / SR-only links. */
export function routeHref(route: Route, param?: string, query?: Record<string, string>): string {
  const parts = [route];
  if (param) parts.push(param);
  let hash = `#/${parts.join("/")}`;
  if (query && Object.keys(query).length) {
    hash += `?${new URLSearchParams(query).toString()}`;
  }
  return hash;
}
