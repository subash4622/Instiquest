/**
 * INSTIQUEST global app stores (Zustand).
 * -------------------------------------------------------------
 * - useAuth: role-based auth (DEMO: client-side, clearly labelled).
 *   The shape mirrors what a real NextAuth.js session would provide;
 *   replace the demo login with a real NextAuth credentials/email
 *   provider before going live. Passwords are NEVER stored in the
 *   client; only an opaque session object is.
 * - useStudentData: in-memory student dashboard data (saved exams,
 *   bookmarks, mock results, applications). The same shape is
 *   mirrored in the Prisma schema for server-side persistence.
 */

"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { siteConfig } from "@/data/site-config";

// ---------- Auth ----------
export type Role = "student" | "institute" | "admin" | "owner";

export interface SessionUser {
  id: string;
  name: string;
  email: string;
  role: Role;
  /** Demo flag — auth is currently client-side for the preview. */
  demo?: boolean;
}

interface AuthState {
  user: SessionUser | null;
  login: (role: Role, name?: string, email?: string) => void;
  /** Owner-specific login — gated by a configurable owner key. */
  loginOwner: (ownerKey: string) => { ok: boolean; error?: string };
  logout: () => void;
}

/**
 * Owner login key placeholder.
 * -------------------------------------------------------------
 * Replace with a real NextAuth credentials provider + hashed
 * password check on the server before going live.
 * The owner key is read from site-config.ts so it's not hardcoded
 * in this file. Default placeholder value: "OWNER-KEY-PLACEHOLDER".
 */
const OWNER_KEY_STORAGE = "instiquest-owner-key";

export const useAuth = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      login: (role, name, email) => {
        const user: SessionUser = {
          id: `demo-${role}-${Date.now()}`,
          name: name ?? (role === "admin" ? "Admin User" : role === "institute" ? "Institute Rep" : role === "owner" ? "Owner" : "Student User"),
          email: email ?? `${role}@instiquest.demo`,
          role,
          demo: true,
        };
        set({ user });
      },
      /**
       * Owner login — gated by a configurable owner key.
       * For the demo, the key is stored in localStorage at first
       * setup and compared client-side. In production, replace
       * with a server-side credentials check via NextAuth.
       */
      loginOwner: (ownerKey: string) => {
        const expectedKey =
          (typeof window !== "undefined" && localStorage.getItem(OWNER_KEY_STORAGE)) ||
          siteConfig.owner.ownerKeyPlaceholder;
        if (!ownerKey || ownerKey.trim() !== expectedKey) {
          return { ok: false, error: "Invalid owner key. Contact the site owner." };
        }
        const ownerUser: SessionUser = {
          id: `owner-${Date.now()}`,
          name: siteConfig.owner.name,
          email: siteConfig.contact.businessEmail,
          role: "owner",
          demo: false,
        };
        set({ user: ownerUser });
        return { ok: true };
      },
      logout: () => set({ user: null }),
    }),
    {
      name: "instiquest-auth",
      storage: createJSONStorage(() => (typeof window !== "undefined" ? localStorage : (undefined as unknown as Storage))),
    }
  )
);

/** Helper: check if the current user has owner privileges. */
export function useIsOwner(): boolean {
  const user = useAuth((s) => s.user);
  return user?.role === "owner";
}

// ---------- Student Data ----------
export interface SavedExam {
  examId: string;
  addedAt: number;
  notes?: string;
  deadline?: string;
}

export interface Bookmark {
  resourceType: "EXAM" | "INSTITUTION" | "ANNOUNCEMENT" | "MOCK_TEST";
  resourceId: string;
  addedAt: number;
}

export interface MockResultSummary {
  id: string;
  mockTestId: string;
  mockTestTitle: string;
  scoredMarks: number;
  totalMarks: number;
  accuracy: number;
  takenAt: number;
  durationSec: number;
}

export interface ApplicationTrack {
  id: string;
  examId?: string;
  institutionId?: string;
  status: "PLANNED" | "APPLIED" | "ADMIT_CARD" | "APPEARED" | "RESULT" | "COUNSELLING" | "ADMITTED" | "REJECTED";
  updatedAt: number;
  notes?: string;
}

interface StudentState {
  savedExams: SavedExam[];
  bookmarks: Bookmark[];
  mockResults: MockResultSummary[];
  applications: ApplicationTrack[];

  saveExam: (examId: string) => void;
  unsaveExam: (examId: string) => void;
  isExamSaved: (examId: string) => boolean;

  toggleBookmark: (resourceType: Bookmark["resourceType"], resourceId: string) => void;
  isBookmarked: (resourceType: Bookmark["resourceType"], resourceId: string) => boolean;

  addMockResult: (r: MockResultSummary) => void;

  addApplication: (a: Omit<ApplicationTrack, "id" | "updatedAt">) => void;
  updateApplication: (id: string, status: ApplicationTrack["status"], notes?: string) => void;
  removeApplication: (id: string) => void;
}

export const useStudentData = create<StudentState>()(
  persist(
    (set, get) => ({
      savedExams: [],
      bookmarks: [],
      mockResults: [],
      applications: [],

      saveExam: (examId) => {
        if (get().savedExams.some((e) => e.examId === examId)) return;
        set({ savedExams: [...get().savedExams, { examId, addedAt: Date.now() }] });
      },
      unsaveExam: (examId) => set({ savedExams: get().savedExams.filter((e) => e.examId !== examId) }),
      isExamSaved: (examId) => get().savedExams.some((e) => e.examId === examId),

      toggleBookmark: (resourceType, resourceId) => {
        const exists = get().bookmarks.some((b) => b.resourceType === resourceType && b.resourceId === resourceId);
        if (exists) {
          set({ bookmarks: get().bookmarks.filter((b) => !(b.resourceType === resourceType && b.resourceId === resourceId)) });
        } else {
          set({ bookmarks: [...get().bookmarks, { resourceType, resourceId, addedAt: Date.now() }] });
        }
      },
      isBookmarked: (resourceType, resourceId) =>
        get().bookmarks.some((b) => b.resourceType === resourceType && b.resourceId === resourceId),

      addMockResult: (r) => set({ mockResults: [r, ...get().mockResults].slice(0, 50) }),

      addApplication: (a) =>
        set({ applications: [{ ...a, id: `app-${Date.now()}`, updatedAt: Date.now() }, ...get().applications] }),
      updateApplication: (id, status, notes) =>
        set({
          applications: get().applications.map((a) =>
            a.id === id ? { ...a, status, notes: notes ?? a.notes, updatedAt: Date.now() } : a
          ),
        }),
      removeApplication: (id) => set({ applications: get().applications.filter((a) => a.id !== id) }),
    }),
    {
      name: "instiquest-student-data",
      storage: createJSONStorage(() => (typeof window !== "undefined" ? localStorage : (undefined as unknown as Storage))),
    }
  )
);

// ---------- Mock Test Active Session ----------
export interface MockAnswerLog {
  questionId: string;
  selectedOptions: number[];
  numericalAnswer?: number;
  status: "unanswered" | "answered" | "marked-for-review" | "answered-marked";
  timeSpentSec: number;
}

export interface MockSessionState {
  mockTestId: string | null;
  currentSectionId: string | null;
  currentIndex: number;
  answers: Record<string, MockAnswerLog>;
  startedAt: number | null;
  endsAt: number | null;
  // results
  lastResult?: {
    mockTestId: string;
    scoredMarks: number;
    totalMarks: number;
    accuracy: number;
    correct: number;
    wrong: number;
    unattempted: number;
    durationSec: number;
    perSection: { sectionId: string; name: string; scored: number; total: number; correct: number; wrong: number; unattempted: number }[];
    perQuestion: { questionId: string; correct: boolean; scored: number; chosen: number[]; correctAnswers: number[]; timeSpentSec: number }[];
  };
  start: (mockTestId: string, durationSec: number, firstSectionId: string) => void;
  setSection: (sectionId: string) => void;
  setIndex: (i: number) => void;
  recordAnswer: (questionId: string, log: Partial<MockAnswerLog>) => void;
  reset: () => void;
  finish: (result: NonNullable<MockSessionState["lastResult"]>) => void;
}

export const useMockSession = create<MockSessionState>((set, get) => ({
  mockTestId: null,
  currentSectionId: null,
  currentIndex: 0,
  answers: {},
  startedAt: null,
  endsAt: null,
  lastResult: undefined,
  start: (mockTestId, durationSec, firstSectionId) =>
    set({
      mockTestId,
      currentSectionId: firstSectionId,
      currentIndex: 0,
      answers: {},
      startedAt: Date.now(),
      endsAt: Date.now() + durationSec * 1000,
      lastResult: undefined,
    }),
  setSection: (sectionId) => set({ currentSectionId: sectionId, currentIndex: 0 }),
  setIndex: (i) => set({ currentIndex: i }),
  recordAnswer: (questionId, log) =>
    set({
      answers: {
        ...get().answers,
        [questionId]: {
          questionId,
          selectedOptions: [],
          status: "unanswered",
          timeSpentSec: 0,
          ...get().answers[questionId],
          ...log,
        },
      },
    }),
  reset: () =>
    set({
      mockTestId: null,
      currentSectionId: null,
      currentIndex: 0,
      answers: {},
      startedAt: null,
      endsAt: null,
    }),
  finish: (result) => set({ lastResult: result, mockTestId: null }),
}));
