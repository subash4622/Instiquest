# INSTIQUEST — Premium Educational Admission Portal

> Built by **WEB CREATORS** · Ownership: **S. Subash** (placeholder until approved for publication)

A futuristic, multi-page educational admission portal built with Next.js 16, TypeScript, Tailwind CSS 4, shadcn/ui, Prisma and Zustand. INSTIQUEST aggregates 120+ entrance exams, 100+ institutions, hard-level mock tests, an AI admission assistant, an institute advertising gateway and a complete admin console — with verified information clearly separated from AI-generated guidance.

---

## ✨ Features

### 1. Homepage
Premium dashboard with animated hero (gradient + orbit + grid background), live statistics, search bar, featured exams, featured institutions, announcements feed and category quick-links.

### 2. Entrance Exam Directory (`#/exams`)
- **120+ verified Indian and international entrance exams**
- 11 categories: Engineering, Medical, Management, Law, Design, Architecture, Science, Humanities, Maritime, Defence, Other
- Real conducting authority, course, eligibility, official website
- **Verified badge** vs **"Unverified — pending review"** badge for every entry
- Search, category/level filters, "Verified only" toggle
- Detail page with overview, eligibility, application info, official portal link
- Save / bookmark any exam

### 3. Institution Directory (`#/institutions`)
- **100+ institutions** across IITs (23), NITs (20), IIITs (15), IIMs (20), central universities, state universities, private/deemed universities
- Real official websites, founding years, admission routes
- Filter by type, state; search by name, location, programme

### 4. Hard-Level Mock Test Module (`#/mock-tests`)
- **4 original mock tests** (Engineering, Medical, Management, Law) — **60 original questions total**, authored by INSTIQUEST, not copied from copyrighted papers
- Timed sections, multiple sections per test, question navigation palette
- Configurable marking scheme with **negative marking**
- Question types: single-correct, multiple-correct, numerical, assertion-reason
- Mark-for-review,answered-marked statuses
- Full result page: score, percentage ring, accuracy, time per question chart (Recharts), per-section breakdown
- Tabs: **Question review** (shows chosen vs correct, marks), **Explanations** (per question), **Analytics** (per-section + recommendations)
- Results saved to student dashboard

### 5. Application Guidance (`#/guidance`)
- 6-step vertical stepper (Choose exam → Eligibility → Register → Fill → Pay fee → Admit card)
- Eligibility checklist (interactive checkboxes)
- Document checklist (10 typical documents)
- Fee structure note with **Unverified badge** — no invented numbers
- CTAs to exams directory and AI assistant

### 6. AI Admission Chatbot (`#/chatbot`)
- Polished chat interface with input box and quick-question chips
- Calls server-side `/api/chat` endpoint — **API keys are NEVER exposed in frontend code**
- Every AI response shows **AI Guidance** badge and disclaimer line
- Verified KB facts pulled from `src/data/kb.ts` show **Verified** badge
- Top disclaimer banner: "AI responses are guidance only. Verify on official portals."
- Falls back gracefully to KB-augmented responses when the AI provider is unavailable
- Persists chat thread to localStorage

### 7. Institute Advertising Portal (`#/advertising`)
- Submission form with **full input validation** (institute name, contact email/phone, website URL, banner copy, campaign dates, message)
- Workflow explanation: **Submit → Admin moderation → Approved → Published**
- **"No advertisement is published automatically without admin approval"** notice
- Payment integration clearly labelled as **demo placeholder**
- Status tracking panel showing previous submissions with Pending/Approved/Rejected/Published
- Submissions stored to database via `/api/ads` (falls back to localStorage in demo)
- Admin moderation endpoint at `/api/admin/ads` with role-gated approve/reject

### 8. Student Dashboard (`#/student-dashboard`)
- Role-gated (demo sign-in as student/institute/admin)
- 5 tabs: **Overview** (stats + recent activity + upcoming deadlines), **Saved Exams**, **Bookmarks**, **Mock Results** (with Recharts accuracy trend), **Applications**
- Application tracking with 8-status lifecycle (PLANNED → APPLIED → ADMIT_CARD → APPEARED → RESULT → COUNSELLING → ADMITTED/REJECTED)
- All data persisted to localStorage (Zustand `persist` middleware)

### 9. Info Pages
- **About & Mission** (`#/about`): mission, vision, 6 core values, stats, ownership status
- **Contact** (`#/contact`): contact form with validation, business/support email, phone, address, social links — all configurable placeholders
- **Privacy Policy** (`#/privacy`): 6-section draft policy
- **Terms of Use** (`#/terms`): 10-section draft terms
- **Disclaimer** (`#/disclaimer`): 5-section disclaimer covering verified vs AI, dates, demo features, advertising

### 10. Admin Dashboard (`#/admin`)
- Role-gated (admin only; demo sign-in available)
- 6 tabs: **Exams**, **Institutions**, **Mock Questions**, **Advertisements** (with approve/reject that updates localStorage + DB), **Chatbot Content** (view-only KB), **Application Dates**
- All actions are clearly-labelled demo (toast notifications)

---

## 🎨 Design

- **Palette**: dark navy (`oklch(0.14 0.04 264)`), electric blue (`#3B82F6`), cyan glow (`#22D3EE`), subtle purple (`#A855F7`)
- **Typography**: Geist Sans (body) + Geist Mono (code), with consistent hierarchy
- **Original SVG logo**: stylised letter "I" + graduation cap + animated futuristic orbit, with `INSTIQUEST` wordmark and `WEB CREATORS` subtitle in small caps
- **Favicon**: standalone SVG mark
- **Effects**: glass-card surfaces with backdrop blur, glowing buttons (`box-shadow` + hover lift), animated gradient text, orbit/spin/pulse-glow animations, aurora + grid backgrounds
- **Responsive**: mobile-first; sidebar collapses to a slide-in Sheet on mobile; touch-friendly targets (min 44px)
- **Accessibility**: semantic HTML, ARIA labels, keyboard-navigable, sr-only text where needed, high-contrast colour choices

---

## 📂 Project Structure

```
.
├── prisma/
│   └── schema.prisma              # User, SavedExam, Bookmark, MockResult, Application, Advertisement, ChatThread, ChatMessage, ExamDate
├── public/
│   ├── favicon.svg                # INSTIQUEST standalone mark
│   ├── logo.svg                   # Full logo with wordmark
│   └── robots.txt
├── src/
│   ├── app/
│   │   ├── layout.tsx             # Root layout, SEO metadata
│   │   ├── page.tsx               # Mounts AppShell (the SPA)
│   │   ├── globals.css            # Theme tokens, custom utilities, animations
│   │   └── api/
│   │       ├── chat/route.ts      # AI chatbot server-side proxy (KB fallback)
│   │       ├── ads/route.ts       # Advertising submission endpoint
│   │       ├── auth/login/route.ts# Demo auth endpoint (replace with NextAuth)
│   │       └── admin/ads/route.ts # Admin moderation endpoint
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Logo.tsx           # Original SVG logo + LogoMark
│   │   │   ├── Sidebar.tsx        # Desktop sidebar + mobile Sheet nav
│   │   │   ├── Header.tsx         # Top bar with search, user menu, ticker
│   │   │   ├── Footer.tsx         # Footer with link groups + contact
│   │   │   └── AppShell.tsx       # Wires routing → page components
│   │   ├── pages/                 # All page components (one per route)
│   │   │   ├── HomePage.tsx
│   │   │   ├── ExamDirectoryPage.tsx
│   │   │   ├── InstitutionDirectoryPage.tsx
│   │   │   ├── MockTestListPage.tsx
│   │   │   ├── MockTestRunner.tsx
│   │   │   ├── MockTestResultPage.tsx
│   │   │   ├── ApplicationGuidancePage.tsx
│   │   │   ├── ChatbotPage.tsx
│   │   │   ├── AdvertisingPortalPage.tsx
│   │   │   ├── StudentDashboardPage.tsx
│   │   │   ├── AdminDashboardPage.tsx
│   │   │   ├── AboutPage.tsx
│   │   │   ├── ContactPage.tsx
│   │   │   ├── PrivacyPage.tsx
│   │   │   ├── TermsPage.tsx
│   │   │   └── DisclaimerPage.tsx
│   │   ├── common/
│   │   │   └── ui-bits.tsx        # VerifiedBadge, UnverifiedBadge, AIBadge, DemoBadge, StatBlock, EmptyState, LoadingGrid, SectionHeading
│   │   └── ui/                    # shadcn/ui primitives (existing)
│   ├── data/                      # All editable content lives here
│   │   ├── site-config.ts         # Brand, ownership, contact, chatbot/payments config
│   │   ├── exams.ts               # 120+ exams
│   │   ├── institutions.ts        # 100+ institutions
│   │   ├── mock-tests.ts          # 4 mock tests, 60 questions
│   │   ├── announcements.ts       # Announcements feed
│   │   └── kb.ts                  # Verified chatbot knowledge base
│   └── lib/
│       ├── router.ts              # Hash-based client router (Zustand)
│       ├── stores.ts              # useAuth, useStudentData, useMockSession (Zustand + persist)
│       ├── db.ts                  # Prisma client singleton
│       └── utils.ts               # cn() helper (existing)
├── Caddyfile                      # Gateway config (sandbox)
├── package.json
└── README.md (this file)
```

---

## 🛠️ How to Edit

### Brand, ownership and contact
All configurable values live in **`src/data/site-config.ts`**. Update:
- `owner.name` (currently `"S. Subash"` — placeholder)
- `owner.approvedForPublication` (set to `true` once approved)
- `contact.businessEmail`, `contact.supportEmail`, `contact.phoneDisplay`, `contact.address`
- `social.*` links
- `chatbot.apiEndpoint`, `chatbot.providerLabel`, `chatbot.enabled`
- `payments.*` (clearly a demo placeholder)

### Add or edit exams
Edit **`src/data/exams.ts`**. Each entry uses the `Exam` interface (see top of file). Mark `verified: false` and set the unverified fields to `REVIEW` (`"Unverified — pending review"`) for any value you cannot independently verify. Never invent dates or specific eligibility percentages.

### Add or edit institutions
Edit **`src/data/institutions.ts`**. Same pattern: real names, real official websites, real founding years.

### Add mock tests / questions
Edit **`src/data/mock-tests.ts`**. All questions must be originally authored. The schema supports `single`, `multiple`, `numerical` and `assertion-reason` question types, per-section durations and configurable negative marking.

### Update chatbot verified KB
Edit **`src/data/kb.ts`**. Add short, factual `KBEntry` records with `keywords` for matching. AI responses are clearly distinct from these verified facts.

### Update announcements
Edit **`src/data/announcements.ts`**. Each announcement has a `verified` flag and optional `source` URL pointing to the official portal.

---

## ▶️ How to Run Locally

```bash
# 1. Install deps
bun install        # or: npm install / pnpm install

# 2. Set up the database
cp .env.example .env   # if .env.example is provided
bun run db:push        # creates SQLite db at prisma/dev.db (or per DATABASE_URL)
bun run db:generate    # generates Prisma client

# 3. Start the dev server
bun run dev            # http://localhost:3000
```

> In the sandbox preview, the dev server starts automatically. To view externally, click the **"Open in New Tab"** button above the preview panel, or use the generated preview link shared with you.

### Build for production
```bash
bun run build
bun run start
```

---

## ✅ How to Test

```bash
# Lint
bun run lint

# Type-check
npx tsc --noEmit

# Push DB schema after editing prisma/schema.prisma
bun run db:push

# Reset DB
bun run db:reset
```

### Manual test checklist
- [ ] Home renders with hero, stats, featured exams, announcements
- [ ] Exam directory filters by category, level, verified
- [ ] Exam detail page links to official website
- [ ] Institution directory filters by type and state
- [ ] Mock test: start → answer questions → mark for review → submit → see result with charts
- [ ] Mock result tabs: Question review, Explanations, Analytics all populated
- [ ] Chatbot: type a question → get verified KB answer (try "JEE Main")
- [ ] Advertising portal: submit form → see pending status → admin dashboard shows the submission
- [ ] Student dashboard: sign in (demo) → save an exam → see it in dashboard
- [ ] Admin dashboard: sign in as admin → 6 tabs render → Approve/Reject buttons toast demo message
- [ ] Mobile view: sidebar collapses to slide-in sheet

---

## 🚀 How to Deploy

### Vercel (recommended)
1. Push this repo to GitHub.
2. Import to Vercel.
3. Set environment variables (see `.env.example`):
   - `DATABASE_URL` — switch to PostgreSQL (`postgresql://...`) for production
   - `ZAI_API_KEY` or `OPENAI_API_KEY` — for live AI chatbot (currently uses KB fallback)
   - `NEXTAUTH_SECRET`, `NEXTAUTH_URL` — for real auth
4. Vercel auto-detects Next.js and runs `bun run build`.

### Self-hosted (Node)
1. Run `bun run build` to produce `.next/standalone`.
2. Run `bun run start` (or `node .next/standalone/server.js`).
3. Put behind a reverse proxy (nginx / Caddy) with TLS.

### Database
- **Dev**: SQLite (`file:./prisma/dev.db`) — already configured.
- **Prod**: switch `provider` in `prisma/schema.prisma` to `"postgresql"` and set `DATABASE_URL`. Run `bun run db:push` to create tables.

### Environment variables
| Var | Purpose | Required? |
| --- | --- | --- |
| `DATABASE_URL` | Prisma datasource URL | Yes |
| `ZAI_API_KEY` | z-ai-web-dev-sdk LLM provider (chatbot) | Optional (KB fallback works without) |
| `NEXTAUTH_SECRET` | NextAuth session secret | When you wire real auth |
| `NEXTAUTH_URL` | Public URL for callbacks | When you wire real auth |

---

## 🔒 Security Notes

- **API keys never exposed**: the chatbot route (`/api/chat`) reads `process.env.ZAI_API_KEY` server-side. The frontend only knows the relative endpoint.
- **Demo auth**: `useAuth` in `src/lib/stores.ts` is a clearly-labelled client-side demo using `localStorage`. Replace with NextAuth.js credentials/email provider before going live. Passwords must be hashed server-side (e.g., bcrypt).
- **Role-based permissions**: routes for admin features are gated client-side AND the `/api/admin/ads` endpoint is documented as requiring admin role (TODO: enforce via NextAuth session check).
- **Input validation**: advertising submission route validates email, phone, URLs and length limits. Contact form validates inline.
- **No automatic ad publishing**: all submissions enter `PENDING` status. Admin must explicitly approve.
- **Privacy**: localStorage stores only the opaque session object, saved exams, bookmarks, mock results, applications and chat thread. Clearing browser storage removes all INSTIQUEST data.

---

## 🔄 How to Update

| Want to… | Edit this |
| --- | --- |
| Change brand / owner / contact | `src/data/site-config.ts` |
| Add exams | `src/data/exams.ts` |
| Add institutions | `src/data/institutions.ts` |
| Add mock tests | `src/data/mock-tests.ts` |
| Update chatbot KB | `src/data/kb.ts` |
| Add announcements | `src/data/announcements.ts` |
| Change theme | `src/app/globals.css` (`:root` and `.dark` tokens) |
| Change logo | `src/components/layout/Logo.tsx` + `public/logo.svg` + `public/favicon.svg` |
| Add a new page | Create `src/components/pages/XPage.tsx`, add a `Route` to `src/lib/router.ts`, register it in `src/components/layout/AppShell.tsx`'s `RouteRenderer`, add a nav item in `src/components/layout/Sidebar.tsx` |
| Change DB schema | Edit `prisma/schema.prisma`, run `bun run db:push` |
| Enable live AI | Uncomment the SDK call in `src/app/api/chat/route.ts` and set `ZAI_API_KEY` |
| Enable real auth | Replace `src/app/api/auth/login/route.ts` and `src/lib/stores.ts` `useAuth` with NextAuth.js |

---

## 📝 Disclaimer

INSTIQUEST is a demo build. Authentication, payment integration and several admin actions are clearly-labelled demo placeholders. Exam dates, application windows, fee structures and specific eligibility percentages are NOT published as confirmed facts — unverified items are flagged as "Unverified — pending review" and must be cross-checked on the official portal before any decision or payment. Mock-test questions are originally authored by INSTIQUEST and do not represent actual exam papers. See the in-app Disclaimer page for the full text.

---

© 2026 INSTIQUEST · WEB CREATORS · Owner: S. Subash (placeholder until approved for publication)
